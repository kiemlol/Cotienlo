# Cổ Tiên Lộ · gói mã client V3

Gói này chứa bốn bundle client công khai đã khôi phục về dạng đọc được, runtime chơi đơn tự dựng, test và báo cáo nguồn. Đây không phải source backend và không phải gói asset đầy đủ. Xem `docs/V3-IMPLEMENTATION.md` để biết phần đã quan sát, phần tự dựng và giới hạn.
