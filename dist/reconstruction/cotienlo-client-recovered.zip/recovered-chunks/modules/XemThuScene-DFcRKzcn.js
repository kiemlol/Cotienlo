import { a as a_1, i, n, r, t as t_1 } from "./index-ChkNmBLw.js";
const a = a_1(i(), 1);
export const BEASTS = [
    `beast_lon_rung`,
    `beast_soi_xam`,
    `beast_tho_nui`,
    `beast_huou_nui`,
    `beast_khi_da`,
    `beast_thach_giap`,
    `beast_gau_nui`,
    `beast_ung_nui`,
    `beast_doi_hang`
];
const s = [
    `walk`,
    `melee`,
    `hit`,
    `death`
];
const c = [
    0,
    2,
    4,
    6
];
const l = 32;
export class XemThuScene extends a.Scene {
    index;
    constructor(){
        super(`xem_thu`);
    }
    init(e) {
        this.index = e.index;
    }
    preload() {
        r(this, this.index, BEASTS);
    }
    create() {
        n(this, this.index, BEASTS);
        let e = 4.2;
        let t = 5.5;
        let r = [];
        BEASTS.forEach((vid, a)=>{
            let o = 3 + a * 3.4;
            this.add.text(8, o * l - 30, vid, {
                fontFamily: `system-ui`,
                fontSize: `13px`,
                color: `#e8e2d0`
            });
            let views = c.map((r, a)=>{
                let s = new t_1(this, this.index, vid, ``, l);
                s.setPosition(t + a * e, o);
                s.setPose(`walk`, r);
                return s;
            });
            r.push({
                views,
                vid
            });
        });
        c.forEach((n, r)=>this.add.text((t + r * e) * l - 20, 6, [
                `đông`,
                `nam`,
                `tây (lật)`,
                `bắc`
            ][r], {
                fontFamily: `system-ui`,
                fontSize: `13px`,
                color: `#d9b45a`
            }));
        let a = this.add.text(8, 6, ``, {
            fontFamily: `system-ui`,
            fontSize: `14px`,
            color: `#f2ead3`
        });
        let u = 0;
        let callback = ()=>{
            let e = s[u % s.length];
            a.setText(`động tác: ${e}`);
            for (let t of r){
                t.views.forEach((t, n)=>t.setPose(e, c[n]));
            }
            u++;
        };
        callback();
        this.time.addEvent({
            delay: 2400,
            loop: true,
            callback
        });
        this.cameras.main.setBackgroundColor(`#3a4232`);
    }
}
export function startXemThu(parent, index) {
    return new a.Game({
        type: a.AUTO,
        parent,
        backgroundColor: `#3a4232`,
        pixelArt: true,
        scale: {
            mode: a.Scale.RESIZE,
            width: window.innerWidth,
            height: window.innerHeight
        },
        scene: [],
        callbacks: {
            postBoot: (e)=>{
                e.scene.add(`xem_thu`, XemThuScene, true, {
                    index
                });
            }
        }
    });
}
