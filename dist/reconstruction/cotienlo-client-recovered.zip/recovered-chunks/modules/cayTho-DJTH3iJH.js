(()=>{
    let e = [
        `#120c07`,
        `#251810`,
        `#352416`,
        `#46321f`,
        `#5c4429`,
        `#715637`
    ];
    let t = {
        vlh: [
            `#0d150b`,
            `#14250f`,
            `#1d3816`,
            `#2b4f1d`,
            `#3f6b26`,
            `#5a8a30`,
            `#83ab44`
        ],
        kc: [
            `#0c170c`,
            `#132813`,
            `#1c3d1b`,
            `#2a5524`,
            `#3e732d`,
            `#5a9238`,
            `#86b44c`
        ],
        kho: [
            `#141a0e`,
            `#1f2914`,
            `#2c3a1a`,
            `#3e4f22`,
            `#53652a`,
            `#6c7c34`,
            `#8a9442`
        ],
        thu: [
            `#1c0e08`,
            `#36160c`,
            `#561f10`,
            `#792c14`,
            `#9c3f18`,
            `#bf5a22`,
            `#d97f30`
        ]
    };
    function n(e, t) {
        return e.map((n, r)=>{
            if (r === 0 || t === 0) {
                return n;
            }
            let [i, a, o] = s(n);
            let c = r / (e.length - 1) * Math.abs(t);
            let [l, u, d] = t > 0 ? [
                26,
                12,
                -10
            ] : [
                -12,
                -8,
                6
            ];
            let f = (e, t)=>Math.max(0, Math.min(255, Math.round(e + t * c)));
            return `#${[
                f(i, l),
                f(a, u),
                f(o, d)
            ].map((e)=>e.toString(16).padStart(2, `0`)).join(``)}`;
        });
    }
    function r(e, t) {
        return n(e, t > 0.3 ? t - 0.55 : t + 0.5);
    }
    function i(e) {
        let t = e >>> 0;
        return ()=>{
            t = t + 1831565813 >>> 0;
            let e = t;
            e = Math.imul(e ^ e >>> 15, e | 1);
            e ^= e + Math.imul(e ^ e >>> 7, e | 61);
            return ((e ^ e >>> 14) >>> 0) / 4294967296;
        };
    }
    function a(e, t, n) {
        let r = Math.imul(e ^ 668265261, 2246822507) ^ Math.imul(t + 374761393, 3266489909) ^ Math.imul(n, 2654435761);
        r = Math.imul(r ^ r >>> 15, 739982445);
        r = Math.imul(r ^ r >>> 13, 695872825);
        return ((r ^ r >>> 16) >>> 0) / 4294967296;
    }
    let o = [
        0,
        8,
        2,
        10,
        12,
        4,
        14,
        6,
        3,
        11,
        1,
        9,
        15,
        7,
        13,
        5
    ].map((e)=>e / 16);
    function s(e) {
        let t = parseInt(e.slice(1), 16);
        return [
            t >> 16 & 255,
            t >> 8 & 255,
            t & 255
        ];
    }
    let c = (e, t, n)=>Math.max(t, Math.min(n, e));
    let l = (e, t, n)=>{
        let r = c((n - e) / (t - e), 0, 1);
        return r * r * (3 - 2 * r);
    };
    function u(e, t, n, r, i, o, than, c, hat) {
        let u = (r, i, a)=>{
            if (r >= 0 && r < t && i >= 0 && i < n) {
                e[i * t + r] = a;
            }
        };
        let d = Math.floor(i);
        let f = (c() - 0.5) * 2.4;
        let p = [
            i + (o - i) * (0.3 + c() * 0.25),
            i + (o - i) * (0.55 + c() * 0.15)
        ];
        for(let e = d; e <= o; e++){
            let t = (e - i) / Math.max(1, o - i);
            let n = Math.max(2, Math.round(than * (0.68 + 0.32 * t) + (t > 0.78 ? ((t - 0.78) / 0.22) ** 1.7 * than * 1.2 : 0)));
            let c = Math.round(r - n / 2 + f * (1 - t) ** 2);
            for(let i = c; i < c + n; i++){
                let o = (i - c + 0.5) / n;
                let s = o < 0.2 ? 5 : o < 0.42 ? 4 : o < 0.66 ? 3 : o < 0.86 ? 2 : 1;
                let d = Math.round(i - (r + f * (1 - t) ** 2) + 50);
                if (a(d, Math.floor((e + a(d, 1, hat) * 9) / 7), hat) < 0.32 && s > 1) {
                    --s;
                }
                for (let t of p){
                    if (Math.abs(e - t) < 1.5 && Math.abs(o - 0.55) < 0.14) {
                        s = 1;
                    }
                }
                u(i, e, s);
            }
            u(c + n, e, 0);
            if (t > 0.5) {
                u(c - 1, e, 2);
            }
        }
        for (let e of [
            -1,
            1
        ]){
            let t = 2 + Math.floor(c() * 2);
            for(let i = 0; i < t; i++){
                let t = than * (0.45 + c() * 0.6);
                let a = Math.max(Math.round(n * 0.9) + 1, o - 2 - Math.floor(c() * 4));
                let l = 0.28 + i * 0.14 + c() * 0.1;
                for(let n = 0; n < t; n++){
                    let t = Math.round(r + e * (than * 0.5 + n));
                    let i = Math.round(a + n * l);
                    if (i > o + 1) {
                        break;
                    }
                    u(t, i, e < 0 ? 4 : 2);
                    u(t, i + 1, 0);
                    u(t, i - 1, e < 0 ? 5 : 3);
                }
            }
        }
    }
    function d(e, t, n, tamX, i, a, o, s, c) {
        let l = Math.ceil(Math.hypot(a - tamX, o - i));
        for(let u = 0; u <= l; u++){
            let d = u / Math.max(1, l);
            let f = tamX + (a - tamX) * d;
            let p = i + (o - i) * d;
            let ee = s + (c - s) * d;
            let m = Math.max(0.5, ee / 2);
            for(let r = Math.floor(p - m); r <= Math.ceil(p + m); r++){
                for(let i = Math.floor(f - m); i <= Math.ceil(f + m); i++){
                    if (i < 0 || r < 0 || i >= t || r >= n || Math.hypot(i + 0.5 - f, r + 0.5 - p) > m + 0.2) {
                        continue;
                    }
                    let a = r + 0.5 < p - m * 0.2;
                    e[r * t + i] = a ? 3 : i + 0.5 < f ? 2 : 1;
                }
            }
        }
    }
    function f(kieu, t, n, r) {
        let i = (e)=>1 + (r() - 0.5) * e;
        switch(kieu){
            case `tan_lon`:
                return {
                    tamX: t / 2 + (r() - 0.5) * 4,
                    yTren: n * 0.04,
                    yDuoi: n * 0.67 * i(0.06),
                    rx: t * 0.46 * i(0.05),
                    o: 5,
                    than: Math.max(8, t * 0.12)
                };
            case `tan_vua`:
                return {
                    tamX: t / 2 + (r() - 0.5) * 4,
                    yTren: n * 0.06,
                    yDuoi: n * 0.65 * i(0.08),
                    rx: t * 0.46 * i(0.06),
                    o: 4.5,
                    than: Math.max(7, t * 0.11)
                };
            case `non`:
                return {
                    tamX: t / 2 + (r() - 0.5) * 3,
                    yTren: n * 0.05,
                    yDuoi: n * 0.67 * i(0.08),
                    rx: t * 0.4 * i(0.08),
                    o: 4,
                    than: Math.max(5, t * 0.085)
                };
            case `bui`:
                return {
                    tamX: t / 2,
                    yTren: n * 0.16,
                    yDuoi: n * 0.94,
                    rx: t * 0.47,
                    o: 3.5,
                    than: 0
                };
        }
    }
    function p(e, t) {
        let n = [
            ...e
        ].sort((e, t)=>e - t);
        return n[Math.min(n.length - 1, Math.max(0, Math.floor(t * (n.length - 1))))] ?? 0;
    }
    function ee(e, t, n) {
        if (n >= 2) {
            return Math.max(e.yDuoi, t * 0.83);
        }
        if (n >= 1) {
            return e.yDuoi + t * 0.1;
        }
        return e.yDuoi;
    }
    function m(e, fx, fy, ax, ay, toi = 0) {
        return {
            fx,
            fy,
            ax,
            ay,
            toi,
            phu: e() < 0.3,
            pha: [
                e() * 6.3,
                e() * 6.3
            ],
            bien: [
                0.05 + e() * 0.07,
                0.03 + e() * 0.05
            ]
        };
    }
    function te(kieu, t, n, r) {
        let i = (e)=>(n() - 0.5) * e;
        let a = [];
        let o = r;
        if (kieu === `bui`) {
            a.push(m(n, -0.42 + i(0.1), 0.58, 0.55, 0.5), m(n, 0.4 + i(0.1), 0.6, 0.56, 0.48), m(n, o * 0.2 + i(0.2), 0.36, 0.6, 0.5));
            if (t === 2) {
                a.push(m(n, 0.6 * Math.sign(o || 1), 0.3, 0.3, 0.3));
            }
            return a;
        }
        if (t === 1) {
            let t = kieu === `tan_lon` ? 3 : kieu === `non` ? 4 : 3;
            for(let r = 0; r < t; r++){
                let s = r / (t - 1);
                let c = (kieu === `non` ? 0.62 : 0.5) + s * 0.42;
                let l = 0.16 + s * 0.66 + i(0.04);
                let u = o * (1 - s) * 0.28 + (r % 2 ? 0.08 : -0.08) + i(0.06);
                let d = (kieu === `non` ? 0.13 : 0.16) + i(0.03);
                a.push(m(n, u - c * 0.42, l + i(0.03), c * 0.66, d, s * 0.1), m(n, u + c * 0.42, l + i(0.03), c * 0.66, d, s * 0.1));
                if (c > 0.75) {
                    a.push(m(n, u + i(0.2), l - d * 0.35, c * 0.5, d * 0.9, s * 0.08));
                }
            }
            return a;
        }
        if (t === 2) {
            let t = kieu === `non` ? 7 : 9;
            for(let e = 0; e < t; e++){
                let r = e / t * Math.PI * 2 + n() * 0.45;
                let i = e === 0 ? 0.1 : 0.55 + n() * 0.3;
                let s = 0.5 + Math.sin(r) * i * 0.4 - 0.04;
                a.push(m(n, o * (1 - s) * 0.3 + Math.cos(r) * i * 0.74, s, 0.24 + n() * 0.1, 0.14 + n() * 0.04, s * 0.15));
            }
            a.push(m(n, o * 0.3 + i(0.2), 0.13, 0.3, 0.13));
            return a;
        }
        if (kieu === `non`) {
            a.push(m(n, i(0.2), 0.78, 0.7, 0.2, 0.12), m(n, -0.35 + i(0.15), 0.56, 0.62, 0.2, 0.06), m(n, 0.38 + i(0.15), 0.5, 0.6, 0.2, 0.04), m(n, o * 0.3 + i(0.15), 0.3, 0.64, 0.2), m(n, o * 0.4 + i(0.1), 0.12, 0.42, 0.12));
            return a;
        }
        a.push(m(n, i(0.3), 0.76, 0.6 + i(0.1), 0.25, 0.14), m(n, -0.48 + i(0.12), 0.52 + i(0.06), 0.5 + i(0.1), 0.28, 0.06), m(n, 0.48 + i(0.12), 0.5 + i(0.06), 0.5 + i(0.1), 0.28, 0.06), m(n, o * 0.3 + i(0.15), 0.25, 0.56 + i(0.08), 0.26));
        if (n() < 0.75) {
            a.push(m(n, (o >= 0 ? 0.5 : -0.5) + i(0.1), 0.24 + i(0.06), 0.36, 0.2, 0.02));
        }
        return a;
    }
    function h(kieu, w_1, h, hat, _ = t.vlh, ne = e, v = {}) {
        let y = Math.max(0, Math.min(2, Math.round(v.che ?? 0)));
        let b = Math.max(0, Math.min(2, Math.round(v.loai ?? 0)));
        let x = v.laPhu ?? r(_, 0);
        let S = i(hat);
        let C = f(kieu, w_1, h, S);
        let w = (S() - 0.5) * 2;
        let T = te(kieu, b, S, w);
        let E = w_1 * h;
        let D = Math.round(h * 0.93);
        let O = ee(C, h, y);
        let k = C.yDuoi - C.yTren;
        let A = i(hat * 7 + 13 + y * 101);
        if (y >= 1 && kieu !== `bui`) {
            T.unshift(m(A, w * 0.15, 0.5, y >= 2 ? 0.8 : 0.62, y >= 2 ? 0.42 : 0.3, 0.3));
            let e = (O - C.yTren) / k;
            let t = y >= 2 ? 3 : 2;
            for(let n = 0; n < t; n++){
                let r = n / (t - 1) * 2 - 1;
                let i = (e - 0.62) * 0.5 + 0.06;
                T.unshift(m(A, r * 0.5 + (A() - 0.5) * 0.12, e - i * 0.95, 0.5 + A() * 0.12, i, 0.22 + 0.06 * y));
            }
        }
        let j = y >= 1 && kieu !== `bui` ? y >= 2 ? 4 : 3 : 0;
        let re = T.slice(j).sort((e, t)=>t.fy + t.ay * 0.5 - (e.fy + e.ay * 0.5));
        let M = [
            ...T.slice(0, j),
            ...re
        ];
        let ie = M.map((e)=>{
            let t = e.ax * C.rx;
            let cx = C.tamX + e.fx * C.rx;
            let r = Math.abs(cx - w_1 / 2) + t * 1.18 - (w_1 / 2 - 1);
            if (r > 0) {
                t -= r * 0.6;
                cx -= Math.sign(cx - w_1 / 2) * r * 0.4;
            }
            let i = e.ay * k;
            let cy = C.yTren + e.fy * k;
            return {
                cx,
                cy,
                ax: Math.max(2, t),
                ay: Math.max(2, i)
            };
        });
        let N = b === 2 ? Math.max(2.6, C.o * 0.7) : C.o;
        let ae = hat * 3 + 1;
        let P = Math.ceil(w_1 / N) + 2;
        let oe = Math.ceil(h / N) + 2;
        let F = new Float32Array(P * oe * 3);
        for(let e = 0; e < oe; e++){
            for(let t = 0; t < P; t++){
                let n = a(t - 1, e - 1, ae);
                let r = (e * P + t) * 3;
                F[r] = (t - 1 + 0.15 + 0.7 * n) * N;
                F[r + 1] = (e - 1 + 0.15 + 0.7 * a(e - 1, t - 1, ae + 5)) * N;
                F[r + 2] = n;
            }
        }
        let se = (e, t)=>{
            let n = Math.floor(e / N) + 1;
            let r = Math.floor(t / N) + 1;
            let i = 1000000000;
            let a = 0;
            let o = 0;
            let s = 0;
            for(let c = r - 1; c <= r + 1; c++){
                for(let r = n - 1; r <= n + 1; r++){
                    let n = (c * P + r) * 3;
                    let l = F[n];
                    let u = F[n + 1];
                    let d = (e - l) ** 2 + (t - u) ** 2;
                    if (d < i) {
                        i = d;
                        a = l;
                        o = u;
                        s = F[n + 2];
                    }
                }
            }
            return [
                Math.sqrt(i) / N,
                (e - a) / N,
                (t - o) / N,
                s
            ];
        };
        let I = new Int16Array(E).fill(-1);
        let L = new Float32Array(E);
        let R = new Float32Array(E);
        let z = new Float32Array(E);
        let B = new Float32Array(E);
        let V = new Float32Array(E);
        let H = new Float32Array(E);
        for(let e = 0; e < h; e++){
            for(let t = 0; t < w_1; t++){
                let n = e * w_1 + t;
                let [r, i, a, o] = se(t + 0.5, e + 0.5);
                z[n] = r;
                B[n] = i;
                V[n] = a;
                H[n] = o;
            }
        }
        M.forEach((e, t)=>{
            let n = ie[t];
            let r = Math.max(0, Math.floor(n.cx - n.ax * 1.25));
            let i = Math.min(w_1 - 1, Math.ceil(n.cx + n.ax * 1.25));
            let a = Math.max(0, Math.floor(n.cy - n.ay * 1.25));
            let o = Math.min(h - 1, Math.ceil(n.cy + n.ay * 1.25));
            for(let s = a; s <= o; s++){
                for(let a = r; a <= i; a++){
                    let r = s * w_1 + a;
                    let i = (a + 0.5 - n.cx) / n.ax;
                    let o = (s + 0.5 - n.cy) / n.ay;
                    let l = Math.atan2(o, i);
                    let u = 1 + e.bien[0] * Math.sin(2 * l + e.pha[0]) + e.bien[1] * Math.sin(3 * l + e.pha[1]) + (0.5 - z[r]) * 0.26 + (H[r] - 0.5) * 0.12;
                    if (!(i * i + o * o > u * u)) {
                        I[r] = t;
                        L[r] = i;
                        R[r] = o;
                    }
                }
            }
        });
        let U = b === 2 && y < 2 ? 1 : 2;
        let ce = (e)=>I[e] >= 0;
        let W = (e, t)=>{
            let n = new Uint8Array(E);
            let r = new Uint8Array(E);
            for(let r = 0; r < h; r++){
                for(let i = 0; i < w_1; i++){
                    let a = +!t;
                    for(let n = -U; n <= U; n++){
                        let o = i + n;
                        let s = o < 0 || o >= w_1 ? 0 : e[r * w_1 + o];
                        a = t ? a | s : a & s;
                    }
                    n[r * w_1 + i] = a;
                }
            }
            for(let e = 0; e < h; e++){
                for(let i = 0; i < w_1; i++){
                    let a = +!t;
                    for(let r = -U; r <= U; r++){
                        let o = e + r;
                        let s = o < 0 || o >= h ? 0 : n[o * w_1 + i];
                        a = t ? a | s : a & s;
                    }
                    r[e * w_1 + i] = a;
                }
            }
            return r;
        };
        let G = new Uint8Array(E);
        for(let e = 0; e < E; e++){
            G[e] = +!!ce(e);
        }
        let le = W(W(G, true), false);
        for(let e = 0; e < E; e++){
            if (!G[e] && le[e]) {
                I[e] = -2;
            }
        }
        let K = new Int8Array(E).fill(-1);
        let ue = i(hat * 31 + 7);
        let de = C.yDuoi - k * 0.3;
        let q = [];
        if (C.than > 0) {
            u(K, w_1, h, Math.round(C.tamX), de, D, C.than, ue, hat);
            let e = re.map((e)=>({
                    x: C.tamX + e.fx * C.rx * 0.8,
                    y: C.yTren + e.fy * k
                })).filter((e)=>e.y > C.yTren + k * 0.2 && e.y < C.yDuoi - k * 0.05);
            let t = Math.min(e.length, b === 2 ? 5 : 3);
            for(let n = 0; n < t; n++){
                let r = e[Math.floor(n / t * e.length)];
                let i = de + k * (0.12 + ue() * 0.12);
                q.push([
                    C.tamX,
                    i,
                    r.x,
                    r.y
                ]);
                d(K, w_1, h, C.tamX, i, r.x, r.y, C.than * 0.55, Math.max(1.4, C.than * 0.18));
            }
        }
        let fe = kieu === `bui` || y >= 2 ? 0 : (b === 2 ? 4 : 1) - (y >= 1 ? b === 2 ? 2 : 1 : 0);
        let J = i(hat * 17 + 3);
        for(let e = 0; e < Math.max(0, fe); e++){
            let e = q.length ? q[Math.floor(J() * q.length)] : null;
            let t = 0.4 + J() * 0.35;
            let r = e ? e[0] + (e[2] - e[0]) * t : C.tamX + (J() - 0.5) * C.rx;
            let i = e ? e[1] + (e[3] - e[1]) * t : C.yTren + k * (0.55 + J() * 0.2);
            let a = (b === 2 ? 3 : 5) + J() * 3 * (kieu === `non` ? 0.5 : 1);
            let o = (b === 2 ? 2.4 : 3) + J() * 1.8;
            for(let e = Math.floor(i - o - 2); e <= i + o + 2; e++){
                for(let t = Math.floor(r - a - 2); t <= r + a + 2; t++){
                    if (t < 0 || e < 0 || t >= w_1 || e >= h) {
                        continue;
                    }
                    let n = e * w_1 + t;
                    if (((t + 0.5 - r) / a) ** 2 + ((e + 0.5 - i) / o) ** 2 <= 1 + (z[n] - 0.5) * 0.9) {
                        I[n] = -1;
                    }
                }
            }
        }
        let Y = [
            -0.5,
            -0.66,
            0.56
        ];
        let pe = Math.hypot(Y[0], Y[1], Y[2]);
        let X = new Float32Array(E);
        let me = new Float32Array(E);
        let Z = [];
        let he = C.yTren + (O - C.yTren) / 2;
        let ge = (O - C.yTren) / 2;
        for(let e = 0; e < E; e++){
            let t = I[e];
            if (t === -1) {
                continue;
            }
            let n = e % w_1;
            let r = (e - n) / w_1;
            let i;
            if (t === -2) {
                i = -0.2;
            } else {
                let a = M[t];
                let o = L[e] * 0.92;
                let s = R[e] * 0.92;
                let l = Math.sqrt(Math.max(0, 1 - o * o - s * s));
                i = Math.max(0, (o * Y[0] + s * Y[1] + l * Y[2]) / pe);
                i = 0.1 + 0.9 * i - a.toi;
                let u = (e)=>{
                    let i = r - e;
                    let a = n - Math.round(e * 0.35);
                    if (i < 0 || a < 0 || a >= w_1) {
                        return false;
                    }
                    return I[i * w_1 + a] > t;
                };
                if (u(1) || u(2)) {
                    i -= 0.42;
                } else if (u(3) || u(4)) {
                    i -= 0.26;
                } else if (u(5)) {
                    i -= 0.12;
                }
                let d = r + 1 < h ? I[e + w_1] : -1;
                if (d !== t && d !== -1 && R[e] > 0.3) {
                    i -= 0.18;
                }
            }
            let a = (n - C.tamX) / C.rx;
            let o = (r - he) / ge;
            i += -0.1 * a - 0.16 * o;
            if (y >= 1 && r > C.yDuoi) {
                i -= 0.15 * Math.min(1, (r - C.yDuoi) / (h * 0.08));
            }
            me[e] = i;
            let s = l(0.42, 0.78, i);
            i += s * (0.2 * (0.45 - z[e]) + 0.22 * (-0.6 * B[e] - 0.8 * V[e]) + (H[e] - 0.5) * 0.08);
            X[e] = i;
            Z.push(i);
        }
        let _e = p(Z, 0.03);
        let ve = p(Z, 0.992);
        for(let e = 0; e < E; e++){
            if (I[e] !== -1) {
                X[e] = Math.min(1, Math.max(0, (X[e] - _e) / Math.max(0.000001, ve - _e))) ** 1.15;
            }
        }
        let ye = _.map(s);
        let be = x.map(s);
        let xe = ne.map(s);
        let px = new Uint8ClampedArray(E * 4);
        let Se = (e, t)=>e < 0 || t < 0 || e >= w_1 || t >= h || I[t * w_1 + e] === -1 && K[t * w_1 + e] < 0;
        let $ = (e, t)=>e < 0 || t < 0 || e >= w_1 || t >= h || I[t * w_1 + e] === -1;
        for(let e = 0; e < h; e++){
            for(let t = 0; t < w_1; t++){
                let n = e * w_1 + t;
                let r = null;
                let i = I[n];
                if (i !== -1) {
                    let a = X[n];
                    let s = o[(e & 3) * 4 + (t & 3)];
                    let c = 1 + Math.floor(Math.min(0.999, a) * 5 + (s - 0.5) * 0.14);
                    if (c >= 5 && z[n] < 0.42 && B[n] + V[n] < -0.05 && me[n] > 0.6) {
                        c = 6;
                    }
                    if ($(t, e + 1)) {
                        c = Se(t, e + 1) && Se(t, e + 2) && a < 0.3 && z[n] > 0.5 ? -1 : 0;
                    } else if ($(t + 1, e)) {
                        c = Math.max(0, Math.min(c - 2, 1));
                    } else if ($(t, e - 1) && $(t - 1, e)) {
                        c = Math.min(6, Math.max(c, 2) + 1);
                    }
                    c = Math.max(-1, Math.min(6, c));
                    if (c >= 0) {
                        r = (i >= 0 && M[i].phu ? be : ye)[c];
                    }
                }
                if (!r && K[n] >= 0) {
                    let t = K[n];
                    if (t > 0 && e - 4 >= 0 && I[n - w_1 * 4] !== -1) {
                        --t;
                    }
                    if (t > 0 && e - 8 >= 0 && I[n - w_1 * 8] !== -1) {
                        --t;
                    }
                    if (t > 0 && e < O && I[n] === -1) {
                        t = Math.max(1, t - 1);
                    }
                    if (t > 0) {
                        t = Math.max(1, t - y);
                    }
                    r = xe[t];
                }
                if (r) {
                    px[n * 4] = r[0];
                    px[n * 4 + 1] = r[1];
                    px[n * 4 + 2] = r[2];
                    px[n * 4 + 3] = 255;
                }
            }
        }
        return {
            w: w_1,
            h,
            px
        };
    }
    let g = {
        prop_cay_tan_1: {
            kieu: `tan_lon`,
            w: 112,
            h: 128
        },
        prop_cay_tan_2: {
            kieu: `tan_vua`,
            w: 96,
            h: 112
        },
        prop_cay_non: {
            kieu: `non`,
            w: 72,
            h: 96
        },
        prop_cay_tan_thu: {
            kieu: `tan_vua`,
            w: 96,
            h: 112,
            thu: true
        },
        prop_bui_1: {
            kieu: `bui`,
            w: 64,
            h: 48
        }
    };
    let _ = [
        `a`,
        `b`,
        `c`
    ];
    let ne = {
        zone_vu_linh_ha: `vlh`,
        zone_khe_coc: `kc`,
        zone_ta_gia_trai: `kc`,
        zone_ben_thuong: `kc`,
        zone_mo_cu: `kho`
    };
    let v = (e, t, n, r = 0)=>`cay_code_${e}_${t.replace(/^prop_/, ``)}_${n}${r ? `_k${r}` : ``}`;
    let y = {};
    let b = [
        0,
        1,
        -1.3
    ];
    for (let e of new Set(Object.values(ne))){
        for (let [t, n] of Object.entries(g)){
            _.forEach((r, loai)=>{
                for (let che of n.kieu === `bui` ? [
                    0
                ] : [
                    0,
                    1,
                    2
                ]){
                    y[v(e, t, r, che)] = {
                        la: n.thu ? `thu` : e,
                        kieu: n.kieu,
                        w: n.w,
                        h: n.h,
                        hat: 7919 * (loai + 1) + n.w * 31 + n.h,
                        lech: n.thu ? b[loai] * 0.5 : b[loai],
                        che,
                        loai
                    };
                }
            });
        }
    }
    let x = new Map;
    function S(i) {
        let a = y[i];
        if (!a) {
            return null;
        }
        let o = x.get(i);
        if (!o) {
            o = h(a.kieu, a.w, a.h, a.hat, n(t[a.la], a.lech), e, {
                che: a.che,
                loai: a.loai,
                laPhu: r(t[a.la], a.lech)
            });
            x.set(i, o);
        }
        return o;
    }
    let C = self;
    let w = [];
    let T = new Set;
    let E = false;
    function D() {
        let id = w.shift();
        if (id === undefined) {
            E = false;
        } else {
            try {
                let t = S(id);
                if (!t) {
                    C.postMessage({
                        id,
                        loi: `không có trong bảng cây code`
                    });
                } else {
                    let n = t.px.slice();
                    C.postMessage({
                        id,
                        w: t.w,
                        h: t.h,
                        px: n.buffer
                    }, [
                        n.buffer
                    ]);
                }
            } catch (error) {
                C.postMessage({
                    id,
                    loi: String(error?.message ?? error)
                });
            }
            setTimeout(D, 0);
        }
    }
    C.onmessage = (e)=>{
        let { ids, uu } = e.data;
        for (let e of ids){
            if (T.has(e)) {
                let t = w.indexOf(e);
                if (uu && t > 0) {
                    w.splice(t, 1);
                    w.unshift(e);
                }
            } else {
                T.add(e);
                if (uu) {
                    w.unshift(e);
                } else {
                    w.push(e);
                }
            }
        }
        if (!E && w.length) {
            E = true;
            setTimeout(D, 0);
        }
    };
})();
