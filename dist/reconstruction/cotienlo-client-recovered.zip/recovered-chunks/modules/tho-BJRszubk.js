(function() {
    function e(e) {
        let [t, n, r, i] = Array.isArray(e) ? e : [
            2654435769,
            608135816,
            3084996962,
            e >>> 0
        ];
        let next = ()=>{
            t >>>= 0;
            n >>>= 0;
            r >>>= 0;
            i >>>= 0;
            let e = t + n | 0;
            t = n ^ n >>> 9;
            n = r + (r << 3) | 0;
            r = r << 21 | r >>> 11;
            i = i + 1 | 0;
            e = e + i | 0;
            r = r + e | 0;
            return (e >>> 0) / 4294967296;
        };
        if (!Array.isArray(e)) {
            for(let e = 0; e < 12; e++){
                next();
            }
        }
        return {
            next,
            int: (e, t)=>e + Math.floor(next() * (t - e + 1)),
            chance: (e)=>next() < e,
            state: ()=>[
                    t >>> 0,
                    n >>> 0,
                    r >>> 0,
                    i >>> 0
                ]
        };
    }
    let t = {
        chu_ky_phut: 60,
        rang_dong_phut: 4,
        ngay_phut: 26,
        hoang_hon_phut: 4,
        dem_phut: 26,
        do_toi_toi_da: 0.55
    };
    function n(e) {
        let t = e.rang_dong_phut + e.ngay_phut + e.hoang_hon_phut + e.dem_phut;
        return {
            chuKyMs: e.chu_ky_phut * 60000,
            rangDong: e.rang_dong_phut / t,
            ngay: e.ngay_phut / t,
            hoangHon: e.hoang_hon_phut / t,
            dem: e.dem_phut / t,
            doToiMax: e.do_toi_toi_da
        };
    }
    n(t);
    let r = new Map;
    function i(e) {
        for (let t of e){
            r.set(t.id, t);
        }
    }
    function a(e) {
        return r.has(e);
    }
    function o(e) {
        let t = r.get(e);
        if (!t) {
            throw Error(`chưa nạp vùng ${e}`);
        }
        return t;
    }
    function s(e, t, n, r = 0.35) {
        if (t < r || n < r || t > e.rong - r || n > e.cao - r) {
            return true;
        }
        for (let i of e.chan){
            let e = Math.min(i.x + i.w, Math.max(i.x, t));
            let a = Math.min(i.y + i.h, Math.max(i.y, n));
            if ((t - e) ** 2 + (n - a) ** 2 < r * r) {
                return true;
            }
        }
        return false;
    }
    [
        ...Array(25).keys()
    ].sort((e, t)=>{
        let n = (e)=>(e % 5 - 2) ** 2 + (Math.floor(e / 5) - 2) ** 2;
        return n(e) - n(t);
    })[0];
    new class {
        f;
        a = new Int32Array(1024);
        size = 0;
        constructor(e){
            this.f = e;
        }
        clear(e) {
            this.f = e;
            this.size = 0;
        }
        push(e) {
            if (this.size === this.a.length) {
                let e = new Int32Array(this.a.length * 2);
                e.set(this.a);
                this.a = e;
            }
            let t = this.a;
            let n = this.f;
            let r = n[e];
            let i = this.size++;
            while(i > 0){
                let e = i - 1 >> 1;
                let a = t[e];
                if (n[a] <= r) {
                    break;
                }
                t[i] = a;
                i = e;
            }
            t[i] = e;
        }
        pop() {
            let e = this.a;
            let t = this.f;
            let n = e[0];
            let r = e[--this.size];
            if (this.size) {
                let n = this.size;
                let i = t[r];
                let a = 0;
                while(true){
                    let r = 2 * a + 1;
                    if (r >= n) {
                        break;
                    }
                    let o = r + 1;
                    let s = o < n && t[e[o]] < t[e[r]] ? o : r;
                    if (t[e[s]] >= i) {
                        break;
                    }
                    e[a] = e[s];
                    a = s;
                }
                e[a] = r;
            }
            return n;
        }
    }(new Float32Array);
    new Intl.DateTimeFormat(`en-GB`, {
        timeZone: `Asia/Ho_Chi_Minh`,
        year: `numeric`,
        month: `2-digit`,
        day: `2-digit`,
        hour: `2-digit`,
        minute: `2-digit`,
        weekday: `short`,
        hourCycle: `h23`
    });
    [
        ...`canh_gioi.luu_phai_bac.nhiem_vu.dem.giet_tong.giet.thu_pho.thap_tang.thu_vuong.bong_thang.sat_chieu.bat_da_co.vcl_luyen.vcl_sao.thuan_thuc.co_phuong.thu_nha.thu_nha_cap.thu_nha_trung_thanh.thu_nha_cuoi.nghe_hoc.nghe_bac.ca_loai.ca_dai.gia_vien_cap.ho_cu_tong_cap.loi_dai_thang.loi_dai_chuoi.ban_be.su_do.ket_nghia.bang_cong.danh_vong.kham_pha.tram_mo.lore.dang_nhap.diem_mua.thu_trieu`.split(`.`)
    ];
    let c = (e)=>{
        let t = 2166136261;
        for(let n = 0; n < e.length; n++){
            t = Math.imul(t ^ e.charCodeAt(n), 16777619);
        }
        return t >>> 0;
    };
    function l(e, t, n) {
        let r = Math.imul(e, 374761393) + Math.imul(t, 668265263) + Math.imul(n, 982451653);
        r = Math.imul(r ^ r >>> 13, 1274126177);
        return ((r ^ r >>> 16) >>> 0) / 4294967296;
    }
    function u(e, t, n) {
        let r = Math.imul(e ^ 1540483477, 1597334677) + Math.imul(t ^ 668265261, 3812015801) + Math.imul(n ^ 374761393, 2246822519);
        r = Math.imul(r ^ r >>> 15, 2654435761);
        return ((r ^ r >>> 13) >>> 0) / 4294967296;
    }
    function d(e, t, n) {
        let r = Math.floor(e);
        let i = Math.floor(t);
        let a = e - r;
        let o = t - i;
        let s = a * a * (3 - 2 * a);
        let c = o * o * (3 - 2 * o);
        let u = l(r, i, n);
        let d = l(r + 1, i, n);
        let f = l(r, i + 1, n);
        let p = l(r + 1, i + 1, n);
        return u + (d - u) * s + (f - u) * c + (u - d - f + p) * s * c;
    }
    function f(e, t, n, r = 3) {
        let i = 0;
        let a = 1;
        let o = 0;
        let s = 1;
        for(let c = 0; c < r; c++){
            i += d(e * s, t * s, n + c * 7919) * a;
            o += a;
            a *= 0.5;
            s *= 2.03;
        }
        return i / o;
    }
    let p = ()=>({
            d1: 0,
            d2: 0,
            px: 0,
            py: 0,
            i: 0,
            j: 0,
            px2: 0,
            py2: 0,
            i2: 0,
            j2: 0
        });
    function m(e, t, n, r, i, a) {
        let o = Math.floor(e);
        let s = Math.floor(t);
        let c = 9;
        let d = 9;
        let f = 0;
        let p = 0;
        let m = 0;
        let h = 0;
        let g = 0;
        let _ = 0;
        let v = 0;
        let y = 0;
        for(let a = s - 1; a <= s + 1; a++){
            for(let s = o - 1; s <= o + 1; s++){
                let o = s + 0.5 + (l(s, a, n) - 0.5) * r;
                let b = a + 0.5 + (u(s, a, n) - 0.5) * r;
                let x = e - o;
                let S = (t - b) / i;
                let C = x * x + S * S;
                if (C < c) {
                    d = c;
                    g = f;
                    _ = p;
                    v = m;
                    y = h;
                    c = C;
                    f = o;
                    p = b;
                    m = s;
                    h = a;
                } else if (C < d) {
                    d = C;
                    g = o;
                    _ = b;
                    v = s;
                    y = a;
                }
            }
        }
        a.d1 = Math.sqrt(c);
        a.d2 = Math.sqrt(d);
        a.px = f;
        a.py = p;
        a.i = m;
        a.j = h;
        a.px2 = g;
        a.py2 = _;
        a.i2 = v;
        a.j2 = y;
        return a;
    }
    function h(e, t, n) {
        let r = Math.min(1, Math.max(0, (n - e) / (t - e)));
        return r * r * (3 - 2 * r);
    }
    let g = (e, t = 0, n = 1)=>{
        if (e < t) {
            return t;
        }
        if (e > n) {
            return n;
        }
        return e;
    };
    let _ = {
        dai: 1,
        daiMin: 0.6,
        daiMax: 2.4,
        tu: [
            0.35,
            0.9
        ],
        het: [
            2.4,
            3.6
        ],
        dam: 0.42,
        ao: 0.3,
        aoRong: 0.35,
        nuoc: 0.5,
        vien: 0.35,
        ben: 0.36,
        benDai: [
            0.45,
            3.2
        ]
    };
    let v = {
        da: 1,
        nuoc: 2,
        rung: 3,
        the: 4,
        bo: 5
    };
    function y(e, t) {
        if (/^vc_\d+$/.test(t)) {
            return `bo`;
        }
        return e.loai?.(t) ?? `da`;
    }
    function b(e, t, n, r) {
        let i = new Uint8Array(t * n);
        for (let a of e.chan){
            let e = r(a.id ?? ``);
            if (!e) {
                continue;
            }
            let o = Math.max(0, Math.ceil(a.x * 4 - 0.5));
            let s = Math.min(t - 1, Math.floor((a.x + a.w) * 4 - 0.5));
            let c = Math.max(0, Math.ceil(a.y * 4 - 0.5));
            let l = Math.min(n - 1, Math.floor((a.y + a.h) * 4 - 0.5));
            for(let n = c; n <= l; n++){
                for(let r = o; r <= s; r++){
                    let a = n * t + r;
                    if (i[a] === 0 || i[a] > e) {
                        i[a] = e;
                    }
                }
            }
        }
        return i;
    }
    function x(e, t, n, r, i, a = 2) {
        let o = t * n;
        let s = 2 * a + 1;
        let c = t + 2 * a;
        let l = new Uint16Array(c * n);
        for(let r = 0; r < n; r++){
            let n = r * t;
            let i = 0;
            for(let r = -a; r <= a; r++){
                i += e[n + Math.min(t - 1, Math.max(0, r))];
            }
            for(let o = 0; o < t; o++){
                l[r * c + o] = i;
                i += e[n + Math.min(t - 1, o + a + 1)] - e[n + Math.max(0, o - a)];
            }
        }
        let u = new Float32Array(o);
        let d = 1 / (s * s);
        for(let o = 0; o < t; o++){
            let s = 0;
            for(let e = -a; e <= a; e++){
                s += l[Math.min(n - 1, Math.max(0, e)) * c + o];
            }
            for(let p = 0; p < n; p++){
                let m = p * t + o;
                let h = s * d;
                s += l[Math.min(n - 1, p + a + 1) * c + o] - l[Math.max(0, p - a) * c + o];
                if (e[m] && h >= 0.999) {
                    u[m] = 1;
                } else if (!(!e[m] && h <= 0.001)) {
                    u[m] = g(h + (f(o / 4 * 0.9, p / 4 * 0.9, r, 2) - 0.5) * i);
                }
            }
        }
        return u;
    }
    function S(e, t, n, r) {
        let i = e * t;
        let a = new Float32Array(i);
        let o = r * 4;
        let Math_SQRT2 = Math.SQRT2;
        for(let e = 0; e < i; e++){
            a[e] = n(e) ? 0 : o;
        }
        for(let n = 0; n < t; n++){
            for(let t = 0; t < e; t++){
                let r = n * e + t;
                let i = a[r];
                if (i !== 0) {
                    if (t > 0) {
                        i = Math.min(i, a[r - 1] + 1);
                    }
                    if (n > 0) {
                        i = Math.min(i, a[r - e] + 1);
                        if (t > 0) {
                            i = Math.min(i, a[r - e - 1] + Math_SQRT2);
                        }
                        if (t < e - 1) {
                            i = Math.min(i, a[r - e + 1] + Math_SQRT2);
                        }
                    }
                    a[r] = i;
                }
            }
        }
        for(let n = t - 1; n >= 0; n--){
            for(let r = e - 1; r >= 0; r--){
                let i = n * e + r;
                let o = a[i];
                if (o !== 0) {
                    if (r < e - 1) {
                        o = Math.min(o, a[i + 1] + 1);
                    }
                    if (n < t - 1) {
                        o = Math.min(o, a[i + e] + 1);
                        if (r < e - 1) {
                            o = Math.min(o, a[i + e + 1] + Math_SQRT2);
                        }
                        if (r > 0) {
                            o = Math.min(o, a[i + e - 1] + Math_SQRT2);
                        }
                    }
                    a[i] = o;
                }
            }
        }
        for(let e = 0; e < i; e++){
            a[e] = a[e] / 4;
        }
        return a;
    }
    function C(e, t, n, r) {
        let i = S(t, n, (t)=>e[t] >= 0.5, r);
        let a = S(t, n, (t)=>e[t] < 0.5, r);
        let o = new Float32Array(t * n);
        for(let t = 0; t < o.length; t++){
            o[t] = e[t] >= 0.5 ? a[t] - 0.125 : -(i[t] - 0.125);
        }
        return o;
    }
    function w(e, t, n, [a, o], i) {
        let s = i[0];
        let c = i[1];
        let l = t * n;
        let u = new Float32Array(l).fill(Infinity);
        let d = new Int32Array(l).fill(-1);
        let f = new Uint8Array(l);
        let p = new Float32Array(1024);
        let m = new Int32Array(1024);
        let h = 0;
        let g = (e, t)=>{
            if (h === p.length) {
                let e = new Float32Array(h * 2);
                let t = new Int32Array(h * 2);
                e.set(p);
                t.set(m);
                p = e;
                m = t;
            }
            let n = h++;
            while(n > 0){
                let t = n - 1 >> 1;
                if (p[t] <= e) {
                    break;
                }
                p[n] = p[t];
                m[n] = m[t];
                n = t;
            }
            p[n] = e;
            m[n] = t;
        };
        let _ = ()=>{
            let e = m[0];
            h--;
            if (h > 0) {
                let e = p[h];
                let t = m[h];
                let n = 0;
                while(true){
                    let t = 2 * n + 1;
                    let r = t + 1;
                    let i = n;
                    let a = e;
                    if (t < h && p[t] < a) {
                        i = t;
                        a = p[t];
                    }
                    if (r < h && p[r] < a) {
                        i = r;
                    }
                    if (i === n) {
                        break;
                    }
                    p[n] = p[i];
                    m[n] = m[i];
                    n = i;
                }
                p[n] = e;
                m[n] = t;
            }
            return e;
        };
        let v = o * t + a;
        u[v] = 0;
        g(0, v);
        let y = [
            1,
            -1,
            0,
            0,
            1,
            1,
            -1,
            -1
        ];
        let b = [
            0,
            0,
            1,
            -1,
            1,
            -1,
            1,
            -1
        ];
        let x = [
            1,
            1,
            1,
            1,
            1.414,
            1.414,
            1.414,
            1.414
        ];
        while(h){
            let r = _();
            if (f[r]) {
                continue;
            }
            f[r] = 1;
            let i = r % t;
            let a = r / t | 0;
            if (i === s && a === c) {
                break;
            }
            for(let o = 0; o < 8; o++){
                let l = y[o];
                let p = b[o];
                let m = i + l;
                let h = a + p;
                if (m < 0 || h < 0 || m >= t || h >= n) {
                    continue;
                }
                let _ = h * t + m;
                if (f[_] || !Number.isFinite(e[_]) || l && p && (!Number.isFinite(e[a * t + m]) || !Number.isFinite(e[h * t + i]))) {
                    continue;
                }
                let v = u[r] + x[o] * e[_];
                if (v < u[_]) {
                    u[_] = v;
                    d[_] = r;
                    g(v + Math.hypot(s - m, c - h), _);
                }
            }
        }
        let S = c * t + s;
        if (!Number.isFinite(u[S])) {
            return null;
        }
        let C = [];
        for(let e = S; e >= 0; e = d[e]){
            C.push([
                e % t + 0.5,
                (e / t | 0) + 0.5
            ]);
        }
        return C.reverse();
    }
    function T(e, t) {
        let n = e;
        for(let e = 0; e < t; e++){
            if (n.length < 3) {
                return n;
            }
            let e = [
                n[0]
            ];
            for(let t = 0; t < n.length - 1; t++){
                let [r, i] = n[t];
                let [a, o] = n[t + 1];
                e.push([
                    r * 0.75 + a * 0.25,
                    i * 0.75 + o * 0.25
                ], [
                    r * 0.25 + a * 0.75,
                    i * 0.25 + o * 0.75
                ]);
            }
            e.push(n[n.length - 1]);
            n = e;
        }
        return n;
    }
    function E(e, t, n) {
        let r = false;
        for(let i = 0, a = n.length - 1; i < n.length; a = i++){
            let [o, s] = n[i];
            let [c, l] = n[a];
            if (s > t != l > t && e < (c - o) * (t - s) / (l - s) + o) {
                r = !r;
            }
        }
        return r;
    }
    function D(e, t, n, r, i, a, o = 0.6) {
        let s = [
            r[0]
        ];
        for(let e = 1; e < r.length; e++){
            let t = r[e];
            let n = s[s.length - 1];
            if (e === r.length - 1 || Math.hypot(t[0] - n[0], t[1] - n[1]) >= 1.2) {
                s.push(t);
            }
        }
        for(let r = 0; r + 1 < s.length; r++){
            let [c, l] = s[r];
            let [u, f] = s[r + 1];
            let p = i / 2 * 1.5 + 1;
            let m = Math.max(0, Math.floor((Math.min(c, u) - p) * 4));
            let g = Math.min(t - 1, Math.ceil((Math.max(c, u) + p) * 4));
            let _ = Math.max(0, Math.floor((Math.min(l, f) - p) * 4));
            let v = Math.min(n - 1, Math.ceil((Math.max(l, f) + p) * 4));
            let y = u - c;
            let b = f - l;
            let x = y * y + b * b || 1;
            let S = i / 2 * 1.22 + o;
            for(let n = _; n <= v; n++){
                for(let r = m; r <= g; r++){
                    let s = (r + 0.5) / 4;
                    let u = (n + 0.5) / 4;
                    let f = Math.max(0, Math.min(1, ((s - c) * y + (u - l) * b) / x));
                    let p = Math.hypot(s - c - f * y, u - l - f * b);
                    if (p > S) {
                        continue;
                    }
                    let m = i / 2 * (0.78 + 0.44 * d(s / 7, u / 7, a));
                    let g = 1 - h(m - o * 0.8, m + o, p);
                    let _ = n * t + r;
                    if (g > e[_]) {
                        e[_] = g;
                    }
                }
            }
        }
    }
    function O(e, t, n, r) {
        let i = r.map((e)=>e[0]);
        let a = r.map((e)=>e[1]);
        let o = Math.max(0, Math.floor(Math.min(...i) * 4) - 2);
        let s = Math.min(t - 1, Math.ceil(Math.max(...i) * 4) + 2);
        let c = Math.max(0, Math.floor(Math.min(...a) * 4) - 2);
        let l = Math.min(n - 1, Math.ceil(Math.max(...a) * 4) + 2);
        for(let n = c; n <= l; n++){
            for(let i = o; i <= s; i++){
                let a = 0;
                for (let [e, t] of [
                    [
                        0.25,
                        0.25
                    ],
                    [
                        0.75,
                        0.25
                    ],
                    [
                        0.25,
                        0.75
                    ],
                    [
                        0.75,
                        0.75
                    ]
                ]){
                    if (E((i + e) / 4, (n + t) / 4, r)) {
                        a++;
                    }
                }
                let o = n * t + i;
                if (a / 4 > e[o]) {
                    e[o] = a / 4;
                }
            }
        }
    }
    function k(loi, t, n, r, i, a, o, s = 1) {
        let c = i * a;
        let l = Math.max(i, c) + 1;
        let u = Math.max(0, Math.floor((r.x - l) * 4));
        let d = Math.min(t - 1, Math.ceil((r.x + r.w + l) * 4));
        let p = Math.max(0, Math.floor((r.y - l) * 4));
        let m = Math.min(n - 1, Math.ceil((r.y + r.h + l) * 4));
        for(let n = p; n <= m; n++){
            for(let a = u; a <= d; a++){
                let l = (a + 0.5) / 4;
                let u = (n + 0.5) / 4;
                let d = Math.max(r.x - l, 0, l - r.x - r.w);
                let p = u > r.y + r.h ? (u - r.y - r.h) * (i / c) : Math.max(r.y - u, 0);
                let m = Math.hypot(d, p) + (f(l / 1.7, u / 1.7, o, 2) - 0.5) * i * 0.9;
                let g = (1 - h(i * 0.45, i, m)) * (s >= 1 ? 1 : s * (0.6 + 0.55 * f(l / 1.1, u / 1.1, o + 1, 2)));
                let _ = n * t + a;
                if (g > loi[_]) {
                    loi[_] = g;
                }
            }
        }
    }
    function A(e, t) {
        let W_1 = Math.ceil(e.rong * 4);
        let H_1 = Math.ceil(e.cao * 4);
        let i = W_1 * H_1;
        let seed = c(e.id);
        let ms = {};
        let l = performance.now();
        let u = (e)=>{
            let t = performance.now();
            ms[e] = Math.round((t - l) * 10) / 10;
            l = t;
        };
        let lop = b(e, W_1, H_1, (e)=>v[y(t, e)]);
        let chanDu = b(e, W_1, H_1, ()=>1);
        {
            let e = [];
            let t = (e)=>{
                let t = lop[e];
                if (t >= 1 && t <= 4) {
                    return t;
                }
                return 0;
            };
            for(let i = 0; i < H_1; i++){
                for(let a = 0; a < W_1; a++){
                    let o = i * W_1 + a;
                    if (lop[o]) {
                        continue;
                    }
                    let s = 0;
                    let c = 0;
                    for(let e = 1; e <= 3 && a - e >= 0; e++){
                        s = t(o - e);
                        if (s) {
                            c = e;
                            break;
                        }
                    }
                    if (s) {
                        for(let r = 1; r <= 4 - c && a + r < W_1; r++){
                            let n = t(o + r);
                            if (n) {
                                e.push(o, Math.min(s, n));
                                break;
                            }
                        }
                        if (e.length && e[e.length - 2] === o) {
                            continue;
                        }
                    }
                    let l = 0;
                    let u = 0;
                    for(let e = 1; e <= 3 && i - e >= 0; e++){
                        l = t(o - e * W_1);
                        if (l) {
                            u = e;
                            break;
                        }
                    }
                    if (l) {
                        for(let a = 1; a <= 4 - u && i + a < H_1; a++){
                            let r = t(o + a * W_1);
                            if (r) {
                                e.push(o, Math.min(l, r));
                                break;
                            }
                        }
                    }
                }
            }
            for(let t = 0; t < e.length; t += 2){
                lop[e[t]] = e[t + 1];
            }
        }
        let g = (e)=>{
            for(let t = 0; t < i; t++){
                if (lop[t] === e) {
                    return true;
                }
            }
            return false;
        };
        let A = new Uint8Array(i);
        let the = new Uint8Array(i);
        for(let e = 0; e < i; e++){
            A[e] = +(lop[e] === 1 || lop[e] === 4);
            the[e] = +(lop[e] === 4);
        }
        let M = x(A, W_1, H_1, seed + 11, 0.4);
        for(let e = 0; e < i; e++){
            if (the[e]) {
                M[e] = Math.max(M[e], 0.75);
            }
        }
        let caoThe = null;
        {
            let a = e.ext.the ?? [];
            let o = b(e, W_1, H_1, (e)=>{
                let n = /^the_(\d+)/.exec(e);
                if (!n || y(t, e) !== `the`) {
                    return 0;
                }
                return Math.round((a[Number(n[1])]?.cao ?? 0) * 10);
            });
            for(let e = 0; e < i; e++){
                if (o[e]) {
                    caoThe ??= new Float32Array(i);
                    caoThe[e] = o[e] / 10;
                }
            }
            let s = t.the?.caoMax ?? 0;
            if (s > 0) {
                for(let e = 0; e < i; e++){
                    if (the[e] && !caoThe?.[e]) {
                        caoThe ??= new Float32Array(i);
                        caoThe[e] = s;
                    }
                }
            }
        }
        u(`mat_na_da`);
        let P = null;
        let kNuoc = null;
        let chayX = null;
        let chayY = null;
        let ae = e.ext.duong ?? [];
        let W1 = Math.ceil(e.rong);
        let H1 = Math.ceil(e.cao);
        if (g(2)) {
            let t = new Uint8Array(i);
            for(let e = 0; e < i; e++){
                t[e] = +(lop[e] === 2);
            }
            let o = ae.filter((e)=>e.lop === `nuoc`);
            for (let s of e.ext.cau ?? []){
                let e = new Float32Array(i);
                for (let t of o){
                    D(e, W_1, H_1, t.diem, t.rong ?? 2.5, seed + 77, 0.01);
                }
                for(let i = Math.max(0, Math.floor(s.y * 4)); i < Math.min(H_1, Math.ceil((s.y + s.h) * 4)); i++){
                    for(let r = Math.max(0, Math.floor(s.x * 4)); r < Math.min(W_1, Math.ceil((s.x + s.w) * 4)); r++){
                        if (e[i * W_1 + r] > 0.5) {
                            t[i * W_1 + r] = 1;
                        }
                    }
                }
            }
            P = x(t, W_1, H_1, seed + 21, 0.22, 3);
        }
        let rung = null;
        let kRung = null;
        if (g(3)) {
            let e = new Uint8Array(i);
            for(let t = 0; t < i; t++){
                e[t] = +(lop[t] === 3);
            }
            rung = x(e, W_1, H_1, seed + 31, 0.5);
        }
        {
            let e = new Uint8Array(i);
            for(let t = 0; t < i; t++){
                e[t] = +(lop[t] >= 1 && lop[t] <= 4);
            }
            for(let t = 0; t < H_1; t++){
                for(let i = 0; i < W_1; i++){
                    let a = t * W_1 + i;
                    if (!e[a] || Math.max(M[a], P?.[a] ?? 0, rung?.[a] ?? 0) >= 0.5) {
                        continue;
                    }
                    let o = true;
                    for(let a = -2; a <= 2 && o; a++){
                        for(let s = -2; s <= 2 && o; s++){
                            let c = i + s;
                            let l = t + a;
                            if (c >= 0 && l >= 0 && c < W_1 && l < H_1 && !e[l * W_1 + c]) {
                                o = false;
                            }
                        }
                    }
                    if (!o) {
                        continue;
                    }
                    let s = lop[a];
                    if (s === 2 && P) {
                        P[a] = 0.6;
                    } else if (s === 3 && rung) {
                        rung[a] = 0.6;
                    } else {
                        M[a] = 0.6;
                    }
                }
            }
        }
        u(`mat_na_nuoc_rung`);
        let xuong = new Float32Array(i);
        let len = new Float32Array(i);
        for(let e = 0; e < W_1; e++){
            let t = 0;
            for(let i = H_1 - 1; i >= 0; i--){
                let r = i * W_1 + e;
                t = M[r] >= 0.5 ? t + 1 / 4 : 0;
                xuong[r] = t;
            }
            t = 99;
            let i = 0;
            for(let a = 0; a < H_1; a++){
                let r = a * W_1 + e;
                let o = M[r] >= 0.5;
                t = o ? 0 : t + 1 / 4;
                i = o ? i + 1 / 4 : 0;
                len[r] = o ? -i : t;
            }
        }
        let tay = new Float32Array(i);
        let ue = new Float32Array(i);
        for(let e = 0; e < H_1; e++){
            let t = 0;
            for(let r = 0; r < W_1; r++){
                let i = e * W_1 + r;
                t = M[i] >= 0.5 ? t + 1 / 4 : 0;
                tay[i] = t;
            }
            t = 0;
            for(let r = W_1 - 1; r >= 0; r--){
                let i = e * W_1 + r;
                t = M[i] >= 0.5 ? t + 1 / 4 : 0;
                ue[i] = t;
            }
        }
        let kDa = S(W_1, H_1, (e)=>M[e] >= 0.5, 6);
        let kBo = t.do.some((e)=>e.noi === `chan_bo`) ? S(W_1, H_1, (e)=>lop[e] === 5, 4) : null;
        u(`khoang_cach_da`);
        if (P) {
            let e = ae.filter((e)=>e.lop === `nuoc`);
            kNuoc = C(P, W_1, H_1, 8);
            chayX = new Float32Array(W1 * H1);
            chayY = new Float32Array(W1 * H1);
            let [i, a] = t.nuoc?.chay ?? [
                0.3,
                0.1
            ];
            for(let t = 0; t < H1; t++){
                for(let o = 0; o < W1; o++){
                    let s = t * W1 + o;
                    let c = Math.min(H_1 - 1, t * 4 + 2) * W_1 + Math.min(W_1 - 1, o * 4 + 2);
                    if (kNuoc[c] < -1.5) {
                        continue;
                    }
                    let l = 8;
                    let u = i;
                    let d = a;
                    for (let n of e){
                        for(let e = 0; e + 1 < n.diem.length; e++){
                            let [r, i] = n.diem[e];
                            let [a, s] = n.diem[e + 1];
                            let c = a - r;
                            let f = s - i;
                            let p = c * c + f * f || 1;
                            let m = Math.max(0, Math.min(1, ((o + 0.5 - r) * c + (t + 0.5 - i) * f) / p));
                            let h = Math.hypot(o + 0.5 - r - m * c, t + 0.5 - i - m * f);
                            if (h < l) {
                                l = h;
                                let e = Math.sqrt(p);
                                u = c / e * 0.9;
                                d = f / e * 0.9;
                            }
                        }
                    }
                    chayX[s] = u;
                    chayY[s] = d;
                }
            }
        }
        if (t.the?.rungTren && caoThe) {
            let o = b(e, W_1, H_1, (e)=>{
                if (/^the_\d+$/.test(e) && y(t, e) === `the`) {
                    return 1;
                }
                return 0;
            });
            for(let e = 0; e < i; e++){
                if (!o[e]) {
                    continue;
                }
                let t = e % W_1;
                let r = e / W_1 | 0;
                let s = xuong[e] - (caoThe[e] ?? 0) - 0.3 - 0.6 * d(t / 4 / 1.3, r / 4 / 1.3, seed + 37);
                if (!(s <= 0)) {
                    rung ??= new Float32Array(i);
                    rung[e] = Math.max(rung[e], h(0, 0.5, s));
                }
            }
        }
        if (rung) {
            kRung = C(rung, W_1, H_1, 8);
        }
        u(`khoang_cach`);
        let n1 = new Float32Array(W1 * H1);
        let n2 = new Float32Array(W1 * H1);
        let n3 = new Float32Array(W1 * H1);
        let n4 = new Float32Array(W1 * H1);
        let n5 = new Float32Array(W1 * H1);
        let nCao = new Float32Array(W1 * H1);
        for(let e = 0; e < H1; e++){
            for(let t = 0; t < W1; t++){
                let n = e * W1 + t;
                let r = t + 0.5;
                let i = e + 0.5;
                n1[n] = f(r / 16, i / 16, seed + 101, 3);
                n2[n] = f(r / 34, i / 34, seed + 202, 3);
                n3[n] = f(r / 11, i / 11, seed + 66, 2);
                n4[n] = d(r / 3.1, i / 3.1, seed + 67);
                n5[n] = f(r / 24, i / 24, seed + 99, 2);
                nCao[n] = f(r / 9, i / 9, seed + 5, 2);
            }
        }
        let gX = null;
        let gY = null;
        if (t.dat?.song || (t.da.tuyet ?? 0) >= 0.5) {
            let e = new Float32Array(W1 * H1);
            for(let t = 0; t < H1; t++){
                for(let n = 0; n < W1; n++){
                    e[t * W1 + n] = 0.62 * f((n + 0.5) / 6.5, (t + 0.5) / 6.5, seed + 141, 3) + 0.38 * f((n + 0.5) / 2.7, (t + 0.5) / 2.7, seed + 142, 2);
                }
            }
            gX = new Float32Array(W1 * H1);
            gY = new Float32Array(W1 * H1);
            for(let t = 0; t < H1; t++){
                for(let n = 0; n < W1; n++){
                    let r = t * W1 + n;
                    let i = Math.max(0, n - 1);
                    let a = Math.min(W1 - 1, n + 1);
                    let o = Math.max(0, t - 1);
                    let s = Math.min(H1 - 1, t + 1);
                    gX[r] = (e[t * W1 + a] - e[t * W1 + i]) / (a - i);
                    gY[r] = (e[s * W1 + n] - e[o * W1 + n]) / (s - o);
                }
            }
        }
        u(`nhieu`);
        let xe = new Float32Array(W1 * H1);
        let z = new Uint8Array(W1 * H1);
        for(let e = 0; e < H_1; e++){
            for(let t = 0; t < W_1; t++){
                if (chanDu[e * W_1 + t]) {
                    z[(e / 4 | 0) * W1 + (t / 4 | 0)] = 1;
                }
            }
        }
        let Se = S(W1, H1, (e)=>z[e] === 1 || e % W1 === 0 || e % W1 === W1 - 1 || e < W1 || e >= W1 * (H1 - 1), 4);
        for(let e = 0; e < W1 * H1; e++){
            let t = Se[e] * 4;
            xe[e] = t < 1 ? Infinity : 1 + (t < 3 ? (3 - t) * 1.2 : 0);
        }
        let B = (e)=>{
            let t = Math.min(W1 - 1, Math.max(0, Math.floor(e[0])));
            let n = Math.min(H1 - 1, Math.max(0, Math.floor(e[1])));
            for(let e = 0; e < 12; e++){
                for(let r = -e; r <= e; r++){
                    for(let i = -e; i <= e; i++){
                        if (Math.max(Math.abs(i), Math.abs(r)) !== e) {
                            continue;
                        }
                        let a = t + i;
                        let o = n + r;
                        if (a >= 0 && o >= 0 && a < W1 && o < H1 && Number.isFinite(xe[o * W1 + a])) {
                            return [
                                a,
                                o
                            ];
                        }
                    }
                }
            }
            return [
                t,
                n
            ];
        };
        let duong = [];
        let we = (t)=>{
            let n = e.noi.find((e)=>e.id === t);
            if (n?.duong?.length) {
                return n.duong.map((e)=>[
                        e[0],
                        e[1]
                    ]);
            }
            if (n && typeof n.x == `number`) {
                return [
                    [
                        n.x,
                        n.y
                    ]
                ];
            }
            let r = e.spawns[t];
            if (r) {
                return [
                    [
                        r.x,
                        r.y
                    ]
                ];
            }
            return [];
        };
        let Te = [
            ...ae
        ];
        for (let e of t.loiThem ?? []){
            Te.push({
                diem: e.qua.flatMap(we),
                rong: e.rong ?? 2.2,
                lop: `dat`
            });
        }
        for (let n of Te){
            if ((n.lop ?? `dat`) !== `dat`) {
                continue;
            }
            if (t.loi.theoDuLieu) {
                duong.push({
                    diem: T(n.diem.map((e)=>[
                            e[0],
                            e[1]
                        ]), 2),
                    rong: (n.rong ?? 2.2) * t.loi.rong
                });
                continue;
            }
            let r = [];
            for(let e = 0; e + 1 < n.diem.length; e++){
                let t = w(xe, W1, H1, B(n.diem[e]), B(n.diem[e + 1]));
                if (t) {
                    r.push(...r.length ? t.slice(1) : t);
                }
            }
            if (r.length < 2) {
                continue;
            }
            let i = r.filter((e, t)=>t % 3 == 0 || t === r.length - 1);
            let a = (t)=>!s(e, t[0], t[1]) || t[0] <= 1 || t[1] <= 1 || t[0] >= e.rong - 1 || t[1] >= e.cao - 1;
            let o = n.diem[0];
            let c = n.diem[n.diem.length - 1];
            if (a(o)) {
                i[0] = [
                    o[0],
                    o[1]
                ];
            }
            if (a(c)) {
                i[i.length - 1] = [
                    c[0],
                    c[1]
                ];
            }
            duong.push({
                diem: T(i, 3),
                rong: (n.rong ?? 2.2) * t.loi.rong
            });
        }
        u(`a_sao`);
        let loi = new Float32Array(i);
        for (let e of duong){
            D(loi, W_1, H_1, e.diem, e.rong, seed + 404);
        }
        let Ee = e.ext.vung ?? [];
        let De = Ee.filter((e)=>e.lop === `dat`);
        if (De.length) {
            let e = new Float32Array(i);
            for (let t of De){
                O(e, W_1, H_1, t.diem);
            }
            let t = C(e, W_1, H_1, 2);
            for(let e = 0; e < i; e++){
                if (t[e] < -1.6) {
                    continue;
                }
                let r = e % W_1;
                let i = e / W_1 | 0;
                let o = (r + 0.5) / 4;
                let s = (i + 0.5) / 4;
                let c = h(-1, 0.9, t[e] + (f(o / 2.1, s / 2.1, seed + 608, 2) - 0.5) * 1.6) * (0.42 + 0.5 * f(o / 3.3, s / 3.3, seed + 609, 2));
                if (c > loi[e]) {
                    loi[e] = Math.min(1, c);
                }
            }
        }
        if (t.nenNha) {
            for (let i of e.chan){
                let e = i.id ?? ``;
                if (!/^vc_\d+$/.test(e) && y(t, e) === `bo` && t.nenNha.loc(e)) {
                    k(loi, W_1, H_1, i, t.nenNha.rong, t.nenNha.nam ?? 1.6, seed + 606);
                }
            }
        }
        for (let e of t.datThem ?? []){
            k(loi, W_1, H_1, {
                x: e.x,
                y: e.y,
                w: 0,
                h: 0
            }, e.r, 1, seed + 607, 0.8);
        }
        let ray = [];
        if (t.ray) {
            let i = t.ray.boNgoai ? e.ext.ngoai ?? [] : [];
            let o = (e)=>i.some((t)=>E(e[0], e[1], t));
            for (let t of e.ext.ray ?? []){
                let e = [];
                let i = [];
                for(let n = 0; n < t.diem.length; n++){
                    let [r, a] = t.diem[n];
                    let [s, c] = n ? t.diem[n - 1] : [
                        r,
                        a
                    ];
                    let l = n ? Math.max(1, Math.ceil(Math.hypot(r - s, a - c) / 0.5)) : 1;
                    for(let t = +!!n; t <= l; t++){
                        let u = n ? [
                            s + (r - s) * t / l,
                            c + (a - c) * t / l
                        ] : [
                            r,
                            a
                        ];
                        if (o(u)) {
                            if (i.length >= 2) {
                                e.push(i);
                            }
                            i = [];
                        } else if (t === l || !i.length) {
                            i.push(u);
                        }
                    }
                }
                if (i.length >= 2) {
                    e.push(i);
                }
                for (let d_1 of e){
                    let s_1 = [
                        0
                    ];
                    for(let n = 1; n < d_1.length; n++){
                        s_1.push(s_1[n - 1] + Math.hypot(d_1[n][0] - d_1[n - 1][0], d_1[n][1] - d_1[n - 1][1]));
                    }
                    ray.push({
                        d: d_1,
                        s: s_1
                    });
                    D(loi, W_1, H_1, d_1, 2.3, seed + 406, 0.5);
                }
            }
        }
        u(`to_loi`);
        let vn_1 = [];
        for (let [o, s] of (t.vungNen ?? []).entries()){
            let t = new Float32Array(i);
            let c = s.mem ?? 2.5;
            let l = s.dam ?? 1;
            let u = seed + 610 + o * 17;
            if (s.ngoai) {
                let a = e.ext.ngoai ?? [];
                let o = new Float32Array(i);
                for (let e of a){
                    O(o, W_1, H_1, e);
                }
                let s = C(o, W_1, H_1, c + 1);
                for(let e = 0; e < H_1; e++){
                    for(let r = 0; r < W_1; r++){
                        let i = e * W_1 + r;
                        let a = (r + 0.5) / 4;
                        let o = (e + 0.5) / 4;
                        let d = (f(a / 3.5, o / 3.5, u, 3) - 0.5) * c * 1.4;
                        t[i] = h(-c * 0.5, c * 0.5, s[i] + d) * l;
                    }
                }
            } else {
                let i = s.noi ? e.noi.find((e)=>e.id === s.noi) : undefined;
                let [a, o] = s.tam ?? (i ? [
                    i.x,
                    i.y
                ] : [
                    e.rong / 2,
                    e.cao / 2
                ]);
                let [d, p] = s.r ?? [
                    8,
                    6
                ];
                let m = Math.max(0, Math.floor((a - d - c) * 4));
                let g = Math.min(W_1 - 1, Math.ceil((a + d + c) * 4));
                let _ = Math.max(0, Math.floor((o - p - c) * 4));
                let v = Math.min(H_1 - 1, Math.ceil((o + p + c) * 4));
                for(let e = _; e <= v; e++){
                    for(let r = m; r <= g; r++){
                        let i = (r + 0.5) / 4;
                        let s = (e + 0.5) / 4;
                        let m = (1 - Math.hypot((i - a) / d, (s - o) / p)) * Math.min(d, p);
                        let g = (f(i / 4, s / 4, u, 3) - 0.5) * c * 1.6;
                        t[e * W_1 + r] = h(-c * 0.5, c * 0.5, m + g) * l;
                    }
                }
            }
            vn_1.push(t);
        }
        u(`vung_nen`);
        let san = null;
        let ruong = null;
        let W = ae.filter((e)=>e.lop === `san_da`);
        let Ae = [
            ...Ee.filter((e)=>e.lop === `san_da`),
            ...(t.sanThem ?? []).map((diem)=>({
                    lop: `san_da`,
                    diem
                }))
        ];
        if (t.san && (W.length || Ae.length)) {
            san = new Float32Array(i);
            for (let e of W){
                D(san, W_1, H_1, e.diem, e.rong ?? 2.5, seed + 505, 0.2);
            }
            for (let e of Ae){
                O(san, W_1, H_1, e.diem);
            }
        }
        let je = Ee.filter((e)=>e.lop === `ruong`).map((e)=>e.diem);
        for (let e of t.ruong?.vung ?? []){
            je.push([
                [
                    e.x,
                    e.y
                ],
                [
                    e.x + e.w,
                    e.y
                ],
                [
                    e.x + e.w,
                    e.y + e.h
                ],
                [
                    e.x,
                    e.y + e.h
                ]
            ]);
        }
        let kRuong = null;
        if (t.ruong && je.length) {
            ruong = new Float32Array(i);
            for (let e of je){
                O(ruong, W_1, H_1, e);
            }
            kRuong = C(ruong, W_1, H_1, 3);
        }
        for(let e = 0; e < i; e++){
            let t = Math.min(1, Math.max(M[e], P?.[e] ?? 0, rung?.[e] ?? 0) * 2);
            loi[e] = loi[e] * (1 - t);
            if (san) {
                san[e] = san[e] * (1 - t);
            }
            if (ruong) {
                ruong[e] = ruong[e] * (1 - t);
            }
        }
        let kSan = san ? C(san, W_1, H_1, 3) : null;
        u(`san_ruong`);
        let bac = [];
        for (let t of e.ext.the ?? []){
            if (t.bac) {
                bac.push({
                    x0: t.bac[0],
                    x1: t.bac[1],
                    y0: t.y + t.h - 0.15,
                    y1: t.y + t.h + t.cao
                });
            }
        }
        let Pe = {
            ..._,
            ...t.caoDo?.thap
        };
        let { tang, mep, benMo } = ne(e, W_1, H_1, M, lop, Pe);
        let hChan = new Float32Array(i);
        {
            let e = (t.da.cao[0] + t.da.cao[1]) / 2;
            for(let t = 0; t < W_1; t++){
                let i = 0;
                let a = 0;
                let o = 0;
                for(let s = 0; s < H_1; s++){
                    let r = s * W_1 + t;
                    if (M[r] >= 0.5) {
                        i += 1 / 4;
                        if (caoThe?.[r]) {
                            a = Math.max(a, caoThe[r]);
                        }
                        o = 0;
                    } else {
                        if (i > 0) {
                            o = a > 0 ? Math.min(i, a) : i < 0.9 ? i : Math.min(e, i * 0.85);
                            i = 0;
                            a = 0;
                        }
                        hChan[r] = o;
                    }
                }
            }
        }
        let chanMo = new Float32Array(i);
        for(let e = 0; e < i; e++){
            let t = hChan[e];
            if (!(t <= 1.2)) {
                chanMo[e] = h(1.2, 6.5, t) * (1 - h(0, 1.2 + 0.9 * t, len[e]));
            }
        }
        te(chanMo, W_1, H_1, 6);
        te(chanMo, W_1, H_1, 6);
        let bacThap = j(W_1, H_1, M, lop, tang, hChan, Pe);
        u(`cao_do`);
        return {
            ms,
            bac,
            tang,
            mep,
            benMo,
            hChan,
            chanMo,
            bacThap,
            rong: e.rong,
            cao: e.cao,
            W: W_1,
            H: H_1,
            seed,
            lop,
            chanDu,
            da: M,
            the,
            xuong,
            len,
            tay,
            dong: ue,
            kDa,
            kBo,
            nuoc: P,
            kNuoc,
            rung,
            kRung,
            loi,
            san,
            ruong,
            kSan,
            kRuong,
            caoThe,
            W1,
            H1,
            n1,
            n2,
            n3,
            n4,
            n5,
            nCao,
            gX,
            gY,
            chayX,
            chayY,
            duong,
            vn: vn_1,
            ray
        };
    }
    function j(e, t, n, lop, tang, hChan, o) {
        let s = new Float32Array(e * t);
        for(let c = 0; c < e; c++){
            let l = 0;
            let u = -1;
            let d = -1;
            let f = 0;
            let p = 0;
            let m = 0;
            let g = 0;
            let _ = 1;
            for(let v = 0; v < t; v++){
                let t = v * e + c;
                if (n[t] >= 0.5 || lop[t] === 5) {
                    if (l === 0) {
                        u = d;
                    }
                    l += 1 / 4;
                    g = 0;
                    continue;
                }
                let y = tang ? tang[t] : 0;
                let b = -1;
                if (l > 0) {
                    let e = tang && u >= 0 && l <= 3 ? u - y : 0;
                    b = Math.max(e >= 0.3 ? e : 0, hChan[t]);
                    l = 0;
                }
                if (b >= o.tu[0]) {
                    f = b;
                    p = 0;
                    m = y;
                    g = h(o.tu[0], o.tu[1], f) * (1 - h(o.het[0], o.het[1], f));
                    _ = Math.min(o.daiMax, Math.max(o.daiMin, o.dai * f));
                } else if (b >= 0) {
                    g = 0;
                } else {
                    p += 1 / 4;
                }
                if (g > 0 && y > m + 0.3) {
                    g = 0;
                }
                d = y;
                if (g <= 0 || p > _) {
                    continue;
                }
                let x = p + 0.5 / 4;
                s[t] = g * (o.dam * (1 - h(0, _, x)) ** 1.6 + o.ao * (1 - h(0, o.aoRong, x)) ** 2);
            }
        }
        ee(s, e, t, 2);
        ee(s, e, t, 2);
        return s;
    }
    function ee(e, t, n, r) {
        let i = new Float32Array(t);
        for(let a = 0; a < n; a++){
            let n = a * t;
            let o = 0;
            let s = 0;
            for(let i = 0; i < Math.min(t, r); i++){
                o += e[n + i];
                s++;
            }
            for(let a = 0; a < t; a++){
                if (a + r < t) {
                    o += e[n + a + r];
                    s++;
                }
                if (a - r - 1 >= 0) {
                    o -= e[n + a - r - 1];
                    s--;
                }
                i[a] = o / s;
            }
            for(let r = 0; r < t; r++){
                e[n + r] = i[r];
            }
        }
    }
    function te(chanMo, t, n, r) {
        let i = new Float32Array(Math.max(t, n));
        for(let a = 0; a < n; a++){
            let n = a * t;
            let o = 0;
            let s = 0;
            for(let i = 0; i < Math.min(t, r); i++){
                o += chanMo[n + i];
                s++;
            }
            for(let a = 0; a < t; a++){
                if (a + r < t) {
                    o += chanMo[n + a + r];
                    s++;
                }
                if (a - r - 1 >= 0) {
                    o -= chanMo[n + a - r - 1];
                    s--;
                }
                i[a] = o / s;
            }
            for(let r = 0; r < t; r++){
                chanMo[n + r] = i[r];
            }
        }
        for(let a = 0; a < t; a++){
            let o = 0;
            let s = 0;
            for(let i = 0; i < Math.min(n, r); i++){
                o += chanMo[i * t + a];
                s++;
            }
            for(let c = 0; c < n; c++){
                if (c + r < n) {
                    o += chanMo[(c + r) * t + a];
                    s++;
                }
                if (c - r - 1 >= 0) {
                    o -= chanMo[(c - r - 1) * t + a];
                    s--;
                }
                i[c] = o / s;
            }
            for(let r = 0; r < n; r++){
                chanMo[r * t + a] = i[r];
            }
        }
    }
    function ne(e, t, n, r, lop, a) {
        let o = (e.ext.the ?? []).map((t_2, i_2)=>({
                t: t_2,
                i: i_2
            })).filter((e)=>e.t.bac && e.t.cao > 0);
        if (!o.length) {
            return {
                tang: null,
                mep: null,
                benMo: null
            };
        }
        let s = t * n;
        let tang = new Float32Array(s);
        let l = b(e, t, n, (e)=>{
            let t = /^the_(\d+)/.exec(e);
            if (t) {
                return Number(t[1]) + 1;
            }
            return 0;
        });
        let u = (e, r)=>Math.min(n - 1, Math.max(0, r * 4 | 0)) * t + Math.min(t - 1, Math.max(0, e * 4 | 0));
        o.sort((e, t)=>t.t.y + t.t.h + t.t.cao - (e.t.y + e.t.h + e.t.cao));
        for (let { t: t_1, i: i_1 } of o){
            let i = tang[u((t_1.bac[0] + t_1.bac[1]) / 2, t_1.y + t_1.h + t_1.cao + 0.4)];
            let a = Math.max(0, Math.ceil(t_1.x * 4 - 0.5));
            let o = Math.min(t - 1, Math.floor((t_1.x + t_1.w) * 4 - 0.5));
            let s = Math.max(0, Math.ceil(t_1.y * 4 - 0.5));
            let d = Math.min(n - 1, Math.floor((t_1.y + t_1.h) * 4 - 0.5));
            for(let n = s; n <= d; n++){
                for(let s = a; s <= o; s++){
                    let a = n * t + s;
                    tang[a] = l[a] === i_1 + 1 ? i : i + t_1.cao;
                }
            }
            let f = Math.min(n - 1, Math.ceil((t_1.y + t_1.h + t_1.cao) * 4));
            for(let e = s; e <= f; e++){
                for(let n = a; n <= o; n++){
                    let a = e * t + n;
                    if (l[a] === i_1 + 1) {
                        tang[a] = i;
                    }
                }
            }
        }
        let d = (e)=>r[e] >= 0.5 || lop[e] === 5 || l[e] > 0;
        let mep = new Float32Array(s).fill(9);
        let p = [
            [
                0,
                1
            ],
            [
                -1,
                0
            ],
            [
                1,
                0
            ]
        ];
        for(let e = 0; e < n; e++){
            for(let r = 0; r < t; r++){
                let i = e * t + r;
                let a = tang[i];
                if (!(a < 0.3 || d(i))) {
                    for (let [o, s] of p){
                        let l = 0;
                        let u = r;
                        let p = e;
                        let m = -1;
                        while(l < 13.5){
                            u += o;
                            p += s;
                            l += 1 / 4;
                            if (u < 0 || p < 0 || u >= t || p >= n) {
                                m = -1;
                                break;
                            }
                            let e = p * t + u;
                            if (d(e)) {
                                if (m < 0) {
                                    if (l > 1.5) {
                                        break;
                                    }
                                    m = l;
                                }
                            } else if (m < 0) {
                                if (l > 1.5) {
                                    break;
                                }
                            } else {
                                if (tang[e] < a - 0.3) {
                                    mep[i] = Math.min(mep[i], m - 0.5 / 4);
                                }
                                break;
                            }
                        }
                    }
                }
            }
        }
        let benMo = null;
        if (a.ben > 0) {
            benMo = new Float32Array(s);
            let e = a.benDai[1];
            for(let r = 0; r < n; r++){
                for(let n = 0; n < t; n++){
                    let i = r * t + n;
                    if (d(i)) {
                        continue;
                    }
                    let o = tang[i];
                    let s = 0;
                    for (let i of [
                        -1,
                        1
                    ]){
                        let l = n;
                        let u = 0;
                        let f = -1;
                        while(u < e + 1.5 && (l += i, u += 1 / 4, !(l < 0 || l >= t))){
                            let n = r * t + l;
                            if (d(n)) {
                                if (f < 0) {
                                    if (u > e) {
                                        break;
                                    }
                                    f = u;
                                }
                                if (u - f > 1.5) {
                                    break;
                                }
                                continue;
                            }
                            if (f < 0) {
                                continue;
                            }
                            let i = tang[n] - o;
                            if (i >= 1) {
                                let e = Math.min(a.benDai[1], a.benDai[0] * i);
                                if (f < e) {
                                    s = Math.max(s, h(1, 5, i) * (1 - h(0, e, f - 0.5 / 4)) ** 1.5);
                                }
                            }
                            break;
                        }
                    }
                    benMo[i] = s * a.ben;
                }
            }
        }
        return {
            tang,
            mep,
            benMo
        };
    }
    function M(e, t, n, r) {
        let i = Math.min(e.W - 1.001, Math.max(0, n * 4 - 0.5));
        let a = Math.min(e.H - 1.001, Math.max(0, r * 4 - 0.5));
        let o = i | 0;
        let s = a | 0;
        let c = i - o;
        let l = a - s;
        let u = s * e.W + o;
        return (t[u] * (1 - c) + t[u + 1] * c) * (1 - l) + (t[u + e.W] * (1 - c) + t[u + e.W + 1] * c) * l;
    }
    function N(e, t, n, r) {
        let i = Math.min(e.W1 - 1.001, Math.max(0, n - 0.5));
        let a = Math.min(e.H1 - 1.001, Math.max(0, r - 0.5));
        let o = i | 0;
        let s = a | 0;
        let c = i - o;
        let l = a - s;
        let u = s * e.W1 + o;
        return (t[u] * (1 - c) + t[u + 1] * c) * (1 - l) + (t[u + e.W1] * (1 - c) + t[u + e.W1 + 1] * c) * l;
    }
    let P = ()=>({
            i: 0,
            u: 0,
            w: 1,
            cao: 2,
            bang: 0
        });
    function re(e, t, n, r, i, a = 0) {
        let o = e.seed + a;
        let s = (t.cot[0] + t.cot[1]) / 2;
        let c = (t.cot[1] - t.cot[0]) / s;
        let u = Math.floor(r / 6);
        let d = Math.floor(n / s);
        let f = F(d, u, o, s, c);
        if (n < f) {
            d--;
            f = F(d, u, o, s, c);
        }
        let p = F(d + 1, u, o, s, c);
        if (n >= p) {
            d++;
            f = p;
            p = F(d + 1, u, o, s, c);
        }
        i.i = d;
        i.w = p - f;
        i.u = (n - f) / (p - f);
        i.bang = u;
        let m = g(0.62 * N(e, e.nCao, n, r) + 0.38 * l(d, u, o + 9));
        i.cao = t.cao[0] + (t.cao[1] - t.cao[0]) * m;
        return i;
    }
    function F(e, t, n, r, i) {
        return r * (e + (l(e, t, n + 3) - 0.5) * i);
    }
    function ie(e, t) {
        let e_caoThe = e.caoThe;
        if (!e_caoThe) {
            return 0;
        }
        if (e_caoThe[t]) {
            return e_caoThe[t];
        }
        for(let r = -1; r <= 1; r++){
            for(let i = -1; i <= 1; i++){
                let a = t + r * e.W + i;
                if (a >= 0 && a < e_caoThe.length && e_caoThe[a]) {
                    return e_caoThe[a];
                }
            }
        }
        return 0;
    }
    function ae(e, t, n, r = 0) {
        if (n) {
            if (r > 0) {
                return Math.min(t, r);
            }
            return t;
        }
        if (t < 0.9) {
            return t;
        }
        return Math.min(e.cao, Math.max(0.6, t * 0.85));
    }
    function I(e, t) {
        let n = (n)=>Math.round((e >> n & 255) * (t >> n & 255) / 255);
        return n(16) << 16 | n(8) << 8 | n(0);
    }
    function L(e, t, n) {
        let [r, i] = e.mau;
        let a = (e)=>Math.max(0, Math.min(255, Math.round(((r >> e & 255) * (1 - t) + (i >> e & 255) * t) * n)));
        return a(16) << 16 | a(8) << 8 | a(0);
    }
    function R(e, t) {
        if (e.anh !== t.anh || e.lat !== t.lat || Math.abs(e.k - t.k) / Math.max(0.000001, (e.k + t.k) / 2) >= 0.07) {
            return false;
        }
        for (let n of [
            16,
            8,
            0
        ]){
            if (Math.abs((e.tong >> n & 255) - (t.tong >> n & 255)) >= 14) {
                return false;
            }
        }
        return true;
    }
    function oe(e, t, n, r, i, a) {
        if (r < 1 || i < 1 || r > e.rong - 1 || i > e.cao - 1) {
            return false;
        }
        let o = M(e, e.da, r, i);
        let s = e.nuoc ? M(e, e.nuoc, r, i) : 0;
        let c = e.rung ? M(e, e.rung, r, i) : 0;
        if (n.noi === `dinh`) {
            return o > 0.97 && M(e, e.xuong, r, i) > t.da.cao[1] + 0.6 && -M(e, e.len, r, i) > 0.7 && M(e, e.da, r - 0.8, i) > 0.9 && M(e, e.da, r + 0.8, i) > 0.9 && !e.the[Math.min(e.H - 1, i * 4 | 0) * e.W + Math.min(e.W - 1, r * 4 | 0)];
        }
        if (n.noi === `mep_dinh`) {
            let n = -M(e, e.len, r, i);
            return o > 0.9 && n > 0.35 && n < 2.1 && M(e, e.xuong, r, i) > t.da.cao[1] + 0.4 && !e.the[Math.min(e.H - 1, i * 4 | 0) * e.W + Math.min(e.W - 1, r * 4 | 0)];
        }
        if (n.noi === `nuoc`) {
            return s > 0.97 && !!e.kNuoc && M(e, e.kNuoc, r, i) > 0.8;
        }
        if (n.noi === `nuoc_nong`) {
            if (s <= 0.92 || !e.kNuoc || o > 0.05) {
                return false;
            }
            let t = M(e, e.kNuoc, r, i);
            return t > 0.3 && t < 1.8;
        }
        if (n.noi === `rung`) {
            return c > 0.97 && !!e.kRung && M(e, e.kRung, r, i) > 1;
        }
        if ((n.noi === `chan_vach` ? o >= 0.42 : o > 0.05) || s > 0.05 || c > 0.05 || M(e, e.loi, r, i) > (n.noi === `chan_vach` ? 0.35 : 0.08) || e.san && M(e, e.san, r, i) > 0.08 || n.noi !== `bo_ruong` && e.ruong && M(e, e.ruong, r, i) > 0.05 || a.some(([e, n])=>Math.hypot(e - r, n - i) < t.tranhNoi) || e.bac.some((e)=>r > e.x0 - 0.4 && r < e.x1 + 0.4 && i > e.y0 - 0.4 && i < e.y1 + 0.6)) {
            return false;
        }
        for (let [t, n] of [
            [
                0,
                0
            ],
            [
                0.3,
                0
            ],
            [
                -0.3,
                0
            ],
            [
                0,
                0.25
            ]
        ]){
            let a = Math.floor((r + t) * 4);
            let o = Math.floor((i + n) * 4);
            if (a >= 0 && o >= 0 && a < e.W && o < e.H && e.lop[o * e.W + a] === 5) {
                return false;
            }
        }
        if ((n.cao ?? 0) >= 2.5 && !se(e, r, i, 0.7)) {
            return false;
        }
        if (n.noi === `chan_bo`) {
            return !!e.kBo && M(e, e.kBo, r, i) < 1.8;
        }
        if (n.noi === `chan_vach`) {
            return M(e, e.kDa, r, i) < (n.sat ?? 1.3);
        }
        if (n.noi === `mep_nuoc`) {
            return !!e.kNuoc && M(e, e.kNuoc, r, i) > -1.6;
        }
        if (n.noi === `mep_rung`) {
            return !!e.kRung && M(e, e.kRung, r, i) > -2.2;
        }
        return n.noi !== `bo_ruong` || !!e.ruong && M(e, e.ruong, r, i) < 0.3 && M(e, e.ruong, r, i - 0.8) + M(e, e.ruong, r, i + 0.8) + M(e, e.ruong, r - 0.8, i) + M(e, e.ruong, r + 0.8, i) > 0.5;
    }
    function se(e, t, n, r) {
        if (M(e, e.kDa, t, n) < r || e.kNuoc && M(e, e.kNuoc, t, n) > -r || e.kRung && M(e, e.kRung, t, n) > -r) {
            return true;
        }
        return !!e.kBo && M(e, e.kBo, t, n) < r;
    }
    function ce(e, t, n) {
        let n_quanh = n.quanh;
        let n_nen = n.nen;
        if (n_nen) {
            let a = n_nen.trong === undefined ? undefined : e.vn[n_nen.trong];
            let o = n_nen.ngoai === undefined ? undefined : e.vn[n_nen.ngoai];
            let { nen, ...rest } = n;
            let l = n_quanh ? ce(e, t, rest) : null;
            return (t, n)=>(!a || M(e, a, t, n) > 0.6) && (!o || M(e, o, t, n) < 0.15) && (!l || l(t, n));
        }
        if (!n_quanh) {
            return null;
        }
        let a = n_quanh.noi ? new RegExp(n_quanh.noi) : null;
        let o = a ? t.noi.filter((e)=>typeof e.x == `number` && a.test(e.id)).map((e)=>[
                e.x,
                e.y
            ]) : [];
        let s = n_quanh.r * n_quanh.r;
        return (t, n)=>{
            for (let [e, r] of o){
                if ((e - t) ** 2 + (r - n) ** 2 <= s) {
                    return true;
                }
            }
            if (n_quanh.ray) {
                for (let r of e.ray){
                    for(let e = 1; e < r.d.length; e++){
                        let [i, a] = r.d[e - 1];
                        let [o, c] = r.d[e];
                        let l = o - i;
                        let u = c - a;
                        let d = l * l + u * u || 1;
                        let f = Math.max(0, Math.min(1, ((t - i) * l + (n - a) * u) / d));
                        if ((t - i - f * l) ** 2 + (n - a - f * u) ** 2 <= s) {
                            return true;
                        }
                    }
                }
            }
            return false;
        };
    }
    function le(t, n, r) {
        let i = e(t.seed + 4242);
        let a = [];
        let o = new Map;
        let s = (e, t, n)=>Math.floor(e / n) * 65536 + Math.floor(t / n);
        let c = Math.max(r.cachChung, ...r.do.map((e)=>e.gan ?? r.cachChung));
        let l = (e, t, n)=>{
            let i = Math.ceil(Math.max(n, c) / 2);
            for(let a = -i; a <= i; a++){
                for(let c = -i; c <= i; c++){
                    for (let i of o.get(s(e + a * 2, t + c * 2, 2)) ?? []){
                        let a = Math.max(n, m(r.do[i.loai]));
                        if ((i.x - e) ** 2 + (i.y - t) ** 2 < a * a) {
                            return true;
                        }
                    }
                }
            }
            return false;
        };
        let u = new Map;
        for (let e of r.do){
            for (let t of e.anh){
                u.set(t, Math.max(u.get(t) ?? 0, e.cach));
            }
        }
        let d = new Map;
        let p = (e, t, n, cach, a)=>{
            let o = d.get(n);
            if (!o) {
                return false;
            }
            for(let n = -1; n <= 1; n++){
                for(let c = -1; c <= 1; c++){
                    for (let l of o.m.get(s(e + n * o.o, t + c * o.o, o.o)) ?? []){
                        if (a !== undefined && l.cum === a) {
                            continue;
                        }
                        let n = Math.max(cach, r.do[l.loai].cach);
                        if ((l.x - e) ** 2 + (l.y - t) ** 2 < n * n) {
                            return true;
                        }
                    }
                }
            }
            return false;
        };
        let m = (e)=>e.gan ?? r.cachChung;
        let g = (e, t, n, r)=>{
            let i = d.get(n);
            if (!i) {
                return [];
            }
            let a = [];
            let o = Math.ceil(r / i.o);
            for(let n = -o; n <= o; n++){
                for(let c = -o; c <= o; c++){
                    for (let o of i.m.get(s(e + n * i.o, t + c * i.o, i.o)) ?? []){
                        if ((o.x - e) ** 2 + (o.y - t) ** 2 < r * r) {
                            a.push(o);
                        }
                    }
                }
            }
            return a;
        };
        let _ = [
            ...n.noi.filter((e)=>typeof e.x == `number`).map((e)=>[
                    e.x,
                    e.y
                ]),
            ...Object.values(n.spawns).map((e)=>[
                    e.x,
                    e.y
                ])
        ];
        let v = new Map;
        let y = 0;
        for (let [e, c] of r.do.entries()){
            let b = v.get(c.noi);
            if (!b) {
                b = [];
                for(let e = 1; e < t.cao - 1; e++){
                    for(let n = 1; n < t.rong - 1; n++){
                        if (oe(t, r, c, n + 0.5, e + 0.5, _)) {
                            b.push(e * 4096 + n);
                        }
                    }
                }
                v.set(c.noi, b);
            }
            let x = ce(t, n, c);
            if (x) {
                b = b.filter((e)=>x(e % 4096 + 0.5, Math.floor(e / 4096) + 0.5));
            }
            if (!b.length) {
                continue;
            }
            let S = Math.round(b.length / 1000 * c.mat);
            let C = c.cum ?? 0.5;
            let w = t.seed + 977 * (e + 1);
            let T = (e, t)=>{
                if (C <= 0) {
                    return 1;
                }
                let n = f(e / (6 + 10 * C), t / (6 + 10 * C), w, 2);
                return h(0.25 + 0.15 * C, 0.7, n) ** (0.6 + 1.6 * C);
            };
            let E = 0;
            let D = i.int(0, c.anh.length - 1);
            let O = m(c);
            let k = null;
            let A = (n, y_1, m = false)=>{
                if (!oe(t, r, c, n, y_1, _) || x && !x(n, y_1)) {
                    return false;
                }
                let h = !!c.cumLoai && m && !!k;
                let v = h ? k.anh : c.anh[D % c.anh.length];
                if (l(n, y_1, O) || p(n, y_1, v, c.cach, h ? k.id : undefined)) {
                    return false;
                }
                if (!h) {
                    D++;
                }
                let b;
                if (!c.cumLoai && !c.bien) {
                    b = {
                        anh: v,
                        x: n,
                        y: y_1,
                        k: c.k[0] + i.next() * (c.k[1] - c.k[0]),
                        lat: i.chance(0.5),
                        tong: (()=>{
                            let e = 228 + i.int(0, 27);
                            let t = e;
                            let n = e - i.int(0, 10);
                            let r = e - i.int(4, 16);
                            let a = c.mau ?? 16777215;
                            return Math.round(t * (a >> 16 & 255) / 255) << 16 | Math.round(n * (a >> 8 & 255) / 255) << 8 | Math.round(r * (a & 255) / 255);
                        })(),
                        loai: e,
                        lay: !!c.lay,
                        bet: !!c.bet
                    };
                } else {
                    if (!h) {
                        k = c.cumLoai ? {
                            id: ++y,
                            anh: v,
                            ds: [],
                            t0: i.next(),
                            s0: i.next(),
                            k0: i.next()
                        } : null;
                    }
                    let t = k;
                    let r = t?.ds.length ?? 0;
                    let a = c.bien ?? {
                        mau: [
                            16777215,
                            16777215
                        ],
                        sang: [
                            0.88,
                            1
                        ]
                    };
                    let o = (e)=>e - Math.floor(e);
                    let s = g(n, y_1, v, Math.max(c.cach, 2.5));
                    let l = null;
                    for(let u = 0; u < 5; u++){
                        let d = t ? o(t.t0 + 0.38 * r + 0.17 * u + i.next() * 0.12) : i.next();
                        let p = t ? o(t.s0 + 0.29 * r + 0.23 * u + i.next() * 0.1) : i.next();
                        let m = t ? o(t.k0 + 0.41 * r + 0.31 * u + i.next() * 0.1) : i.next();
                        let tong = I(L(a, d, a.sang[0] + (a.sang[1] - a.sang[0]) * p), c.mau ?? 16777215);
                        l = {
                            anh: v,
                            x: n,
                            y: y_1,
                            k: c.k[0] + m * (c.k[1] - c.k[0]),
                            lat: i.chance(0.5),
                            tong,
                            loai: e,
                            lay: !!c.lay,
                            bet: !!c.bet,
                            ...t ? {
                                cum: t.id
                            } : {}
                        };
                        if (!s.some((e)=>R(e, l))) {
                            break;
                        }
                    }
                    let u = l;
                    if (s.some((e)=>R(e, u))) {
                        u.lat = !u.lat;
                    }
                    for(let e = 0; e < 4 && s.some((e)=>R(e, u)); e++){
                        u.k *= 1.08;
                    }
                    b = u;
                    t?.ds.push(b);
                }
                a.push(b);
                let S = s(n, y_1, 2);
                (o.get(S) ?? o.set(S, []).get(S)).push(b);
                let C = d.get(v);
                if (!C) {
                    C = {
                        o: Math.max(1, u.get(v) ?? c.cach),
                        m: new Map
                    };
                    d.set(v, C);
                }
                let w = s(n, y_1, C.o);
                (C.m.get(w) ?? C.m.set(w, []).get(w)).push(b);
                E++;
                return true;
            };
            for(let e = 0; E < S && e < S * 30; e++){
                let e = b[i.int(0, b.length - 1)];
                let t = e % 4096 + i.next();
                let n = Math.floor(e / 4096) + i.next();
                if (!(i.next() > T(t, n)) && A(t, n)) {
                    for(let e = 0; e < (c.con ?? 0) && E < S; e++){
                        for(let e = 0; e < 4; e++){
                            let e = i.next() * Math.PI * 2;
                            let r = c.cumLoai ? O * 1.02 + i.next() * 0.9 : O * 1.05 + i.next() * 1.4;
                            if (A(t + Math.cos(e) * r, n + Math.sin(e) * r * 0.8, true)) {
                                break;
                            }
                        }
                    }
                }
            }
        }
        let t_mep = t.mep;
        if (t_mep) {
            return a.filter((e)=>e.bet || M(t, t_mep, e.x, e.y) >= ((r.do[e.loai]?.cao ?? 0) >= 2.5 ? 1.5 : 0.8));
        }
        return a;
    }
    let zone_lang_coc = {
        nen: [
            `nen_lc_dat_hem_a`,
            `nen_lc_dat_hem_b`
        ],
        duong: `nen_lc_loi_soi_di`,
        da: {
            anh: `nen_lc_da_do_phang`,
            cao: [
                2,
                3.5
            ],
            cot: [
                0.55,
                1.15
            ],
            mat: [
                122,
                52,
                37
            ],
            vach: [
                84,
                35,
                27
            ],
            khe: [
                24,
                9,
                8
            ],
            vien: [
                192,
                102,
                70
            ],
            tam: 1.5,
            bac: 0.75,
            lo: 1,
            bui: 0.55,
            hat: 0.42,
            vat: 0.12,
            loang: 0.65,
            khoi: 1.7,
            tron: 0.75,
            ben: 1.4
        },
        dat: {
            soi: 0.32,
            soiMau: [
                138,
                62,
                44
            ],
            mang: 0.85,
            tiB: 0.3,
            cong: 0.4,
            diu: 0.2
        },
        bong: {
            dam: 0.5
        },
        tong: [
            1.2,
            1.07,
            0.98
        ],
        loi: {
            rong: 1.15,
            dam: 0.85
        },
        cachChung: 1.2,
        tranhNoi: 2,
        do: [
            {
                anh: [
                    `prop_phu_lang_coc_cay_kho`
                ],
                noi: `dinh`,
                mat: 1.8,
                cach: 9,
                k: [
                    0.8,
                    1.15
                ],
                cum: 0.45,
                gan: 2.4,
                cao: 2.6
            },
            {
                anh: [
                    `prop_phu_lang_coc_bui_gai`,
                    `prop_phu_lang_coc_bui_gai_b`
                ],
                noi: `dinh`,
                mat: 6,
                cach: 6,
                k: [
                    0.75,
                    1.05
                ],
                lay: true,
                cum: 0.6,
                con: 1,
                gan: 1.3,
                mau: 15784136
            },
            {
                anh: [
                    `prop_phu_lang_coc_da_chong`,
                    `prop_phu_lang_coc_phien_da`,
                    `prop_phu_lang_coc_da_vun`,
                    `prop_phu_lang_coc_da_do`
                ],
                noi: `dinh`,
                mat: 6,
                cach: 6,
                k: [
                    0.7,
                    1.05
                ],
                cum: 0.55,
                con: 1,
                gan: 1.4
            },
            {
                anh: [
                    `prop_phu_lang_coc_co_kho`,
                    `prop_phu_lang_coc_co_kho_b`
                ],
                noi: `dinh`,
                mat: 34,
                cach: 2.6,
                k: [
                    0.6,
                    0.95
                ],
                lay: true,
                cum: 0.8,
                con: 3,
                gan: 0.8,
                bong: false,
                mau: 16047308
            },
            {
                anh: [
                    `prop_phu_lang_coc_da_vun`,
                    `prop_phu_lang_coc_phien_da`,
                    `prop_phu_lang_coc_da_chong`
                ],
                noi: `mep_dinh`,
                mat: 120,
                cach: 3,
                k: [
                    0.45,
                    0.8
                ],
                cum: 0.45,
                con: 1,
                gan: 1
            },
            {
                anh: [
                    `prop_phu_lang_coc_co_kho`,
                    `prop_phu_lang_coc_co_kho_b`
                ],
                noi: `mep_dinh`,
                mat: 90,
                cach: 2.6,
                k: [
                    0.5,
                    0.85
                ],
                lay: true,
                cum: 0.6,
                con: 1,
                gan: 0.8,
                bong: false,
                mau: 16047308
            },
            {
                anh: [
                    `prop_phu_lang_coc_da_vun`,
                    `prop_phu_lang_coc_da_chong`,
                    `prop_phu_lang_coc_phien_da`
                ],
                noi: `chan_vach`,
                sat: 0.75,
                mat: 150,
                cach: 2.2,
                k: [
                    0.5,
                    0.95
                ],
                cum: 0.3,
                con: 2,
                gan: 0.9
            },
            {
                anh: [
                    `prop_phu_lang_coc_da_vun`,
                    `prop_phu_lang_coc_phien_da`
                ],
                noi: `chan_vach`,
                mat: 60,
                cach: 2.2,
                k: [
                    0.32,
                    0.48
                ],
                cum: 0.3,
                con: 1,
                gan: 0.7,
                bong: false
            },
            {
                anh: [
                    `prop_phu_lang_coc_co_kho`,
                    `prop_phu_lang_coc_co_kho_b`
                ],
                noi: `chan_vach`,
                mat: 40,
                cach: 2.6,
                k: [
                    0.55,
                    0.9
                ],
                lay: true,
                cum: 0.6,
                gan: 0.8,
                bong: false,
                mau: 16047308
            },
            {
                anh: [
                    `prop_phu_lang_coc_cot_da`
                ],
                noi: `chan_vach`,
                sat: 0.6,
                mat: 0.8,
                cach: 18,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.2,
                gan: 2.5,
                cao: 1.8
            },
            {
                anh: [
                    `prop_phu_lang_coc_co_kho`,
                    `prop_phu_lang_coc_co_kho_b`
                ],
                noi: `dat`,
                mat: 55,
                cach: 2.4,
                k: [
                    0.6,
                    1
                ],
                lay: true,
                cum: 0.8,
                con: 3,
                gan: 0.8,
                bong: false,
                mau: 16048336
            },
            {
                anh: [
                    `prop_phu_lang_coc_bui_gai`,
                    `prop_phu_lang_coc_bui_gai_b`
                ],
                noi: `dat`,
                mat: 3.5,
                cach: 6,
                k: [
                    0.55,
                    0.85
                ],
                lay: true,
                cum: 0.6,
                gan: 1.2
            },
            {
                anh: [
                    `prop_phu_lang_coc_da_chong`,
                    `prop_phu_lang_coc_phien_da`,
                    `prop_phu_lang_coc_da_vun`
                ],
                noi: `dat`,
                mat: 24,
                cach: 4,
                k: [
                    0.42,
                    0.65
                ],
                cum: 0.6,
                con: 1,
                gan: 1
            },
            {
                anh: [
                    `prop_phu_lang_coc_da_vun`
                ],
                noi: `dat`,
                mat: 14,
                cach: 3.5,
                k: [
                    0.3,
                    0.45
                ],
                cum: 0.7,
                con: 1,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `nen_lc_co_chet`
                ],
                noi: `dat`,
                mat: 2.6,
                cach: 6,
                k: [
                    0.85,
                    1.15
                ],
                bet: true,
                cum: 0.7
            },
            {
                anh: [
                    `nen_lc_xuong_thu`
                ],
                noi: `dat`,
                mat: 0.35,
                cach: 18,
                k: [
                    0.85,
                    1.1
                ],
                bet: true
            },
            {
                anh: [
                    `nen_lc_long_soi_rung`
                ],
                noi: `dat`,
                mat: 0.3,
                cach: 18,
                k: [
                    0.85,
                    1.1
                ],
                bet: true
            },
            {
                anh: [
                    `nen_lc_vet_mau_kho`
                ],
                noi: `dat`,
                mat: 0.15,
                cach: 24,
                k: [
                    0.85,
                    1.1
                ],
                bet: true
            },
            {
                anh: [
                    `nen_lc_mep_da_vun`
                ],
                noi: `chan_vach`,
                mat: 4,
                cach: 5,
                k: [
                    0.85,
                    1.1
                ],
                bet: true,
                cum: 0.4
            },
            {
                anh: [
                    `nen_lc_hang_soi_cu`
                ],
                noi: `chan_vach`,
                mat: 0.12,
                cach: 30,
                k: [
                    0.9,
                    1
                ],
                bet: true
            },
            {
                anh: [
                    `prop_phu_lang_coc_bi_ngan_a`,
                    `prop_phu_lang_coc_bi_ngan_b`,
                    `prop_phu_lang_coc_bi_ngan_c`,
                    `prop_phu_lang_coc_bi_ngan_d`
                ],
                noi: `dat`,
                mat: 4,
                cach: 4,
                k: [
                    0.85,
                    1.1
                ],
                cum: 0.85,
                con: 3,
                gan: 0.8,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_lang_coc_bi_ngan_a`,
                    `prop_phu_lang_coc_bi_ngan_b`,
                    `prop_phu_lang_coc_bi_ngan_c`,
                    `prop_phu_lang_coc_bi_ngan_d`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^(go_soi_xam|san_cuong_lang|duong_soi_lon)$`,
                    r: 16
                },
                mat: 14,
                cach: 4,
                k: [
                    0.85,
                    1.1
                ],
                cum: 0.7,
                con: 3,
                gan: 0.8,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_lang_coc_bi_ngan_b`,
                    `prop_phu_lang_coc_bi_ngan_d`
                ],
                noi: `chan_vach`,
                mat: 6,
                cach: 4,
                k: [
                    0.8,
                    1
                ],
                cum: 0.8,
                con: 2,
                gan: 0.8,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_lang_coc_bui_gai_a`,
                    `prop_phu_lang_coc_bui_gai_c`,
                    `prop_phu_lang_coc_bui_gai_d`
                ],
                noi: `dat`,
                mat: 1.4,
                cach: 8,
                k: [
                    0.8,
                    1
                ],
                cum: 0.6,
                con: 1,
                gan: 1.2,
                lay: true
            },
            {
                anh: [
                    `prop_phu_lang_coc_co_kho_a`,
                    `prop_phu_lang_coc_co_kho_c`,
                    `prop_phu_lang_coc_co_kho_d`
                ],
                noi: `dat`,
                mat: 4,
                cach: 4,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.8,
                con: 2,
                gan: 0.8,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_lang_coc_cay_chet_a`,
                    `prop_phu_lang_coc_cay_chet_b`,
                    `prop_phu_lang_coc_cay_chet_c`,
                    `prop_phu_lang_coc_cay_chet_d`
                ],
                noi: `dinh`,
                mat: 0.8,
                cach: 14,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.4,
                gan: 2.4,
                cao: 2.5
            },
            {
                anh: [
                    `prop_phu_lang_coc_cay_chet_a`,
                    `prop_phu_lang_coc_cay_chet_c`
                ],
                noi: `dat`,
                mat: 0.2,
                cach: 20,
                k: [
                    0.85,
                    1
                ],
                cum: 0.3,
                gan: 2.4,
                cao: 2.5
            }
        ],
        dong: {
            bui: {
                so: 34,
                mau: 13144176
            },
            conTrung: 3,
            chim: 1.2,
            nang: 0.7
        }
    };
    let zone_khe_coc = {
        nen: [
            `prop_tl_co_bai_a`,
            `prop_tl_co_bai_b`
        ],
        duong: `prop_tl_san_dat_nen_a`,
        loai: (e)=>{
            if (e.startsWith(`rung`) || e.startsWith(`vc_tui`)) {
                return `rung`;
            }
            if (e.startsWith(`nuoc`)) {
                return `nuoc`;
            }
            if (e.startsWith(`the`)) {
                return `the`;
            }
            if (e.startsWith(`kep`)) {
                return `bo`;
            }
            return `da`;
        },
        da: {
            anh: `prop_tl_san_da_lat_a`,
            cao: [
                1.6,
                2.6
            ],
            cot: [
                0.6,
                1.2
            ],
            mat: [
                120,
                116,
                98
            ],
            vach: [
                86,
                82,
                70
            ],
            khe: [
                30,
                30,
                24
            ],
            vien: [
                176,
                172,
                146
            ],
            lo: 0.5,
            reu: {
                mau: [
                    76,
                    116,
                    48
                ],
                mat: 0.45
            }
        },
        the: {
            mat: [
                124,
                110,
                82
            ],
            vach: [
                96,
                86,
                66
            ],
            khe: [
                38,
                34,
                26
            ],
            vien: [
                160,
                150,
                112
            ],
            reu: {
                mau: [
                    82,
                    122,
                    50
                ],
                mat: 0.5
            }
        },
        nuoc: {
            nong: [
                78,
                176,
                166
            ],
            sau: [
                22,
                98,
                116
            ],
            bot: [
                232,
                246,
                238
            ],
            troi: [
                196,
                238,
                242
            ],
            uot: [
                150,
                160,
                128
            ],
            trong: 0.45,
            dong: {
                lap: 70,
                la: 6,
                gon: 5
            },
            daBo: 0.85,
            daGiua: 0.5,
            daMau: [
                132,
                130,
                118
            ]
        },
        boVat: [
            `anim_lua_dong`
        ],
        ruong: {
            bo: [
                130,
                112,
                68
            ],
            nuoc: [
                82,
                132,
                128
            ],
            ma: [
                62,
                132,
                44
            ],
            maSang: [
                170,
                216,
                92
            ]
        },
        rung: {
            nen: [
                28,
                44,
                22
            ],
            toi: [
                22,
                50,
                26
            ],
            tan: [
                70,
                120,
                48
            ],
            sang: [
                168,
                204,
                86
            ],
            o: 1.9,
            cao: 6,
            bien: 0.6,
            vuon: 0.45
        },
        dat: {
            soi: 0.06,
            soiMau: [
                128,
                124,
                108
            ],
            mang: 0.6
        },
        bong: {
            dam: 0.42
        },
        tong: [
            1,
            1.06,
            0.96
        ],
        loi: {
            rong: 1,
            dam: 0.92,
            theoDuLieu: true
        },
        cachChung: 1.1,
        tranhNoi: 3,
        do: [
            {
                anh: [
                    `prop_phu_khe_coc_bui_to`,
                    `prop_phu_khe_coc_bui_vua`,
                    `prop_phu_khe_coc_hang_bui`
                ],
                noi: `mep_rung`,
                mat: 120,
                cach: 4,
                k: [
                    0.7,
                    1
                ],
                lay: true,
                cum: 0.4,
                con: 1,
                gan: 1.3
            },
            {
                anh: [
                    `prop_phu_khe_coc_duong_xi`,
                    `prop_trai_clump_ferns`
                ],
                noi: `mep_rung`,
                mat: 90,
                cach: 3,
                k: [
                    0.7,
                    1
                ],
                lay: true,
                cum: 0.6,
                gan: 1,
                bong: false
            },
            {
                anh: [
                    `prop_kho_reeds_clump`,
                    `prop_kho_tall_reeds`,
                    `prop_tl_co_cao_cum`
                ],
                noi: `mep_nuoc`,
                mat: 260,
                cach: 2.6,
                k: [
                    0.8,
                    1.1
                ],
                lay: true,
                cum: 0.7,
                con: 2,
                gan: 0.85,
                bong: false
            },
            {
                anh: [
                    `prop_phu_khe_coc_da_reu`,
                    `prop_kho_smooth_river_stones`,
                    `prop_kho_large_mossy_boulder`
                ],
                noi: `mep_nuoc`,
                mat: 60,
                cach: 5,
                k: [
                    0.6,
                    0.9
                ],
                cum: 0.5,
                gan: 1.2
            },
            {
                anh: [
                    `prop_kho_lotus_leaves`
                ],
                noi: `nuoc`,
                mat: 40,
                cach: 4,
                k: [
                    1.4,
                    1.9
                ],
                bet: true,
                cum: 0.8
            },
            {
                anh: [
                    `prop_kho_tall_wild_grass`,
                    `prop_kho_short_green_grass_tuft`,
                    `prop_tl_co_cao_cum`
                ],
                noi: `dat`,
                mat: 90,
                cach: 3,
                k: [
                    0.75,
                    1.1
                ],
                lay: true,
                cum: 0.8,
                con: 2,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `prop_kho_small_white_wildflowers`,
                    `prop_kho_purple_wildflowers`,
                    `prop_kho_tiny_blue_flowers`,
                    `prop_kho_yellow_chrysanthemum`
                ],
                noi: `dat`,
                mat: 40,
                cach: 4,
                k: [
                    0.8,
                    1.05
                ],
                lay: true,
                cum: 0.85,
                con: 2,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `prop_tl_hoa_dai`
                ],
                noi: `dat`,
                mat: 2.4,
                cach: 9,
                k: [
                    0.8,
                    1.05
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `prop_phu_khe_coc_bui_hoa`,
                    `prop_phu_khe_coc_goc_cay`
                ],
                noi: `dat`,
                mat: 6,
                cach: 9,
                k: [
                    0.75,
                    1
                ],
                cum: 0.5,
                gan: 1.5
            },
            {
                anh: [
                    `prop_kho_short_green_grass_tuft`,
                    `prop_kho_small_white_wildflowers`
                ],
                noi: `bo_ruong`,
                mat: 40,
                cach: 3,
                k: [
                    0.7,
                    0.95
                ],
                lay: true,
                cum: 0.6,
                gan: 0.9,
                bong: false
            },
            {
                anh: [
                    `prop_phu_khe_coc_tu_dang_a`,
                    `prop_phu_khe_coc_tu_dang_b`,
                    `prop_phu_khe_coc_tu_dang_c`
                ],
                noi: `mep_rung`,
                mat: 10,
                cach: 16,
                k: [
                    0.8,
                    1
                ],
                cum: 0.5,
                gan: 1.6,
                cao: 4
            },
            {
                anh: [
                    `prop_phu_khe_coc_tu_dang_b`,
                    `prop_phu_khe_coc_tu_dang_c`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^thon_ha_khe$`,
                    r: 18
                },
                mat: 8,
                cach: 16,
                k: [
                    0.8,
                    0.95
                ],
                cum: 0.4,
                gan: 1.8,
                cao: 4
            },
            {
                anh: [
                    `prop_phu_khe_coc_lieu_a`,
                    `prop_phu_khe_coc_lieu_b`,
                    `prop_phu_khe_coc_lieu_c`
                ],
                noi: `nuoc_nong`,
                mat: 6,
                cach: 16,
                k: [
                    0.8,
                    1
                ],
                cum: 0.4,
                gan: 1.6,
                lay: true,
                cao: 4
            },
            {
                anh: [
                    `prop_phu_khe_coc_truc_a`,
                    `prop_phu_khe_coc_truc_b`,
                    `prop_phu_khe_coc_truc_c`
                ],
                noi: `mep_rung`,
                quanh: {
                    noi: `^(thon_ha_khe|nha_cu_tri_thu|lan_tho_san_thon)$`,
                    r: 22
                },
                mat: 24,
                cach: 10,
                k: [
                    0.7,
                    0.9
                ],
                cum: 0.5,
                gan: 1.4,
                lay: true,
                cao: 4
            },
            {
                anh: [
                    `prop_phu_khe_coc_do_quyen_a`,
                    `prop_phu_khe_coc_do_quyen_b`,
                    `prop_phu_khe_coc_do_quyen_c`,
                    `prop_phu_khe_coc_do_quyen_d`
                ],
                noi: `mep_rung`,
                mat: 14,
                cach: 5,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.85,
                con: 3,
                gan: 1,
                lay: true
            },
            {
                anh: [
                    `prop_phu_khe_coc_tu_cau_a`,
                    `prop_phu_khe_coc_tu_cau_b`,
                    `prop_phu_khe_coc_tu_cau_c`,
                    `prop_phu_khe_coc_tu_cau_d`
                ],
                noi: `dat`,
                mat: 4,
                cach: 5,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.85,
                con: 3,
                gan: 1,
                lay: true
            },
            {
                anh: [
                    `prop_phu_khe_coc_hoa_hien_a`,
                    `prop_phu_khe_coc_hoa_hien_b`,
                    `prop_phu_khe_coc_hoa_hien_c`,
                    `prop_phu_khe_coc_hoa_hien_d`
                ],
                noi: `dat`,
                mat: 5,
                cach: 4,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.8,
                con: 2,
                gan: 0.9,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_khe_coc_cuc_dai_a`,
                    `prop_phu_khe_coc_cuc_dai_b`,
                    `prop_phu_khe_coc_cuc_dai_c`,
                    `prop_phu_khe_coc_cuc_dai_d`
                ],
                noi: `dat`,
                mat: 8,
                cach: 4,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.85,
                con: 3,
                gan: 0.85,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_khe_coc_lau_a`,
                    `prop_phu_khe_coc_lau_b`,
                    `prop_phu_khe_coc_lau_c`,
                    `prop_phu_khe_coc_lau_d`
                ],
                noi: `nuoc_nong`,
                mat: 24,
                cach: 4,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.75,
                con: 2,
                gan: 0.9,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_khe_coc_dien_vi_a`,
                    `prop_phu_khe_coc_dien_vi_b`,
                    `prop_phu_khe_coc_dien_vi_c`,
                    `prop_phu_khe_coc_dien_vi_d`
                ],
                noi: `nuoc_nong`,
                mat: 18,
                cach: 4,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.8,
                con: 2,
                gan: 0.85,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_khe_coc_khoai_mon_a`,
                    `prop_phu_khe_coc_khoai_mon_b`,
                    `prop_phu_khe_coc_khoai_mon_c`,
                    `prop_phu_khe_coc_khoai_mon_d`
                ],
                noi: `mep_rung`,
                mat: 8,
                cach: 5,
                k: [
                    0.8,
                    1
                ],
                cum: 0.7,
                con: 1,
                gan: 1,
                lay: true
            },
            {
                anh: [
                    `nen_kc_sen_a`,
                    `nen_kc_sen_b`,
                    `nen_kc_sen_c`,
                    `nen_kc_sen_d`
                ],
                noi: `nuoc`,
                mat: 14,
                cach: 8,
                k: [
                    0.85,
                    1.1
                ],
                bet: true,
                cum: 0.85
            },
            {
                anh: [
                    `prop_phu_chung_den_giay_a`,
                    `prop_phu_chung_den_giay_b`,
                    `prop_phu_chung_den_lua_a`,
                    `prop_phu_chung_den_da_b`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^(thon_ha_khe|ben_thuyen|gieng_thon)$`,
                    r: 9
                },
                mat: 16,
                cach: 10,
                k: [
                    0.85,
                    1
                ],
                cum: 0.3,
                gan: 1.6,
                sang: {
                    mau: 16760944,
                    r: 2.6
                }
            },
            {
                anh: [
                    `prop_phu_chung_hoa_trang_dem_a`,
                    `prop_phu_chung_hoa_trang_dem_b`,
                    `prop_phu_chung_hoa_trang_dem_c`,
                    `prop_phu_chung_hoa_trang_dem_d`
                ],
                noi: `mep_rung`,
                mat: 2.5,
                cach: 14,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.8,
                con: 1,
                gan: 1,
                sang: {
                    mau: 15266047,
                    r: 1.2
                }
            },
            {
                anh: [
                    `prop_phu_chung_nam_den_a`,
                    `prop_phu_chung_nam_den_b`,
                    `prop_phu_chung_nam_den_c`,
                    `prop_phu_chung_nam_den_d`
                ],
                noi: `mep_rung`,
                mat: 2.5,
                cach: 14,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.8,
                con: 2,
                gan: 0.9,
                sang: {
                    mau: 16756816,
                    r: 1.3
                }
            },
            {
                anh: [
                    `prop_phu_chung_hoa_chuong_a`,
                    `prop_phu_chung_hoa_chuong_b`,
                    `prop_phu_chung_hoa_chuong_c`,
                    `prop_phu_chung_hoa_chuong_d`
                ],
                noi: `dat`,
                mat: 1.5,
                cach: 14,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.85,
                con: 2,
                gan: 0.9,
                lay: true,
                bong: false,
                sang: {
                    mau: 10537215,
                    r: 1.1
                }
            }
        ],
        dong: {
            la: {
                so: 10,
                mau: [
                    7244346,
                    9083458,
                    10521154
                ]
            },
            conTrung: 4,
            chim: 1.5,
            domDom: 18,
            chuon: 3,
            khoi: [
                [
                    62.8,
                    63.8
                ],
                [
                    90.6,
                    27.9
                ]
            ]
        }
    };
    let fe = new Set([
        `hoc_duong`,
        `kho_toc`,
        `nha_dan_b`,
        `nha_nc`,
        `ham_ruou`,
        `tram_thuoc`,
        `chuong_heo`
    ]);
    let zone_ta_gia_trai = {
        nen: [
            `prop_tl_co_bai_a`,
            `prop_tl_co_bai_b`
        ],
        duong: `prop_tl_san_dat_nen_a`,
        loai: (e)=>{
            if (e.startsWith(`rung`)) {
                return `rung`;
            }
            return `bo`;
        },
        da: {
            anh: `prop_tl_san_da_lat_a`,
            cao: [
                1.2,
                1.8
            ],
            cot: [
                0.5,
                0.9
            ],
            mat: [
                124,
                118,
                102
            ],
            vach: [
                90,
                84,
                72
            ],
            khe: [
                34,
                32,
                28
            ],
            vien: [
                176,
                170,
                150
            ],
            lo: 0.3,
            reu: {
                mau: [
                    82,
                    112,
                    54
                ],
                mat: 0.4
            }
        },
        the: {
            mat: [
                136,
                130,
                114
            ],
            vach: [
                92,
                86,
                74
            ],
            khe: [
                36,
                34,
                30
            ],
            vien: [
                184,
                178,
                158
            ],
            reu: {
                mau: [
                    84,
                    116,
                    56
                ],
                mat: 0.45
            }
        },
        san: {
            mau: [
                154,
                144,
                130
            ],
            vua: [
                56,
                50,
                42
            ],
            o: 0.86,
            reu: 0.5,
            reuMau: [
                84,
                108,
                50
            ]
        },
        ruong: {
            bo: [
                118,
                96,
                62
            ],
            nuoc: [
                96,
                70,
                46
            ],
            ma: [
                58,
                118,
                46
            ],
            maSang: [
                156,
                206,
                96
            ],
            kho: true
        },
        rung: {
            nen: [
                28,
                40,
                22
            ],
            toi: [
                24,
                46,
                26
            ],
            tan: [
                66,
                110,
                48
            ],
            sang: [
                160,
                192,
                86
            ],
            o: 1.9,
            cao: 6,
            bien: 0.55,
            vuon: 0.5
        },
        dat: {
            soi: 0.05,
            soiMau: [
                128,
                124,
                108
            ],
            mang: 0.55
        },
        bong: {
            dam: 0.44
        },
        tong: [
            0.98,
            1.05,
            0.95
        ],
        loi: {
            rong: 1,
            dam: 0.95,
            theoDuLieu: true
        },
        nenNha: {
            loc: (e)=>fe.has(e),
            rong: 1.1,
            nam: 1.7
        },
        datThem: [
            {
                x: 53.5,
                y: 39.2,
                r: 5.2
            },
            {
                x: 49.5,
                y: 36.5,
                r: 2.4
            },
            {
                x: 47,
                y: 27.2,
                r: 2.6
            },
            {
                x: 6,
                y: 31.2,
                r: 2.4
            }
        ],
        boVat: [
            `anim_lo_ren`
        ],
        vatThem: [
            {
                hinh: `anim_lo_ren_ngoai_troi`,
                x: 23.6,
                y: 32.05,
                k: 0.5,
                den: {
                    mau: `#ff7a30`,
                    r: 3.2,
                    lua: true
                }
            }
        ],
        cachChung: 1.1,
        tranhNoi: 2.2,
        do: [
            {
                anh: [
                    `prop_kho_tall_wild_grass`,
                    `prop_kho_short_green_grass_tuft`,
                    `prop_kho_clover_patch`,
                    `prop_tl_co_cao_cum`
                ],
                noi: `dat`,
                mat: 70,
                cach: 3,
                k: [
                    0.75,
                    1.05
                ],
                lay: true,
                cum: 0.8,
                con: 2,
                gan: 0.85,
                bong: false
            },
            {
                anh: [
                    `prop_kho_small_white_wildflowers`,
                    `prop_kho_dandelions`,
                    `prop_kho_yellow_chrysanthemum`,
                    `prop_kho_tiny_blue_flowers`
                ],
                noi: `dat`,
                mat: 26,
                cach: 4,
                k: [
                    0.8,
                    1.05
                ],
                lay: true,
                cum: 0.85,
                con: 1,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `prop_tl_hoa_dai`
                ],
                noi: `dat`,
                mat: 2.2,
                cach: 9,
                k: [
                    0.8,
                    1.05
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `prop_kho_small_pebbles`,
                    `prop_kho_flat_grey_stone`
                ],
                noi: `dat`,
                mat: 3,
                cach: 7,
                k: [
                    0.7,
                    0.95
                ],
                cum: 0.5,
                gan: 1
            },
            {
                anh: [
                    `prop_phu_khe_coc_bui_vua`,
                    `prop_phu_khe_coc_duong_xi`,
                    `prop_phu_khe_coc_bui_hoa`
                ],
                noi: `mep_rung`,
                mat: 110,
                cach: 3.2,
                k: [
                    0.65,
                    0.95
                ],
                lay: true,
                cum: 0.5,
                con: 1,
                gan: 1.1
            },
            {
                anh: [
                    `prop_trai_clump_ferns`,
                    `prop_kho_small_fern_plant`
                ],
                noi: `mep_rung`,
                mat: 60,
                cach: 2.6,
                k: [
                    0.75,
                    1.05
                ],
                lay: true,
                cum: 0.6,
                gan: 0.9,
                bong: false
            },
            {
                anh: [
                    `prop_phu_ta_gia_trai_chau_a`,
                    `prop_phu_ta_gia_trai_chau_b`,
                    `prop_phu_ta_gia_trai_chau_c`,
                    `prop_phu_ta_gia_trai_chau_d`
                ],
                noi: `chan_bo`,
                mat: 7,
                cach: 8,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.4,
                gan: 1
            },
            {
                anh: [
                    `prop_phu_ta_gia_trai_bon_hoa_a`,
                    `prop_phu_ta_gia_trai_bon_hoa_b`,
                    `prop_phu_ta_gia_trai_bon_hoa_c`,
                    `prop_phu_ta_gia_trai_bon_hoa_d`
                ],
                noi: `chan_bo`,
                mat: 4,
                cach: 10,
                k: [
                    0.85,
                    1
                ],
                cum: 0.4,
                gan: 1.3
            },
            {
                anh: [
                    `prop_phu_ta_gia_trai_gian_leo_a`,
                    `prop_phu_ta_gia_trai_gian_leo_b`,
                    `prop_phu_ta_gia_trai_gian_leo_c`,
                    `prop_phu_ta_gia_trai_gian_leo_d`
                ],
                noi: `chan_bo`,
                mat: 2.5,
                cach: 12,
                k: [
                    0.85,
                    1
                ],
                cum: 0.4,
                gan: 1.4
            },
            {
                anh: [
                    `prop_phu_ta_gia_trai_dao_man_a`,
                    `prop_phu_ta_gia_trai_dao_man_b`,
                    `prop_phu_ta_gia_trai_dao_man_c`,
                    `prop_phu_ta_gia_trai_dao_man_d`
                ],
                noi: `dat`,
                mat: 1.4,
                cach: 14,
                k: [
                    0.8,
                    1
                ],
                cum: 0.5,
                gan: 2,
                cao: 3
            },
            {
                anh: [
                    `prop_phu_chung_den_lua_a`,
                    `prop_phu_chung_den_lua_b`,
                    `prop_phu_chung_den_lua_d`,
                    `prop_phu_chung_den_giay_a`,
                    `prop_phu_chung_den_giay_d`
                ],
                noi: `chan_bo`,
                mat: 6,
                cach: 12,
                k: [
                    0.85,
                    1
                ],
                cum: 0.3,
                gan: 1.4,
                sang: {
                    mau: 16754784,
                    r: 2.6
                }
            },
            {
                anh: [
                    `prop_phu_chung_duoc_a`,
                    `prop_phu_chung_duoc_b`,
                    `prop_phu_chung_duoc_d`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^(cong_trai|cong_tay)$`,
                    r: 8
                },
                mat: 30,
                cach: 6,
                k: [
                    0.85,
                    1
                ],
                cum: 0.2,
                gan: 1.6,
                sang: {
                    mau: 16748592,
                    r: 3.4
                }
            },
            {
                anh: [
                    `prop_phu_chung_den_da_a`,
                    `prop_phu_chung_den_da_b`,
                    `prop_phu_chung_den_da_c`,
                    `prop_phu_chung_den_da_d`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^(tu_duong|tang_kinh_cac)$`,
                    r: 9
                },
                mat: 10,
                cach: 8,
                k: [
                    0.85,
                    1
                ],
                cum: 0.2,
                gan: 1.6,
                sang: {
                    mau: 16760928,
                    r: 2.2
                }
            },
            {
                anh: [
                    `prop_phu_chung_hoa_trang_dem_a`,
                    `prop_phu_chung_hoa_trang_dem_b`,
                    `prop_phu_chung_hoa_trang_dem_c`,
                    `prop_phu_chung_hoa_trang_dem_d`
                ],
                noi: `dat`,
                mat: 1.2,
                cach: 14,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.8,
                con: 1,
                gan: 1,
                sang: {
                    mau: 15266047,
                    r: 1.2
                }
            },
            {
                anh: [
                    `prop_phu_chung_bui_qua_sang_a`,
                    `prop_phu_chung_bui_qua_sang_b`,
                    `prop_phu_chung_bui_qua_sang_c`,
                    `prop_phu_chung_bui_qua_sang_d`
                ],
                noi: `dat`,
                mat: 1,
                cach: 14,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.8,
                con: 1,
                gan: 1,
                lay: true,
                sang: {
                    mau: 14221184,
                    r: 1.2
                }
            }
        ],
        dong: {
            la: {
                so: 8,
                mau: [
                    7244346,
                    9083458,
                    10521154
                ]
            },
            conTrung: 3,
            chim: 1.4,
            domDom: 12,
            khoi: [
                [
                    14.6,
                    37.9
                ],
                [
                    13.8,
                    39.9
                ],
                [
                    23.75,
                    29.7
                ]
            ]
        }
    };
    let me = [
        `prop_gpt_thong_tuyet_cao_a`,
        `prop_gpt_thong_tuyet_cao_b`
    ];
    let he = [
        `prop_gpt_thong_tuyet_non_a`,
        `prop_gpt_thong_tuyet_non_b`
    ];
    let zone_bac_linh = {
        nen: [
            `nen_bl_tuyet_a`,
            `nen_bl_tuyet_a`
        ],
        duong: `nen_bl_dat_bun_tuyet`,
        loai: (e)=>{
            if (e.startsWith(`suoi`) && e !== `suoi_t_3`) {
                return `nuoc`;
            }
            return `da`;
        },
        da: {
            anh: `nen_ms_da_vach_hang`,
            cao: [
                2.4,
                4.2
            ],
            cot: [
                0.55,
                1.15
            ],
            mat: [
                112,
                116,
                126
            ],
            vach: [
                80,
                85,
                98
            ],
            khe: [
                24,
                26,
                36
            ],
            vien: [
                182,
                190,
                204
            ],
            tam: 1.6,
            lo: 0.4,
            tuyet: 0.86,
            hat: 0.45
        },
        nuoc: {
            nong: [
                96,
                168,
                176
            ],
            sau: [
                34,
                98,
                116
            ],
            bot: [
                236,
                244,
                250
            ],
            troi: [
                222,
                238,
                244
            ],
            uot: [
                196,
                204,
                220
            ],
            trong: 0.45,
            chay: [
                -0.3,
                0.85
            ],
            dong: {
                lap: 55,
                la: 0,
                gon: 1
            },
            bang: {
                rong: 1.1,
                mau: [
                    196,
                    222,
                    236
                ]
            }
        },
        dat: {
            soi: 0.035,
            soiMau: [
                138,
                144,
                158
            ],
            co: 0.04,
            coMau: [
                150,
                136,
                104
            ],
            mang: 0.3,
            tiB: 0.5,
            phang: 0.66,
            song: 0.55,
            songMau: [
                0.8,
                0.87,
                1
            ],
            gon: 0.85,
            lap: 0.55
        },
        bong: {
            dam: 0.42
        },
        caoDo: {
            mat: 0.25
        },
        tong: [
            0.98,
            1,
            1.03
        ],
        loi: {
            rong: 1,
            dam: 0.42
        },
        loiThem: [
            {
                qua: [
                    `cua_nam`,
                    `tram_canh_bac_linh`,
                    `tuyen_ho_tong_bl`,
                    `cua_bac`
                ],
                rong: 1.8
            },
            {
                qua: [
                    `san_soi_bac`,
                    `trai_moc_tam_nuong`
                ],
                rong: 1.2
            },
            {
                qua: [
                    `cua_truyen_thua`,
                    `cua_o_soi`
                ],
                rong: 1.2
            }
        ],
        cachChung: 1.1,
        tranhNoi: 3,
        do: [
            {
                anh: me,
                noi: `dinh`,
                mat: 26,
                cach: 4.5,
                k: [
                    0.8,
                    1.15
                ],
                cum: 0.75,
                con: 2,
                gan: 1.8,
                cao: 6
            },
            {
                anh: he,
                noi: `dinh`,
                mat: 22,
                cach: 4,
                k: [
                    0.7,
                    1.05
                ],
                cum: 0.7,
                con: 1,
                gan: 1.5,
                cao: 3
            },
            {
                anh: [
                    `prop_pg_da_tuyet_cum`,
                    `nen_bl_bui_kho_tuyet`
                ],
                noi: `dinh`,
                mat: 5,
                cach: 7,
                k: [
                    0.55,
                    0.95
                ],
                cum: 0.5,
                gan: 1.4
            },
            {
                anh: [
                    `prop_pg_cay_kho_bang`
                ],
                noi: `dinh`,
                mat: 1,
                cach: 14,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.4,
                gan: 2,
                cao: 2.5
            },
            {
                anh: [
                    `prop_pg_da_tuyet_cum`
                ],
                noi: `chan_vach`,
                mat: 26,
                cach: 4.5,
                k: [
                    0.45,
                    0.8
                ],
                cum: 0.45,
                con: 1,
                gan: 1.1
            },
            {
                anh: [
                    `nen_bl_bui_kho_tuyet`,
                    `nen_bl_mang_co_lo`
                ],
                noi: `chan_vach`,
                mat: 20,
                cach: 4,
                k: [
                    0.45,
                    0.75
                ],
                lay: true,
                cum: 0.55,
                gan: 1,
                bong: false
            },
            {
                anh: [
                    `nen_bl_mang_co_lo`
                ],
                noi: `chan_vach`,
                mat: 22,
                cach: 3,
                k: [
                    0.22,
                    0.34
                ],
                lay: true,
                cum: 0.6,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `nen_bl_soi_tuyet`,
                    `nen_bl_go_tuyet_nho`
                ],
                noi: `chan_vach`,
                mat: 8,
                cach: 6,
                k: [
                    0.8,
                    1.1
                ],
                bet: true,
                cum: 0.4
            },
            {
                anh: [
                    `prop_pg_da_tuyet_cum`
                ],
                noi: `mep_nuoc`,
                mat: 90,
                cach: 3.2,
                k: [
                    0.4,
                    0.75
                ],
                cum: 0.55,
                con: 1,
                gan: 0.9
            },
            {
                anh: [
                    `nen_bl_mang_co_lo`,
                    `nen_bl_bui_kho_tuyet`
                ],
                noi: `mep_nuoc`,
                mat: 110,
                cach: 3,
                k: [
                    0.45,
                    0.8
                ],
                lay: true,
                cum: 0.7,
                con: 1,
                gan: 0.85,
                bong: false
            },
            {
                anh: [
                    `nen_bl_mang_co_lo`
                ],
                noi: `mep_nuoc`,
                mat: 60,
                cach: 2.4,
                k: [
                    0.2,
                    0.3
                ],
                lay: true,
                cum: 0.8,
                con: 2,
                gan: 0.7,
                bong: false
            },
            {
                anh: [
                    `nen_bl_soi_tuyet`
                ],
                noi: `mep_nuoc`,
                mat: 14,
                cach: 6,
                k: [
                    0.7,
                    1
                ],
                bet: true,
                cum: 0.5
            },
            {
                anh: he,
                noi: `chan_vach`,
                sat: 0.7,
                mat: 34,
                cach: 5,
                k: [
                    0.7,
                    1.05
                ],
                cum: 0.8,
                con: 2,
                gan: 1.6,
                cao: 3
            },
            {
                anh: me,
                noi: `chan_vach`,
                sat: 0.7,
                mat: 12,
                cach: 8,
                k: [
                    0.75,
                    1
                ],
                cum: 0.8,
                con: 1,
                gan: 2,
                cao: 6
            },
            {
                anh: [
                    `prop_pg_cay_kho_bang`
                ],
                noi: `chan_vach`,
                sat: 0.7,
                mat: 6,
                cach: 12,
                k: [
                    0.75,
                    1
                ],
                cum: 0.4,
                gan: 2,
                cao: 2.5,
                mau: 14673136
            },
            {
                anh: [
                    `nen_bl_bui_kho_tuyet`,
                    `nen_bl_mang_co_lo`
                ],
                noi: `dat`,
                mat: 3,
                cach: 6,
                k: [
                    0.5,
                    0.85
                ],
                lay: true,
                cum: 0.75,
                con: 1,
                gan: 1.1
            },
            {
                anh: [
                    `nen_bl_mang_co_lo`
                ],
                noi: `dat`,
                mat: 6,
                cach: 3.2,
                k: [
                    0.3,
                    0.55
                ],
                lay: true,
                cum: 0.85,
                con: 1,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `nen_bl_mang_co_lo`
                ],
                noi: `dat`,
                mat: 4,
                cach: 2.6,
                k: [
                    0.18,
                    0.3
                ],
                lay: true,
                cum: 0.92,
                con: 2,
                gan: 0.7,
                bong: false
            },
            {
                anh: [
                    `prop_pg_da_tuyet_cum`
                ],
                noi: `dat`,
                mat: 2.2,
                cach: 8,
                k: [
                    0.4,
                    0.7
                ],
                cum: 0.6,
                gan: 1.2
            },
            {
                anh: [
                    `prop_kho_rib_bones`,
                    `prop_kho_small_animal_skull`,
                    `prop_kho_small_bones`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^san_soi_bac$`,
                    r: 20
                },
                mat: 15,
                cach: 6,
                k: [
                    0.9,
                    1.2
                ],
                cum: 0.5,
                gan: 1,
                mau: 15264496
            },
            {
                anh: [
                    `nen_lc_long_soi_rung`,
                    `nen_lc_vet_mau_kho`,
                    `nen_lc_xuong_thu`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^san_soi_bac$`,
                    r: 20
                },
                mat: 8,
                cach: 9,
                k: [
                    0.85,
                    1.05
                ],
                bet: true,
                cum: 0.5
            },
            {
                anh: [
                    `nen_bl_vet_chan_soi`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^san_soi_bac$`,
                    r: 22
                },
                mat: 8,
                cach: 6,
                k: [
                    0.9,
                    1.1
                ],
                bet: true,
                cum: 0.3
            },
            {
                anh: [
                    `nen_bl_go_tuyet_nho`
                ],
                noi: `dat`,
                mat: 2.6,
                cach: 8,
                k: [
                    0.8,
                    1.15
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `nen_bl_soi_tuyet`
                ],
                noi: `dat`,
                mat: 2.8,
                cach: 8,
                k: [
                    0.8,
                    1.1
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `nen_bl_vet_chan_soi`
                ],
                noi: `dat`,
                mat: 0.5,
                cach: 16,
                k: [
                    0.9,
                    1.1
                ],
                bet: true
            },
            {
                anh: [
                    `nen_bl_vet_nut_bang`
                ],
                noi: `dat`,
                mat: 0.22,
                cach: 24,
                k: [
                    0.85,
                    1.1
                ],
                bet: true
            },
            {
                anh: [
                    `prop_phu_bac_linh_tung_tuyet_a`,
                    `prop_phu_bac_linh_tung_tuyet_b`,
                    `prop_phu_bac_linh_tung_tuyet_c`
                ],
                noi: `dinh`,
                mat: 4,
                cach: 8,
                k: [
                    0.85,
                    1.1
                ],
                cum: 0.7,
                con: 1,
                gan: 1.8,
                cao: 4
            },
            {
                anh: [
                    `prop_phu_bac_linh_tung_tuyet_a`,
                    `prop_phu_bac_linh_tung_tuyet_b`,
                    `prop_phu_bac_linh_tung_tuyet_c`
                ],
                noi: `dat`,
                mat: 0.4,
                cach: 12,
                k: [
                    0.8,
                    1
                ],
                cum: 0.85,
                con: 1,
                gan: 2,
                cao: 4
            },
            {
                anh: [
                    `prop_phu_bac_linh_cay_bang_a`,
                    `prop_phu_bac_linh_cay_bang_b`,
                    `prop_phu_bac_linh_cay_bang_c`
                ],
                noi: `dat`,
                mat: 0.3,
                cach: 18,
                k: [
                    0.8,
                    1
                ],
                cum: 0.4,
                gan: 2.2,
                cao: 3
            },
            {
                anh: [
                    `prop_phu_bac_linh_cay_bang_a`,
                    `prop_phu_bac_linh_cay_bang_b`,
                    `prop_phu_bac_linh_cay_bang_c`
                ],
                noi: `dinh`,
                mat: 0.6,
                cach: 16,
                k: [
                    0.8,
                    1
                ],
                cum: 0.4,
                gan: 2.2,
                cao: 3
            },
            {
                anh: [
                    `prop_phu_bac_linh_hong_mai_a`,
                    `prop_phu_bac_linh_hong_mai_b`,
                    `prop_phu_bac_linh_hong_mai_c`
                ],
                noi: `dat`,
                mat: 0.12,
                cach: 40,
                k: [
                    0.85,
                    1
                ],
                cum: 0.2,
                gan: 2.6,
                cao: 3
            }
        ],
        dong: {
            tuyet: 150,
            bui: {
                so: 26,
                mau: 15922943
            },
            chim: 0.4,
            tuyetBay: 10,
            lapLanh: {
                so: 16,
                mau: 16777215
            }
        }
    };
    let zone_mach_sau = {
        nen: [
            `nen_ms_san_hang_a`,
            `nen_ms_san_hang_b`
        ],
        duong: `nen_ms_loi_mo_cu`,
        loai: (e)=>{
            if (e.startsWith(`nuoc`)) {
                return `nuoc`;
            }
            return `da`;
        },
        da: {
            anh: `nen_ms_da_vach_hang`,
            kieuMat: `dat`,
            matAnh: `nen_ms_da_vach_hang`,
            cao: [
                1.8,
                3
            ],
            cot: [
                0.45,
                0.95
            ],
            mat: [
                34,
                37,
                46
            ],
            vach: [
                78,
                82,
                94
            ],
            khe: [
                10,
                12,
                18
            ],
            vien: [
                120,
                132,
                150
            ],
            lo: 0.85,
            hat: 0.4,
            khoi: 1.5,
            tron: 0.6,
            ben: 1.8,
            loang: 0.5,
            mach: {
                mau: [
                    70,
                    230,
                    175
                ],
                mat: 1.15,
                den: {
                    r: 2.3,
                    mau: 6287552,
                    cach: 2.4
                }
            }
        },
        nuoc: {
            nong: [
                56,
                132,
                140
            ],
            sau: [
                10,
                48,
                70
            ],
            bot: [
                150,
                230,
                236
            ],
            troi: [
                90,
                170,
                190
            ],
            uot: [
                110,
                118,
                132
            ],
            trong: 0.45,
            chay: [
                0.08,
                0.03
            ],
            dong: {
                lap: 34,
                la: 0,
                gon: 4
            }
        },
        dat: {
            soi: 0.34,
            soiMau: [
                96,
                100,
                114
            ],
            mang: 0.7,
            tiB: 0.5,
            cong: 1
        },
        bong: {
            dam: 0.35
        },
        tong: [
            1.22,
            1.27,
            1.34
        ],
        loi: {
            rong: 1,
            dam: 0.32
        },
        hang: {
            toi: 0.4,
            toiKhongDen: 0.8
        },
        cachChung: 1.1,
        tranhNoi: 2.6,
        do: [
            {
                anh: [
                    `prop_phu_mach_sau_mang_da`,
                    `prop_phu_mach_sau_mang_da_cao`
                ],
                noi: `chan_vach`,
                sat: 0.6,
                mat: 46,
                cach: 4,
                k: [
                    0.65,
                    1.05
                ],
                cum: 0.55,
                con: 1,
                gan: 1.2,
                cao: 2
            },
            {
                anh: [
                    `prop_phu_mach_sau_da_vun`,
                    `prop_phu_mach_sau_soi_den`,
                    `prop_phu_mach_sau_da_hang`
                ],
                noi: `chan_vach`,
                mat: 80,
                cach: 3,
                k: [
                    0.45,
                    0.85
                ],
                cum: 0.4,
                con: 2,
                gan: 0.9
            },
            {
                anh: [
                    `prop_phu_mach_sau_nam_sang`,
                    `prop_kho_glowing_blue_mushrooms`
                ],
                noi: `chan_vach`,
                mat: 18,
                cach: 5,
                k: [
                    0.6,
                    1
                ],
                cum: 0.75,
                con: 2,
                gan: 1,
                sang: {
                    mau: 8378623,
                    r: 2.2
                }
            },
            {
                anh: [
                    `prop_phu_mach_sau_tinh_the`,
                    `prop_kho_pale_blue_crystals`
                ],
                noi: `chan_vach`,
                mat: 8,
                cach: 7,
                k: [
                    0.6,
                    0.95
                ],
                cum: 0.6,
                gan: 1.3,
                sang: {
                    mau: 10479871,
                    r: 2.4
                }
            },
            {
                anh: [
                    `prop_phu_mach_sau_da_hang`,
                    `prop_phu_mach_sau_soi_den`,
                    `prop_phu_mach_sau_mang_da`
                ],
                noi: `mep_dinh`,
                mat: 90,
                cach: 3.2,
                k: [
                    0.45,
                    0.8
                ],
                cum: 0.5,
                con: 1,
                gan: 1
            },
            {
                anh: [
                    `prop_phu_mach_sau_mang_da_cao`,
                    `prop_phu_mach_sau_da_hang`
                ],
                noi: `dinh`,
                mat: 7,
                cach: 7,
                k: [
                    0.75,
                    1.1
                ],
                cum: 0.5,
                gan: 1.6
            },
            {
                anh: [
                    `prop_phu_mach_sau_tinh_the`
                ],
                noi: `dinh`,
                mat: 3,
                cach: 9,
                k: [
                    0.7,
                    1
                ],
                cum: 0.6,
                gan: 1.6,
                sang: {
                    mau: 10479871,
                    r: 2.6
                }
            },
            {
                anh: [
                    `prop_kho_pale_blue_crystals`,
                    `prop_phu_mach_sau_tinh_the`
                ],
                noi: `mep_nuoc`,
                mat: 260,
                cach: 4,
                k: [
                    0.55,
                    0.85
                ],
                cum: 0.5,
                gan: 1.4,
                sang: {
                    mau: 9431280,
                    r: 2.8
                }
            },
            {
                anh: [
                    `prop_phu_mach_sau_phien_da_nuoc`,
                    `prop_phu_mach_sau_soi_den`
                ],
                noi: `mep_nuoc`,
                mat: 200,
                cach: 4,
                k: [
                    0.55,
                    0.85
                ],
                cum: 0.5,
                con: 1,
                gan: 1
            },
            {
                anh: [
                    `prop_phu_mach_sau_soi_den`,
                    `prop_phu_mach_sau_da_vun`
                ],
                noi: `dat`,
                mat: 9,
                cach: 5,
                k: [
                    0.35,
                    0.6
                ],
                cum: 0.75,
                con: 1,
                gan: 1,
                bong: false
            },
            {
                anh: [
                    `prop_kho_glowing_blue_mushrooms`
                ],
                noi: `dat`,
                mat: 1.6,
                cach: 9,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.8,
                gan: 1.2,
                sang: {
                    mau: 8378623,
                    r: 1.6
                }
            },
            {
                anh: [
                    `prop_kho_pile_grey_ore`,
                    `prop_kho_iron_pickaxe`
                ],
                noi: `dat`,
                mat: 30,
                cach: 8,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.3,
                gan: 1.4,
                quanh: {
                    noi: `^(nguyen_tuyen_sau_|nut_mo_giau_)`,
                    r: 4
                }
            },
            {
                anh: [
                    `nen_ms_da_vun_hang`,
                    `nen_ms_nam_hang`
                ],
                noi: `dat`,
                mat: 4,
                cach: 7,
                k: [
                    0.85,
                    1.1
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `nen_ms_vung_nuoc_ngam`
                ],
                noi: `dat`,
                mat: 1.6,
                cach: 10,
                k: [
                    0.8,
                    1.05
                ],
                bet: true,
                cum: 0.5
            },
            {
                anh: [
                    `nen_ms_mach_nguyen_thach`
                ],
                noi: `chan_vach`,
                mat: 2.5,
                cach: 9,
                k: [
                    0.85,
                    1.05
                ],
                bet: true,
                cum: 0.5
            },
            {
                anh: [
                    `nen_ms_cuoc_gay`
                ],
                noi: `dat`,
                mat: 0.4,
                cach: 20,
                k: [
                    0.85,
                    1
                ],
                bet: true,
                quanh: {
                    noi: `^(nguyen_tuyen_sau_|nut_mo_giau_)`,
                    r: 6
                }
            },
            {
                anh: [
                    `prop_phu_mach_sau_nam_sang_a`,
                    `prop_phu_mach_sau_nam_sang_b`,
                    `prop_phu_mach_sau_nam_sang_c`,
                    `prop_phu_mach_sau_nam_sang_d`
                ],
                noi: `chan_vach`,
                mat: 7,
                cach: 6,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.75,
                con: 2,
                gan: 1,
                sang: {
                    mau: 8388576,
                    r: 2
                }
            },
            {
                anh: [
                    `prop_phu_mach_sau_lan_hang_a`,
                    `prop_phu_mach_sau_lan_hang_b`,
                    `prop_phu_mach_sau_lan_hang_c`,
                    `prop_phu_mach_sau_lan_hang_d`
                ],
                noi: `chan_vach`,
                mat: 5,
                cach: 6,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.8,
                con: 1,
                gan: 0.9,
                sang: {
                    mau: 13152511,
                    r: 1.4
                }
            },
            {
                anh: [
                    `prop_phu_mach_sau_duong_xi_bac_a`,
                    `prop_phu_mach_sau_duong_xi_bac_b`,
                    `prop_phu_mach_sau_duong_xi_bac_c`,
                    `prop_phu_mach_sau_duong_xi_bac_d`
                ],
                noi: `mep_nuoc`,
                mat: 50,
                cach: 4,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.6,
                con: 1,
                gan: 1,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_mach_sau_duong_xi_bac_a`,
                    `prop_phu_mach_sau_duong_xi_bac_b`,
                    `prop_phu_mach_sau_duong_xi_bac_c`,
                    `prop_phu_mach_sau_duong_xi_bac_d`
                ],
                noi: `chan_vach`,
                mat: 6,
                cach: 5,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.6,
                con: 1,
                gan: 1,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `nen_ms_reu_sang_a`,
                    `nen_ms_reu_sang_b`,
                    `nen_ms_reu_sang_c`,
                    `nen_ms_reu_sang_d`
                ],
                noi: `dat`,
                mat: 2,
                cach: 9,
                k: [
                    0.85,
                    1.1
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `nen_ms_reu_sang_a`,
                    `nen_ms_reu_sang_b`,
                    `nen_ms_reu_sang_c`,
                    `nen_ms_reu_sang_d`
                ],
                noi: `chan_vach`,
                mat: 3,
                cach: 8,
                k: [
                    0.85,
                    1.05
                ],
                bet: true,
                cum: 0.5
            }
        ],
        dong: {
            hatSang: {
                so: 26,
                mau: 9433296
            },
            giot: 5
        }
    };
    let zone_vu_linh_ha = {
        nen: [
            `nen_vlh_dat_rung_a`,
            `prop_tl_san_dat_nen_b`
        ],
        duong: `prop_tl_san_dat_nen_a`,
        loai: (e)=>{
            if (e.startsWith(`rung`) || e.startsWith(`vc_tui`)) {
                return `rung`;
            }
            if (e.startsWith(`nuoc`)) {
                return `nuoc`;
            }
            if (e.startsWith(`the`)) {
                return `the`;
            }
            return `da`;
        },
        da: {
            anh: `nen_ms_da_vach_hang`,
            cao: [
                2,
                3.2
            ],
            cot: [
                0.35,
                1.8
            ],
            mat: [
                104,
                98,
                82
            ],
            vach: [
                92,
                84,
                70
            ],
            khe: [
                26,
                24,
                20
            ],
            vien: [
                160,
                150,
                120
            ],
            tam: 1.3,
            bac: 0.5,
            lo: 0.9,
            hat: 0.5,
            reu: {
                mau: [
                    70,
                    104,
                    44
                ],
                mat: 0.5
            }
        },
        the: {
            mat: [
                104,
                98,
                78
            ],
            vach: [
                96,
                88,
                72
            ],
            khe: [
                24,
                22,
                18
            ],
            vien: [
                156,
                146,
                114
            ],
            reu: {
                mau: [
                    70,
                    108,
                    44
                ],
                mat: 0.55
            },
            rungTren: true,
            tuNhien: true,
            hat: 0.6
        },
        nuoc: {
            nong: [
                72,
                176,
                170
            ],
            sau: [
                16,
                92,
                112
            ],
            bot: [
                230,
                246,
                240
            ],
            troi: [
                190,
                236,
                240
            ],
            uot: [
                140,
                122,
                96
            ],
            chay: [
                -0.4,
                0.5
            ],
            trong: 0.25,
            dong: {
                lap: 70,
                la: 9,
                gon: 5
            },
            daBo: 0.9,
            daGiua: 0.55,
            daMau: [
                130,
                122,
                104
            ]
        },
        ruong: {
            bo: [
                120,
                96,
                60
            ],
            nuoc: [
                82,
                60,
                40
            ],
            ma: [
                66,
                112,
                40
            ],
            maSang: [
                150,
                192,
                82
            ],
            kho: true
        },
        rung: {
            nen: [
                26,
                34,
                18
            ],
            toi: [
                22,
                42,
                22
            ],
            tan: [
                62,
                108,
                40
            ],
            sang: [
                168,
                200,
                74
            ],
            o: 2.1,
            cao: 7,
            bien: 0.75,
            vuon: 0.5
        },
        dat: {
            soi: 0.1,
            soiMau: [
                124,
                108,
                86
            ],
            mang: 0.75,
            tiB: 0.12
        },
        bong: {
            dam: 0.48
        },
        tong: [
            1.1,
            1.05,
            0.95
        ],
        loi: {
            rong: 1.05,
            dam: 0.9,
            theoDuLieu: true
        },
        cachChung: 1.1,
        tranhNoi: 2.6,
        datThem: [
            {
                x: 39,
                y: 60,
                r: 4.5
            },
            {
                x: 44,
                y: 56.5,
                r: 2.4
            },
            {
                x: 34.5,
                y: 63,
                r: 2.2
            },
            {
                x: 96,
                y: 84,
                r: 4.5
            },
            {
                x: 91.5,
                y: 86.5,
                r: 2.4
            },
            {
                x: 22,
                y: 28,
                r: 3
            }
        ],
        do: [
            {
                anh: [
                    `prop_phu_vu_linh_ha_bui_rung`,
                    `prop_phu_vu_linh_ha_cay_bui_la`,
                    `prop_phu_vu_linh_ha_duong_xi_to_b`
                ],
                noi: `mep_rung`,
                mat: 150,
                cach: 3.2,
                k: [
                    0.7,
                    1
                ],
                lay: true,
                cum: 0.5,
                con: 1,
                gan: 1.2
            },
            {
                anh: [
                    `prop_phu_vu_linh_ha_duong_xi`,
                    `prop_phu_vu_linh_ha_duong_xi_to_a`,
                    `prop_trai_clump_ferns`
                ],
                noi: `mep_rung`,
                mat: 120,
                cach: 2.6,
                k: [
                    0.7,
                    1.05
                ],
                lay: true,
                cum: 0.6,
                con: 1,
                gan: 0.9,
                bong: false
            },
            {
                anh: [
                    `prop_phu_vu_linh_ha_thong_non`,
                    `prop_phu_vu_linh_ha_bui_thu`
                ],
                noi: `mep_rung`,
                mat: 30,
                cach: 6,
                k: [
                    0.75,
                    1
                ],
                lay: true,
                cum: 0.5,
                gan: 1.4
            },
            {
                anh: [
                    `prop_phu_vu_linh_ha_khuc_go`,
                    `prop_phu_vu_linh_ha_goc_cay`,
                    `prop_phu_vu_linh_ha_da_reu`
                ],
                noi: `mep_rung`,
                mat: 10,
                cach: 9,
                k: [
                    0.7,
                    0.95
                ],
                cum: 0.4,
                gan: 1.6
            },
            {
                anh: [
                    `prop_kho_reeds_clump`,
                    `prop_kho_tall_reeds`,
                    `prop_tl_co_cao_cum`
                ],
                noi: `mep_nuoc`,
                mat: 200,
                cach: 2.6,
                k: [
                    0.75,
                    1.05
                ],
                lay: true,
                cum: 0.7,
                con: 2,
                gan: 0.9,
                bong: false
            },
            {
                anh: [
                    `prop_phu_vu_linh_ha_da_reu`,
                    `prop_kho_smooth_river_stones`,
                    `prop_kho_large_mossy_boulder`
                ],
                noi: `mep_nuoc`,
                mat: 40,
                cach: 6,
                k: [
                    0.55,
                    0.85
                ],
                cum: 0.5,
                gan: 1.2
            },
            {
                anh: [
                    `prop_kho_lotus_leaves`
                ],
                noi: `nuoc`,
                mat: 12,
                cach: 7,
                k: [
                    1.2,
                    1.6
                ],
                bet: true,
                cum: 0.9
            },
            {
                anh: [
                    `prop_tl_da_roi`
                ],
                noi: `chan_vach`,
                mat: 40,
                cach: 3.5,
                k: [
                    0.75,
                    1.05
                ],
                cum: 0.4,
                gan: 1.2,
                bet: true
            },
            {
                anh: [
                    `prop_phu_vu_linh_ha_da_reu`
                ],
                noi: `chan_vach`,
                sat: 0.8,
                mat: 26,
                cach: 3,
                k: [
                    0.4,
                    0.75
                ],
                cum: 0.4,
                con: 1,
                gan: 1
            },
            {
                anh: [
                    `prop_phu_vu_linh_ha_duong_xi`,
                    `prop_kho_small_fern_plant`
                ],
                noi: `chan_vach`,
                mat: 40,
                cach: 2.6,
                k: [
                    0.7,
                    1
                ],
                lay: true,
                cum: 0.6,
                gan: 0.9,
                bong: false
            },
            {
                anh: [
                    `prop_kho_short_green_grass_tuft`,
                    `prop_kho_tall_wild_grass`,
                    `prop_kho_small_fern_plant`,
                    `prop_kho_dry_yellow_grass_tuft`
                ],
                noi: `dat`,
                mat: 110,
                cach: 2.8,
                k: [
                    0.75,
                    1.05
                ],
                lay: true,
                cum: 0.8,
                con: 2,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `prop_kho_dry_twig`,
                    `prop_kho_fallen_branch`,
                    `prop_kho_pile_of_sticks`
                ],
                noi: `dat`,
                mat: 5,
                cach: 8,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.5,
                gan: 1.2
            },
            {
                anh: [
                    `prop_kho_purple_wildflowers`,
                    `prop_kho_small_white_wildflowers`,
                    `prop_kho_red_spider_lily`
                ],
                noi: `dat`,
                mat: 10,
                cach: 5,
                k: [
                    0.8,
                    1
                ],
                lay: true,
                cum: 0.85,
                con: 1,
                gan: 0.9,
                bong: false
            },
            {
                anh: [
                    `nen_vlh_re_noi`,
                    `nen_vlh_cay_muc`
                ],
                noi: `dat`,
                mat: 2.2,
                cach: 10,
                k: [
                    0.85,
                    1.1
                ],
                bet: true,
                cum: 0.5
            },
            {
                anh: [
                    `nen_vlh_cum_nam`,
                    `nen_vlh_mep_reu`
                ],
                noi: `dat`,
                mat: 2.4,
                cach: 9,
                k: [
                    0.85,
                    1.1
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `nen_vlh_vet_ui_heo`
                ],
                noi: `dat`,
                mat: 1.6,
                cach: 8,
                k: [
                    0.85,
                    1.1
                ],
                bet: true,
                cum: 0.7
            },
            {
                anh: [
                    `nen_vlh_vung_nuoc_rung`
                ],
                noi: `dat`,
                mat: 0.4,
                cach: 18,
                k: [
                    0.9,
                    1.1
                ],
                bet: true
            },
            {
                anh: [
                    `nen_vlh_re_noi`,
                    `nen_vlh_mep_reu`
                ],
                noi: `mep_rung`,
                mat: 8,
                cach: 7,
                k: [
                    0.85,
                    1.1
                ],
                bet: true,
                cum: 0.5
            },
            {
                anh: [
                    `prop_phu_vu_linh_ha_co_thu_a`,
                    `prop_phu_vu_linh_ha_co_thu_b`,
                    `prop_phu_vu_linh_ha_co_thu_c`
                ],
                noi: `mep_rung`,
                mat: 2,
                cach: 30,
                k: [
                    0.85,
                    1
                ],
                cum: 0.3,
                gan: 2,
                cao: 6
            },
            {
                anh: [
                    `prop_phu_vu_linh_ha_ngan_hanh_a`,
                    `prop_phu_vu_linh_ha_ngan_hanh_b`,
                    `prop_phu_vu_linh_ha_ngan_hanh_c`
                ],
                noi: `mep_rung`,
                mat: 6,
                cach: 16,
                k: [
                    0.8,
                    1
                ],
                cum: 0.75,
                con: 1,
                gan: 1.6,
                cao: 5
            },
            {
                anh: [
                    `prop_phu_vu_linh_ha_phong_do_a`,
                    `prop_phu_vu_linh_ha_phong_do_b`,
                    `prop_phu_vu_linh_ha_phong_do_c`
                ],
                noi: `mep_rung`,
                mat: 6,
                cach: 16,
                k: [
                    0.8,
                    1
                ],
                cum: 0.75,
                con: 1,
                gan: 1.6,
                cao: 5
            },
            {
                anh: [
                    `prop_phu_vu_linh_ha_duong_xi_to_c`,
                    `prop_phu_vu_linh_ha_duong_xi_to_d`
                ],
                noi: `mep_rung`,
                mat: 16,
                cach: 4,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.6,
                con: 1,
                gan: 1,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_vu_linh_ha_nam_a`,
                    `prop_phu_vu_linh_ha_nam_b`,
                    `prop_phu_vu_linh_ha_nam_c`,
                    `prop_phu_vu_linh_ha_nam_d`
                ],
                noi: `mep_rung`,
                mat: 6,
                cach: 7,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.8,
                con: 1,
                gan: 0.9
            },
            {
                anh: [
                    `prop_phu_vu_linh_ha_go_reu_a`,
                    `prop_phu_vu_linh_ha_go_reu_b`,
                    `prop_phu_vu_linh_ha_go_reu_c`,
                    `prop_phu_vu_linh_ha_go_reu_d`
                ],
                noi: `mep_rung`,
                mat: 5,
                cach: 14,
                k: [
                    0.8,
                    1
                ],
                cum: 0.4,
                gan: 1.4
            },
            {
                anh: [
                    `nen_vlh_reu_hoa_a`,
                    `nen_vlh_reu_hoa_b`,
                    `nen_vlh_reu_hoa_c`,
                    `nen_vlh_reu_hoa_d`
                ],
                noi: `dat`,
                mat: 2,
                cach: 9,
                k: [
                    0.85,
                    1.1
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `prop_phu_chung_nam_den_a`,
                    `prop_phu_chung_nam_den_b`,
                    `prop_phu_chung_nam_den_c`,
                    `prop_phu_chung_nam_den_d`
                ],
                noi: `mep_rung`,
                mat: 2.5,
                cach: 14,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.8,
                con: 2,
                gan: 0.9,
                sang: {
                    mau: 16756816,
                    r: 1.3
                }
            },
            {
                anh: [
                    `prop_phu_chung_bui_qua_sang_a`,
                    `prop_phu_chung_bui_qua_sang_b`,
                    `prop_phu_chung_bui_qua_sang_c`,
                    `prop_phu_chung_bui_qua_sang_d`
                ],
                noi: `dat`,
                mat: 1,
                cach: 14,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.8,
                con: 1,
                gan: 1,
                lay: true,
                sang: {
                    mau: 14221184,
                    r: 1.2
                }
            },
            {
                anh: [
                    `prop_phu_chung_hoa_chuong_a`,
                    `prop_phu_chung_hoa_chuong_b`,
                    `prop_phu_chung_hoa_chuong_c`,
                    `prop_phu_chung_hoa_chuong_d`
                ],
                noi: `dat`,
                mat: 1,
                cach: 14,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.85,
                con: 2,
                gan: 0.9,
                lay: true,
                bong: false,
                sang: {
                    mau: 10537215,
                    r: 1.1
                }
            }
        ],
        dong: {
            la: {
                so: 16,
                mau: [
                    7244346,
                    9083458,
                    10521154,
                    10119730
                ]
            },
            conTrung: 5,
            chim: 1.4,
            domDom: 22,
            bui: {
                so: 10,
                mau: 14213280
            },
            chuon: 3
        }
    };
    let zone_hac_thuy = {
        nen: [
            `nen_ht_bun_den_a`,
            `nen_ht_co_lau_ua`
        ],
        duong: `nen_ht_dat_kho_nut`,
        loai: (e)=>{
            if (e.startsWith(`ho`)) {
                return `nuoc`;
            }
            if (e.startsWith(`cay_dam`)) {
                return `bo`;
            }
            return `da`;
        },
        da: {
            anh: `nen_ms_da_vach_hang`,
            cao: [
                1,
                1.6
            ],
            cot: [
                0.45,
                0.95
            ],
            mat: [
                70,
                72,
                58
            ],
            vach: [
                58,
                56,
                44
            ],
            khe: [
                18,
                20,
                16
            ],
            vien: [
                104,
                108,
                84
            ],
            lo: 0.5,
            reu: {
                mau: [
                    64,
                    84,
                    42
                ],
                mat: 0.6
            },
            hat: 0.4
        },
        nuoc: {
            nong: [
                48,
                60,
                46
            ],
            sau: [
                12,
                20,
                18
            ],
            bot: [
                128,
                136,
                104
            ],
            troi: [
                104,
                118,
                112
            ],
            uot: [
                128,
                122,
                104
            ],
            trong: 0.12,
            chay: [
                0.06,
                0.03
            ],
            lang: true,
            am: 6,
            dong: {
                lap: 16,
                la: 5,
                gon: 6,
                bot: 9
            },
            beo: {
                mau: [
                    74,
                    96,
                    40
                ],
                mat: 0.45
            }
        },
        dat: {
            soi: 0.04,
            soiMau: [
                74,
                70,
                58
            ],
            mang: 0.6,
            tiB: 0.36,
            phang: 0.4,
            song: 0.4,
            songMau: [
                0.86,
                0.92,
                0.9
            ],
            uot: {
                mau: [
                    146,
                    154,
                    142
                ],
                mat: 0.26
            }
        },
        bong: {
            dam: 0.36
        },
        tong: [
            0.94,
            0.99,
            0.94
        ],
        loi: {
            rong: 1,
            dam: 0.55
        },
        loiThem: [
            {
                qua: [
                    `cua_dong`,
                    `tram_hac_thuy`,
                    `nuoc_den`,
                    `da_co_bo_suong`,
                    `cua_dam_hac_thuy`
                ],
                rong: 2
            },
            {
                qua: [
                    `tram_hac_thuy`,
                    `da_co_lach_mua`,
                    `nut_hai_bun`
                ],
                rong: 1.6
            },
            {
                qua: [
                    `cua_dam_hac_thuy`,
                    `nguon_doc`
                ],
                rong: 1.4
            }
        ],
        cachChung: 1.1,
        tranhNoi: 3,
        banDo: {
            duoi: 14,
            tren: 190
        },
        do: [
            {
                anh: [
                    `prop_kho_reeds_clump`,
                    `prop_kho_tall_reeds`
                ],
                noi: `mep_nuoc`,
                mat: 200,
                cach: 2.4,
                k: [
                    1,
                    1.5
                ],
                lay: true,
                cum: 0.45,
                con: 3,
                gan: 0.7,
                bong: false,
                mau: 14209200
            },
            {
                anh: [
                    `nen_ht_cum_lau`
                ],
                noi: `nuoc_nong`,
                mat: 260,
                cach: 3,
                k: [
                    0.6,
                    1
                ],
                lay: true,
                cum: 0.3,
                con: 2,
                gan: 1,
                bong: false
            },
            {
                anh: [
                    `prop_kho_tall_reeds`,
                    `prop_kho_reeds_clump`
                ],
                noi: `nuoc_nong`,
                mat: 300,
                cach: 2.2,
                k: [
                    1,
                    1.5
                ],
                lay: true,
                cum: 0.3,
                con: 2,
                gan: 0.75,
                bong: false,
                mau: 13683886
            },
            {
                anh: [
                    `nen_ht_cum_lau`
                ],
                noi: `mep_nuoc`,
                mat: 120,
                cach: 3,
                k: [
                    0.65,
                    1.05
                ],
                lay: true,
                cum: 0.45,
                con: 2,
                gan: 1,
                bong: false
            },
            {
                anh: [
                    `nuoc_ht_mep_bo_lau`
                ],
                noi: `mep_nuoc`,
                mat: 8,
                cach: 12,
                k: [
                    0.42,
                    0.55
                ],
                lay: true,
                cum: 0.3,
                gan: 2,
                bong: false
            },
            {
                anh: [
                    `nuoc_ht_da_den_uot`,
                    `prop_go_muc`
                ],
                noi: `mep_nuoc`,
                mat: 6,
                cach: 9,
                k: [
                    0.42,
                    0.55
                ],
                cum: 0.4,
                gan: 1.4
            },
            {
                anh: [
                    `nen_ht_go_muc_dam`,
                    `nen_ht_xuong_ca`
                ],
                noi: `mep_nuoc`,
                mat: 4,
                cach: 10,
                k: [
                    0.8,
                    1
                ],
                bet: true,
                cum: 0.4
            },
            {
                anh: [
                    `nuoc_ht_da_den_uot`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^dao_thuy_mang$`,
                    r: 22
                },
                mat: 22,
                cach: 6,
                k: [
                    0.38,
                    0.55
                ],
                cum: 0.5,
                con: 1,
                gan: 1.4
            },
            {
                anh: [
                    `prop_da_dao`
                ],
                noi: `mep_nuoc`,
                quanh: {
                    noi: `^dao_thuy_mang$`,
                    r: 22
                },
                mat: 30,
                cach: 5,
                k: [
                    0.6,
                    1
                ],
                cum: 0.6,
                gan: 1.2,
                mau: 12634296
            },
            {
                anh: [
                    `prop_phu_hac_thuy_da_den_a`,
                    `prop_phu_hac_thuy_da_den_b`,
                    `prop_phu_hac_thuy_da_den_c`,
                    `prop_phu_hac_thuy_da_den_d`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^dao_thuy_mang$`,
                    r: 22
                },
                mat: 10,
                cach: 5,
                k: [
                    0.6,
                    0.85
                ],
                cum: 0.6,
                con: 1,
                gan: 1.2
            },
            {
                anh: [
                    `prop_kho_rib_bones`,
                    `prop_kho_boar_skull_tusks`,
                    `prop_kho_small_bones`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^dao_thuy_mang$`,
                    r: 22
                },
                mat: 12,
                cach: 6,
                k: [
                    0.9,
                    1.2
                ],
                cum: 0.4,
                gan: 1
            },
            {
                anh: [
                    `nen_ht_xuong_ca`,
                    `nen_ht_vet_tran`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^dao_thuy_mang$`,
                    r: 22
                },
                mat: 8,
                cach: 9,
                k: [
                    0.85,
                    1.1
                ],
                bet: true,
                cum: 0.5
            },
            {
                anh: [
                    `nuoc_ht_sen_heo`,
                    `nuoc_ht_beo_tay`
                ],
                noi: `nuoc`,
                mat: 9,
                cach: 6,
                k: [
                    0.85,
                    1.15
                ],
                bet: true,
                cum: 0.7
            },
            {
                anh: [
                    `nuoc_ht_go_muc_noi`
                ],
                noi: `nuoc`,
                mat: 1.2,
                cach: 14,
                k: [
                    0.85,
                    1.1
                ],
                bet: true,
                cum: 0.4
            },
            {
                anh: [
                    `nuoc_ht_coc_muc_nuoc`
                ],
                noi: `nuoc`,
                mat: 0.8,
                cach: 14,
                k: [
                    0.42,
                    0.52
                ],
                cum: 0.5,
                gan: 2
            },
            {
                anh: [
                    `prop_cay_chet`,
                    `prop_kho_dead_leafless_tree`
                ],
                noi: `chan_vach`,
                sat: 0.6,
                mat: 30,
                cach: 6,
                k: [
                    0.85,
                    1.15
                ],
                cum: 0.5,
                gan: 2,
                cao: 3,
                mau: 13159616
            },
            {
                anh: [
                    `prop_kho_reeds_clump`,
                    `nen_ht_cum_lau`
                ],
                noi: `chan_vach`,
                mat: 90,
                cach: 3,
                k: [
                    0.6,
                    1
                ],
                lay: true,
                cum: 0.6,
                gan: 0.9,
                bong: false
            },
            {
                anh: [
                    `nen_ht_cum_lau`
                ],
                noi: `dat`,
                mat: 7,
                cach: 5,
                k: [
                    0.6,
                    0.95
                ],
                lay: true,
                cum: 0.85,
                con: 2,
                gan: 1.1,
                bong: false
            },
            {
                anh: [
                    `prop_kho_reeds_clump`,
                    `prop_kho_tall_wild_grass`
                ],
                noi: `dat`,
                mat: 15,
                cach: 3,
                k: [
                    0.7,
                    1.1
                ],
                lay: true,
                cum: 0.85,
                con: 3,
                gan: 0.8,
                bong: false,
                mau: 12104852
            },
            {
                anh: [
                    `prop_cay_chet`,
                    `prop_kho_dead_leafless_tree`
                ],
                noi: `dat`,
                mat: 0.7,
                cach: 14,
                k: [
                    0.85,
                    1.1
                ],
                cum: 0.6,
                con: 1,
                gan: 2.4,
                cao: 3,
                mau: 12633272
            },
            {
                anh: [
                    `prop_go_muc`,
                    `prop_kho_fallen_hollow_log`
                ],
                noi: `dat`,
                mat: 0.8,
                cach: 12,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.4,
                gan: 1.6
            },
            {
                anh: [
                    `prop_kho_small_bones`,
                    `prop_kho_small_animal_skull`
                ],
                noi: `dat`,
                mat: 0.4,
                cach: 16,
                k: [
                    0.85,
                    1
                ],
                cum: 0.3
            },
            {
                anh: [
                    `nen_ht_vung_doc`
                ],
                noi: `dat`,
                mat: 0.14,
                cach: 26,
                k: [
                    0.8,
                    1
                ],
                bet: true
            },
            {
                anh: [
                    `nen_ht_vet_doc_lan`,
                    `nen_ht_vet_tran`
                ],
                noi: `dat`,
                mat: 0.5,
                cach: 16,
                k: [
                    0.8,
                    1.1
                ],
                bet: true,
                cum: 0.5
            },
            {
                anh: [
                    `nen_ht_go_muc_dam`,
                    `nen_ht_xuong_ca`
                ],
                noi: `dat`,
                mat: 0.6,
                cach: 14,
                k: [
                    0.8,
                    1.05
                ],
                bet: true,
                cum: 0.4
            },
            {
                anh: [
                    `prop_phu_hac_thuy_cay_chet_reu_a`,
                    `prop_phu_hac_thuy_cay_chet_reu_b`,
                    `prop_phu_hac_thuy_cay_chet_reu_c`,
                    `prop_phu_hac_thuy_cay_chet_reu_d`
                ],
                noi: `chan_vach`,
                sat: 0.6,
                mat: 5,
                cach: 12,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.5,
                gan: 2.2,
                cao: 3.5
            },
            {
                anh: [
                    `prop_phu_hac_thuy_cay_chet_reu_a`,
                    `prop_phu_hac_thuy_cay_chet_reu_b`,
                    `prop_phu_hac_thuy_cay_chet_reu_c`,
                    `prop_phu_hac_thuy_cay_chet_reu_d`
                ],
                noi: `mep_nuoc`,
                mat: 1,
                cach: 16,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.5,
                gan: 2.4,
                cao: 3.5
            },
            {
                anh: [
                    `prop_phu_hac_thuy_re_duoc_a`,
                    `prop_phu_hac_thuy_re_duoc_b`,
                    `prop_phu_hac_thuy_re_duoc_c`,
                    `prop_phu_hac_thuy_re_duoc_d`
                ],
                noi: `nuoc_nong`,
                mat: 6,
                cach: 9,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.6,
                con: 1,
                gan: 1.6
            },
            {
                anh: [
                    `prop_phu_hac_thuy_hoa_doc_a`,
                    `prop_phu_hac_thuy_hoa_doc_b`,
                    `prop_phu_hac_thuy_hoa_doc_c`,
                    `prop_phu_hac_thuy_hoa_doc_d`
                ],
                noi: `mep_nuoc`,
                mat: 5,
                cach: 5,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.85,
                con: 2,
                gan: 0.9,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_hac_thuy_hoa_doc_a`,
                    `prop_phu_hac_thuy_hoa_doc_b`,
                    `prop_phu_hac_thuy_hoa_doc_c`,
                    `prop_phu_hac_thuy_hoa_doc_d`
                ],
                noi: `dat`,
                mat: 0.8,
                cach: 6,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.85,
                con: 2,
                gan: 0.9,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_hac_thuy_sen_heo_a`,
                    `prop_phu_hac_thuy_sen_heo_b`,
                    `prop_phu_hac_thuy_sen_heo_c`,
                    `prop_phu_hac_thuy_sen_heo_d`
                ],
                noi: `nuoc_nong`,
                mat: 5,
                cach: 7,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.75,
                con: 1,
                gan: 1.2,
                bong: false
            },
            {
                anh: [
                    `prop_phu_hac_thuy_goc_muc_a`,
                    `prop_phu_hac_thuy_goc_muc_b`,
                    `prop_phu_hac_thuy_goc_muc_c`,
                    `prop_phu_hac_thuy_goc_muc_d`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^dao_thuy_mang$`,
                    r: 22
                },
                mat: 3,
                cach: 8,
                k: [
                    0.75,
                    0.95
                ],
                cum: 0.5,
                gan: 1.4
            },
            {
                anh: [
                    `prop_phu_hac_thuy_xuong_a`,
                    `prop_phu_hac_thuy_xuong_b`,
                    `prop_phu_hac_thuy_xuong_c`,
                    `prop_phu_hac_thuy_xuong_d`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^dao_thuy_mang$`,
                    r: 22
                },
                mat: 3,
                cach: 8,
                k: [
                    0.7,
                    0.9
                ],
                cum: 0.5,
                gan: 1.2
            },
            {
                anh: [
                    `prop_phu_hac_thuy_go_bun_a`,
                    `prop_phu_hac_thuy_go_bun_b`,
                    `prop_phu_hac_thuy_go_bun_c`,
                    `prop_phu_hac_thuy_go_bun_d`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^dao_thuy_mang$`,
                    r: 22
                },
                mat: 3,
                cach: 8,
                k: [
                    0.8,
                    1
                ],
                cum: 0.5,
                gan: 1.4
            },
            {
                anh: [
                    `prop_phu_hac_thuy_go_bun_a`,
                    `prop_phu_hac_thuy_go_bun_b`,
                    `prop_phu_hac_thuy_go_bun_c`,
                    `prop_phu_hac_thuy_go_bun_d`,
                    `prop_phu_hac_thuy_goc_muc_a`,
                    `prop_phu_hac_thuy_goc_muc_b`,
                    `prop_phu_hac_thuy_goc_muc_c`,
                    `prop_phu_hac_thuy_goc_muc_d`
                ],
                noi: `dat`,
                mat: 0.35,
                cach: 12,
                k: [
                    0.8,
                    1
                ],
                cum: 0.6,
                con: 1,
                gan: 1.6
            },
            {
                anh: [
                    `prop_phu_hac_thuy_xuong_a`,
                    `prop_phu_hac_thuy_xuong_b`,
                    `prop_phu_hac_thuy_xuong_c`,
                    `prop_phu_hac_thuy_xuong_d`
                ],
                noi: `dat`,
                mat: 0.1,
                cach: 18,
                k: [
                    0.7,
                    0.9
                ],
                cum: 0.3,
                gan: 1.4
            }
        ],
        dong: {
            suong: {
                so: 9,
                mau: 13030086,
                a: 0.2
            },
            conTrung: 7,
            domDom: 16,
            chim: 0.3,
            chuon: 3
        }
    };
    let be = {
        nen: [
            `nen_bt_dat_ben_a`,
            `nen_bt_dat_ben_b`
        ],
        duong: `nen_bt_cat_song`,
        loai: (e)=>{
            if (e.startsWith(`song`)) {
                return `nuoc`;
            }
            if (e.startsWith(`bien`)) {
                return `rung`;
            }
            return `bo`;
        },
        da: {
            anh: `prop_tl_san_da_lat_a`,
            cao: [
                1.2,
                1.8
            ],
            cot: [
                0.5,
                0.9
            ],
            mat: [
                124,
                116,
                100
            ],
            vach: [
                92,
                86,
                74
            ],
            khe: [
                34,
                32,
                28
            ],
            vien: [
                170,
                162,
                142
            ],
            lo: 0.3
        },
        nuoc: {
            nong: [
                92,
                126,
                108
            ],
            sau: [
                36,
                70,
                80
            ],
            bot: [
                222,
                230,
                218
            ],
            troi: [
                190,
                214,
                222
            ],
            uot: [
                146,
                134,
                110
            ],
            trong: 0.45,
            dong: {
                lap: 60,
                la: 5,
                gon: 4
            }
        },
        san: {
            mau: [
                146,
                138,
                120
            ],
            vua: [
                72,
                64,
                52
            ],
            o: 0.62,
            reu: 0.25,
            reuMau: [
                80,
                102,
                56
            ]
        },
        rung: {
            nen: [
                30,
                44,
                24
            ],
            toi: [
                26,
                48,
                28
            ],
            tan: [
                70,
                112,
                50
            ],
            sang: [
                150,
                182,
                86
            ],
            o: 1.7,
            cao: 6
        },
        dat: {
            soi: 0.07,
            soiMau: [
                150,
                134,
                108
            ],
            mang: 0.45,
            tiB: 0.5,
            phang: 0.35,
            co: 0.1,
            coMau: [
                104,
                124,
                62
            ],
            song: 0.18,
            songMau: [
                0.92,
                0.92,
                0.96
            ]
        },
        bong: {
            dam: 0.4
        },
        tong: [
            1,
            0.99,
            0.97
        ],
        loi: {
            rong: 1,
            dam: 0.6
        },
        loiThem: [
            {
                qua: [
                    `cua_bac`,
                    `loi_dai`,
                    `quang_truong`,
                    `ben_thuong_doi`
                ],
                rong: 3
            },
            {
                qua: [
                    `quang_truong`,
                    `cho_thuong_hoi`,
                    `tram_xe`,
                    `cua_dong`
                ],
                rong: 2.6
            },
            {
                qua: [
                    `quang_truong`,
                    `phuong_do_thach`,
                    `quan_tro`,
                    `ben_thuyen`
                ],
                rong: 2.2
            },
            {
                qua: [
                    `quang_truong`,
                    `dang_ky_bang`,
                    `tru_so_bang`
                ],
                rong: 2
            },
            {
                qua: [
                    `tram_xe`,
                    `chuong_lao_khuyen`
                ],
                rong: 1.8
            }
        ],
        cachChung: 1.1,
        tranhNoi: 3.5,
        do: [
            {
                anh: [
                    `prop_phu_ben_thuong_ven_song_b`,
                    `prop_phu_ben_thuong_ven_song_d`,
                    `prop_trai_clump_ferns`
                ],
                noi: `mep_rung`,
                mat: 120,
                cach: 3.5,
                k: [
                    0.6,
                    0.95
                ],
                lay: true,
                cum: 0.5,
                con: 1,
                gan: 1.1
            },
            {
                anh: [
                    `prop_kho_reeds_clump`,
                    `prop_kho_tall_reeds`
                ],
                noi: `mep_nuoc`,
                mat: 90,
                cach: 2.6,
                k: [
                    0.8,
                    1.1
                ],
                lay: true,
                cum: 0.7,
                con: 1,
                gan: 0.9,
                bong: false
            },
            {
                anh: [
                    `prop_kho_smooth_river_stones`
                ],
                noi: `mep_nuoc`,
                mat: 20,
                cach: 6,
                k: [
                    0.7,
                    0.95
                ],
                cum: 0.5,
                gan: 1.2
            },
            {
                anh: [
                    `nen_bt_co_ven_song`
                ],
                noi: `mep_nuoc`,
                mat: 10,
                cach: 8,
                k: [
                    0.8,
                    1.05
                ],
                bet: true,
                cum: 0.5
            },
            {
                anh: [
                    `prop_kho_short_green_grass_tuft`,
                    `prop_kho_tall_wild_grass`,
                    `prop_kho_clover_patch`
                ],
                noi: `dat`,
                mat: 34,
                cach: 2.6,
                k: [
                    0.7,
                    1
                ],
                lay: true,
                cum: 0.85,
                con: 2,
                gan: 0.8,
                bong: false,
                mau: 15261896
            },
            {
                anh: [
                    `prop_kho_weeds_white_flowers`,
                    `prop_kho_dandelions`,
                    `prop_kho_small_white_wildflowers`
                ],
                noi: `dat`,
                mat: 8,
                cach: 5,
                k: [
                    0.75,
                    1
                ],
                lay: true,
                cum: 0.85,
                con: 1,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `prop_kho_small_pebbles`,
                    `prop_kho_flat_grey_stone`
                ],
                noi: `dat`,
                mat: 6,
                cach: 6,
                k: [
                    0.7,
                    1
                ],
                cum: 0.6,
                gan: 0.9,
                bong: false
            },
            {
                anh: [
                    `prop_trai_three_sacks_grain`,
                    `prop_trai_three_wine_jars_stacked`,
                    `prop_kho_small_crate`,
                    `prop_trai_wooden_crate_lid`,
                    `prop_trai_stack_firewood`,
                    `prop_kho_straw_bundle`,
                    `prop_kho_bamboo_back_basket`,
                    `prop_kho_clay_pot_honey`,
                    `prop_kho_small_bucket`,
                    `prop_kho_coil_rope_wooden`
                ],
                noi: `chan_bo`,
                mat: 75,
                cach: 6,
                k: [
                    0.95,
                    1.2
                ],
                cum: 0.75,
                con: 2,
                gan: 0.75
            },
            {
                anh: [
                    `prop_kho_short_green_grass_tuft`,
                    `prop_kho_tall_wild_grass`,
                    `prop_kho_weeds_white_flowers`
                ],
                noi: `chan_bo`,
                mat: 90,
                cach: 2.6,
                k: [
                    0.75,
                    1.05
                ],
                lay: true,
                cum: 0.7,
                con: 2,
                gan: 0.7,
                bong: false,
                mau: 15261896
            },
            {
                anh: [
                    `nen_bt_dong_hang_le`,
                    `nen_bt_rom_vai`,
                    `nen_bt_van_go_vo`
                ],
                noi: `chan_bo`,
                mat: 16,
                cach: 8,
                k: [
                    0.75,
                    1
                ],
                bet: true,
                cum: 0.5
            },
            {
                anh: [
                    `nen_bt_vet_banh_xe`
                ],
                noi: `dat`,
                mat: 1.6,
                cach: 10,
                k: [
                    0.85,
                    1.05
                ],
                bet: true,
                cum: 0.4
            },
            {
                anh: [
                    `nen_bt_rom_vai`,
                    `nen_bt_van_go_vo`,
                    `prop_tl_rom_vai`
                ],
                noi: `dat`,
                mat: 2.4,
                cach: 10,
                k: [
                    0.75,
                    1
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `prop_phu_ta_gia_trai_chau_a`,
                    `prop_phu_ta_gia_trai_chau_b`,
                    `prop_phu_ta_gia_trai_chau_c`,
                    `prop_phu_ta_gia_trai_chau_d`
                ],
                noi: `chan_bo`,
                mat: 4,
                cach: 9,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.4,
                gan: 1
            },
            {
                anh: [
                    `prop_phu_ta_gia_trai_bon_hoa_a`,
                    `prop_phu_ta_gia_trai_bon_hoa_b`,
                    `prop_phu_ta_gia_trai_bon_hoa_c`,
                    `prop_phu_ta_gia_trai_bon_hoa_d`
                ],
                noi: `chan_bo`,
                mat: 2.4,
                cach: 12,
                k: [
                    0.85,
                    1
                ],
                cum: 0.4,
                gan: 1.3
            },
            {
                anh: [
                    `prop_phu_ta_gia_trai_gian_leo_a`,
                    `prop_phu_ta_gia_trai_gian_leo_b`,
                    `prop_phu_ta_gia_trai_gian_leo_c`,
                    `prop_phu_ta_gia_trai_gian_leo_d`
                ],
                noi: `chan_bo`,
                mat: 1.6,
                cach: 14,
                k: [
                    0.85,
                    1
                ],
                cum: 0.4,
                gan: 1.4
            },
            {
                anh: [
                    `prop_phu_ta_gia_trai_dao_man_a`,
                    `prop_phu_ta_gia_trai_dao_man_b`,
                    `prop_phu_ta_gia_trai_dao_man_c`,
                    `prop_phu_ta_gia_trai_dao_man_d`
                ],
                noi: `dat`,
                mat: 0.4,
                cach: 16,
                k: [
                    0.8,
                    1
                ],
                cum: 0.5,
                gan: 2.4,
                cao: 3
            },
            {
                anh: [
                    `prop_phu_chung_den_lua_a`,
                    `prop_phu_chung_den_lua_b`,
                    `prop_phu_chung_den_lua_c`,
                    `prop_phu_chung_den_lua_d`
                ],
                noi: `chan_bo`,
                mat: 2.5,
                cach: 12,
                k: [
                    0.85,
                    1
                ],
                cum: 0.3,
                gan: 1.4,
                sang: {
                    mau: 16754784,
                    r: 2.6
                }
            },
            {
                anh: [
                    `prop_phu_chung_den_giay_b`,
                    `prop_phu_chung_den_giay_c`,
                    `prop_phu_chung_duoc_b`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^ben_thuyen$`,
                    r: 12
                },
                mat: 14,
                cach: 8,
                k: [
                    0.85,
                    1
                ],
                cum: 0.2,
                gan: 1.6,
                sang: {
                    mau: 16760944,
                    r: 2.8
                }
            },
            {
                anh: [
                    `prop_phu_chung_duoc_a`,
                    `prop_phu_chung_duoc_c`,
                    `prop_phu_chung_den_da_a`,
                    `prop_phu_chung_den_da_d`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^(quang_truong|ban_tho_mieu)$`,
                    r: 12
                },
                mat: 6,
                cach: 10,
                k: [
                    0.85,
                    1
                ],
                cum: 0.2,
                gan: 1.6,
                sang: {
                    mau: 16751168,
                    r: 3
                }
            },
            {
                anh: [
                    `prop_phu_ben_thuong_hang_a`,
                    `prop_phu_ben_thuong_hang_b`,
                    `prop_phu_ben_thuong_hang_c`,
                    `prop_phu_ben_thuong_hang_d`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^(ben_thuong_doi|ben_thuyen|bang_viec_thue)$`,
                    r: 12
                },
                mat: 40,
                cach: 7,
                k: [
                    0.8,
                    1
                ],
                cum: 0.6,
                con: 1,
                gan: 1.3
            },
            {
                anh: [
                    `prop_phu_ben_thuong_luoi_day_a`,
                    `prop_phu_ben_thuong_luoi_day_b`,
                    `prop_phu_ben_thuong_luoi_day_c`,
                    `prop_phu_ben_thuong_luoi_day_d`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^(ben_thuong_doi|ben_thuyen)$`,
                    r: 12
                },
                mat: 26,
                cach: 8,
                k: [
                    0.8,
                    1
                ],
                cum: 0.4,
                gan: 1.4
            },
            {
                anh: [
                    `prop_phu_ben_thuong_cay_pho_a`,
                    `prop_phu_ben_thuong_cay_pho_b`,
                    `prop_phu_ben_thuong_cay_pho_c`,
                    `prop_phu_ben_thuong_cay_pho_d`
                ],
                noi: `chan_bo`,
                quanh: {
                    noi: `^(cho_thuong_hoi|bang_dat_hang|quang_truong|phuong_do_thach)$`,
                    r: 14
                },
                mat: 22,
                cach: 10,
                k: [
                    1.5,
                    1.75
                ],
                cum: 0.3,
                gan: 2
            },
            {
                anh: [
                    `prop_phu_ben_thuong_ven_song_a`,
                    `prop_phu_ben_thuong_ven_song_c`
                ],
                noi: `mep_nuoc`,
                mat: 14,
                cach: 6,
                k: [
                    0.8,
                    1
                ],
                lay: true,
                cum: 0.6,
                con: 1,
                gan: 1,
                bong: false
            }
        ],
        dong: {
            la: {
                so: 6,
                mau: [
                    7244346,
                    9083458,
                    10521154
                ]
            },
            conTrung: 2,
            chim: 1,
            domDom: 6,
            bui: {
                so: 8,
                mau: 13152394
            },
            chuon: 2
        }
    };
    let xe = {
        v1: [
            4.2,
            7.05
        ],
        v2: [
            25.6,
            6.65
        ],
        v3: [
            3.6,
            13.53
        ],
        v4: [
            26.4,
            12.86
        ],
        v5: [
            9.5,
            4.63
        ]
    };
    let z = (e)=>({
            x: xe[e][0],
            y: xe[e][1]
        });
    let Se = (e, t)=>(n)=>{
            if (n === `tuong_bac`) {
                return e;
            }
            if (n === `khan_dai`) {
                return t;
            }
            return `bo`;
        };
    let B = {
        mau: `#ffb060`,
        r: 3.2,
        lua: true
    };
    let Ce = {
        mau: `#ffd890`,
        r: 2.6
    };
    let we = {
        nen: [
            `nen_bt_dat_ben_a`,
            `nen_bt_dat_ben_b`
        ],
        duong: `nen_bt_cat_song`,
        loai: Se(`the`, `bo`),
        da: {
            anh: `prop_tl_san_da_lat_a`,
            cao: [
                1.6,
                2.2
            ],
            cot: [
                0.5,
                0.9
            ],
            mat: [
                126,
                118,
                102
            ],
            vach: [
                94,
                88,
                76
            ],
            khe: [
                34,
                32,
                28
            ],
            vien: [
                172,
                164,
                144
            ],
            lo: 0.25
        },
        the: {
            mat: [
                128,
                120,
                104
            ],
            vach: [
                96,
                90,
                78
            ],
            khe: [
                36,
                34,
                30
            ],
            vien: [
                176,
                168,
                148
            ],
            reu: {
                mau: [
                    80,
                    102,
                    56
                ],
                mat: 0.3
            }
        },
        san: {
            mau: [
                146,
                138,
                120
            ],
            vua: [
                70,
                62,
                50
            ],
            o: 0.7,
            reu: 0.2,
            reuMau: [
                80,
                102,
                56
            ]
        },
        sanThem: [
            [
                [
                    4,
                    4.6
                ],
                [
                    26,
                    4.6
                ],
                [
                    26,
                    23.6
                ],
                [
                    4,
                    23.6
                ]
            ]
        ],
        dat: {
            soi: 0.07,
            soiMau: [
                150,
                134,
                108
            ],
            mang: 0.45,
            tiB: 0.5,
            phang: 0.35,
            co: 0.08,
            coMau: [
                104,
                124,
                62
            ]
        },
        bong: {
            dam: 0.4
        },
        tong: [
            1,
            0.99,
            0.97
        ],
        loi: {
            rong: 1,
            dam: 0.6
        },
        vatThem: [
            {
                hinh: `prop_pg27_khan_dai_go`,
                x: 3.4,
                y: 29.6
            },
            {
                hinh: `prop_pg27_khan_dai_go`,
                x: 9.4,
                y: 29.6,
                lat: true
            },
            {
                hinh: `prop_pg27_khan_dai_go`,
                x: 20.6,
                y: 29.6
            },
            {
                hinh: `prop_pg27_khan_dai_go`,
                x: 26.6,
                y: 29.6,
                lat: true
            },
            {
                hinh: `prop_pg25_co_thuong_gia_cot`,
                x: 13.1,
                y: 26.4
            },
            {
                hinh: `prop_pg25_co_thuong_gia_cot`,
                x: 16.9,
                y: 26.4,
                lat: true
            },
            {
                hinh: `prop_pg_day_den_long`,
                x: 8,
                y: 3.1,
                den: Ce
            },
            {
                hinh: `prop_pg_day_den_long`,
                x: 22,
                y: 3.1,
                lat: true,
                den: Ce
            },
            {
                hinh: `prop_pg27_bao_cat_treo`,
                ...z(`v1`)
            },
            {
                hinh: `prop_pg25_trong_tran`,
                ...z(`v2`)
            },
            {
                hinh: `prop_trai_bronze_incense_burner`,
                ...z(`v3`)
            },
            {
                hinh: `prop_pg27_gia_binh_khi_tre`,
                ...z(`v4`)
            },
            {
                hinh: `prop_trai_wooden_notice_board`,
                ...z(`v5`)
            },
            {
                hinh: `prop_phu_chung_duoc_a`,
                x: 4.6,
                y: 23.2,
                k: 0.5,
                den: B
            },
            {
                hinh: `prop_phu_chung_duoc_b`,
                x: 25.4,
                y: 23.2,
                k: 0.5,
                den: B
            },
            {
                hinh: `prop_phu_chung_duoc_c`,
                x: 13.2,
                y: 4.9,
                k: 0.5,
                den: B
            },
            {
                hinh: `prop_phu_chung_duoc_d`,
                x: 16.8,
                y: 4.9,
                k: 0.5,
                den: B
            }
        ],
        cachChung: 1.1,
        tranhNoi: 2.2,
        do: [
            {
                anh: [
                    `prop_kho_short_green_grass_tuft`,
                    `prop_kho_tall_wild_grass`,
                    `prop_kho_clover_patch`
                ],
                noi: `dat`,
                mat: 140,
                cach: 2.2,
                k: [
                    0.7,
                    1
                ],
                lay: true,
                cum: 0.85,
                con: 2,
                gan: 0.7,
                bong: false,
                mau: 15261896
            },
            {
                anh: [
                    `prop_kho_small_pebbles`,
                    `prop_kho_flat_grey_stone`
                ],
                noi: `dat`,
                mat: 8,
                cach: 6,
                k: [
                    0.7,
                    1
                ],
                cum: 0.6,
                gan: 0.9,
                bong: false
            },
            {
                anh: [
                    `prop_trai_three_sacks_grain`,
                    `prop_trai_three_wine_jars_stacked`,
                    `prop_kho_small_crate`,
                    `prop_trai_wooden_crate_lid`
                ],
                noi: `chan_bo`,
                mat: 12,
                cach: 5,
                k: [
                    0.85,
                    1
                ],
                cum: 0.5,
                gan: 1.2
            },
            {
                anh: [
                    `nen_bt_dong_hang_le`,
                    `nen_bt_rom_vai`
                ],
                noi: `chan_bo`,
                mat: 6,
                cach: 8,
                k: [
                    0.75,
                    1
                ],
                bet: true,
                cum: 0.5
            },
            {
                anh: [
                    `prop_phu_ben_thuong_hang_a`,
                    `prop_phu_ben_thuong_hang_b`,
                    `prop_phu_ben_thuong_hang_c`,
                    `prop_phu_ben_thuong_hang_d`
                ],
                noi: `dat`,
                mat: 14,
                cach: 5,
                k: [
                    0.85,
                    1
                ],
                cum: 0.6,
                gan: 1.3
            }
        ]
    };
    let inst_tru_so_bang = {
        nen: [
            `prop_tl_san_dat_nen_a`,
            `prop_tl_san_dat_nen_b`
        ],
        duong: `prop_tl_san_dat_nen_a`,
        loai: Se(`the`, `bo`),
        the: {
            mat: [
                128,
                120,
                104
            ],
            vach: [
                92,
                86,
                74
            ],
            khe: [
                36,
                34,
                30
            ],
            vien: [
                178,
                170,
                150
            ],
            reu: {
                mau: [
                    84,
                    108,
                    50
                ],
                mat: 0.3
            }
        },
        da: {
            anh: `prop_tl_san_da_lat_a`,
            cao: [
                1.2,
                1.8
            ],
            cot: [
                0.5,
                0.9
            ],
            mat: [
                124,
                118,
                102
            ],
            vach: [
                90,
                84,
                72
            ],
            khe: [
                34,
                32,
                28
            ],
            vien: [
                176,
                170,
                150
            ],
            lo: 0.2
        },
        san: {
            mau: [
                150,
                142,
                128
            ],
            vua: [
                58,
                52,
                44
            ],
            o: 0.86,
            reu: 0.35,
            reuMau: [
                84,
                108,
                50
            ]
        },
        sanThem: [
            [
                [
                    3,
                    4.2
                ],
                [
                    27,
                    4.2
                ],
                [
                    27,
                    24.6
                ],
                [
                    3,
                    24.6
                ]
            ]
        ],
        dat: {
            soi: 0.05,
            soiMau: [
                128,
                124,
                108
            ],
            mang: 0.5
        },
        bong: {
            dam: 0.42
        },
        tong: [
            0.99,
            1,
            0.98
        ],
        loi: {
            rong: 1,
            dam: 0.6
        },
        vatThem: [
            {
                hinh: `prop_trai_ancestral_hall_b`,
                x: 15,
                y: 3.05
            },
            {
                hinh: `prop_pg_nha_thu_ky_bang`,
                x: 5.6,
                y: 3.05
            },
            {
                hinh: `prop_pg_nha_thu_ky_bang`,
                x: 24.4,
                y: 3.05,
                lat: true
            },
            {
                hinh: `prop_pg_cong_tru_so_bang`,
                x: 15,
                y: 29.8
            },
            {
                hinh: `prop_gpt_tuong_tu_duong_a`,
                x: 3.2,
                y: 27
            },
            {
                hinh: `prop_gpt_tuong_tu_duong_b`,
                x: 7.2,
                y: 27
            },
            {
                hinh: `prop_gpt_tuong_tu_duong_a`,
                x: 22.8,
                y: 27,
                lat: true
            },
            {
                hinh: `prop_gpt_tuong_tu_duong_b`,
                x: 26.8,
                y: 27,
                lat: true
            },
            {
                hinh: `prop_phu_chung_den_da_a`,
                x: 11.8,
                y: 8.8,
                k: 0.5,
                den: Ce
            },
            {
                hinh: `prop_phu_chung_den_da_a`,
                x: 18.2,
                y: 8.8,
                k: 0.5,
                lat: true,
                den: Ce
            },
            {
                hinh: `prop_phu_chung_den_da_b`,
                x: 11.8,
                y: 21.6,
                k: 0.5,
                den: Ce
            },
            {
                hinh: `prop_phu_chung_den_da_b`,
                x: 18.2,
                y: 21.6,
                k: 0.5,
                lat: true,
                den: Ce
            },
            {
                hinh: `prop_trai_bronze_incense_burner`,
                x: 12.6,
                y: 14.6
            },
            {
                hinh: `prop_trai_bronze_incense_burner`,
                x: 17.4,
                y: 14.6,
                lat: true
            },
            {
                hinh: `prop_pg25_trong_tran`,
                x: 22.4,
                y: 18.4
            },
            {
                hinh: `prop_trai_small_stone_lantern`,
                ...z(`v1`)
            },
            {
                hinh: `prop_pg27_gia_binh_khi_tre`,
                ...z(`v2`)
            },
            {
                hinh: `prop_trai_large_clay_water_vat`,
                ...z(`v3`)
            },
            {
                hinh: `prop_trai_weapon_rack`,
                ...z(`v4`)
            },
            {
                hinh: `prop_trai_wooden_notice_board`,
                ...z(`v5`)
            }
        ],
        cachChung: 1.1,
        tranhNoi: 2.4,
        do: [
            {
                anh: [
                    `prop_kho_short_green_grass_tuft`,
                    `prop_kho_clover_patch`
                ],
                noi: `dat`,
                mat: 140,
                cach: 2.2,
                k: [
                    0.7,
                    1
                ],
                lay: true,
                cum: 0.85,
                con: 2,
                gan: 0.7,
                bong: false
            },
            {
                anh: [
                    `prop_trai_large_clay_water_vat`,
                    `prop_trai_stack_firewood`,
                    `prop_kho_small_crate`
                ],
                noi: `chan_bo`,
                mat: 6,
                cach: 7,
                k: [
                    0.85,
                    1
                ],
                cum: 0.4,
                gan: 1.3
            },
            {
                anh: [
                    `prop_phu_ta_gia_trai_chau_a`,
                    `prop_phu_ta_gia_trai_chau_b`,
                    `prop_phu_ta_gia_trai_chau_c`,
                    `prop_phu_ta_gia_trai_chau_d`
                ],
                noi: `dat`,
                mat: 12,
                cach: 6,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.4,
                gan: 1.2
            },
            {
                anh: [
                    `prop_phu_ta_gia_trai_bon_hoa_a`,
                    `prop_phu_ta_gia_trai_bon_hoa_b`
                ],
                noi: `chan_bo`,
                mat: 3,
                cach: 9,
                k: [
                    0.85,
                    1
                ],
                cum: 0.4,
                gan: 1.4
            }
        ]
    };
    function V(e) {
        let t = e === `dau_bong` ? {
            mau: `#8fb8ff`,
            r: 3.4
        } : B;
        return {
            nen: [
                `nen_bl_tuyet_a`,
                `nen_bl_tuyet_mong`
            ],
            duong: `nen_bl_dat_bun_tuyet`,
            loai: Se(`da`, `da`),
            da: {
                anh: `nen_ms_da_vach_hang`,
                cao: [
                    2.6,
                    3.8
                ],
                cot: [
                    0.55,
                    1.15
                ],
                mat: [
                    112,
                    116,
                    126
                ],
                vach: [
                    80,
                    85,
                    98
                ],
                khe: [
                    24,
                    26,
                    36
                ],
                vien: [
                    182,
                    190,
                    204
                ],
                tam: 1.6,
                lo: 0.4,
                tuyet: 0.55,
                hat: 0.45
            },
            san: {
                mau: e === `dau_bong` ? [
                    96,
                    102,
                    116
                ] : [
                    128,
                    130,
                    134
                ],
                vua: [
                    52,
                    54,
                    62
                ],
                o: 1.1,
                reu: 0.15,
                reuMau: [
                    92,
                    110,
                    96
                ]
            },
            sanThem: [
                [
                    [
                        5,
                        5.5
                    ],
                    [
                        25,
                        5.5
                    ],
                    [
                        25,
                        23
                    ],
                    [
                        5,
                        23
                    ]
                ]
            ],
            dat: {
                soi: 0.04,
                soiMau: [
                    138,
                    144,
                    158
                ],
                mang: 0.3,
                tiB: 0.5,
                phang: 0.6,
                song: 0.4,
                songMau: [
                    0.8,
                    0.87,
                    1
                ],
                lap: 0.4
            },
            bong: {
                dam: 0.42
            },
            tong: e === `dau_bong` ? [
                0.9,
                0.94,
                1.06
            ] : e === `giu_den` ? [
                0.96,
                0.95,
                1
            ] : [
                0.98,
                1,
                1.02
            ],
            loi: {
                rong: 1,
                dam: 0.42
            },
            ...e === `dau_bong` ? {
                dong: {
                    suong: {
                        so: 9,
                        mau: 12898532,
                        a: 0.32
                    }
                }
            } : {},
            vatThem: [
                {
                    hinh: `prop_pg25_cong_truyen_thua`,
                    x: 15,
                    y: 3.1
                },
                {
                    hinh: `prop_pg25_bia_co_tuyet`,
                    x: 9.2,
                    y: 3.3
                },
                {
                    hinh: `prop_pg25_bia_co_tuyet`,
                    x: 20.8,
                    y: 3.3,
                    lat: true
                },
                {
                    hinh: `prop_gpt_cot_da_do`,
                    x: 5.6,
                    y: 23.6,
                    k: 0.7
                },
                {
                    hinh: `prop_gpt_cot_da_do`,
                    x: 24.4,
                    y: 23.6,
                    k: 0.7,
                    lat: true
                },
                {
                    hinh: `prop_pg25_bia_co_tuyet`,
                    ...z(`v1`),
                    k: 0.7
                },
                {
                    hinh: `prop_kho_cracked_grey_stone`,
                    ...z(`v2`),
                    k: 1.4
                },
                {
                    hinh: `prop_phu_chung_den_da_b`,
                    ...z(`v3`),
                    k: 0.5,
                    den: t
                },
                {
                    hinh: `prop_kho_cracked_grey_stone`,
                    ...z(`v4`),
                    k: 1.6,
                    lat: true
                },
                {
                    hinh: `prop_phu_chung_den_da_a`,
                    ...z(`v5`),
                    k: 0.5,
                    den: t
                },
                ...e === `giu_den` ? [
                    {
                        hinh: `prop_phu_chung_duoc_a`,
                        x: 4.4,
                        y: 14,
                        k: 0.5,
                        den: B
                    },
                    {
                        hinh: `prop_phu_chung_duoc_b`,
                        x: 25.6,
                        y: 14,
                        k: 0.5,
                        den: B
                    },
                    {
                        hinh: `prop_phu_chung_duoc_c`,
                        x: 15,
                        y: 6.4,
                        k: 0.5,
                        den: B
                    }
                ] : [],
                ...e === `dau_bong` ? [
                    {
                        hinh: `prop_phu_chung_den_da_a`,
                        x: 6,
                        y: 6.4,
                        k: 0.5,
                        den: t
                    },
                    {
                        hinh: `prop_phu_chung_den_da_a`,
                        x: 24,
                        y: 6.4,
                        k: 0.5,
                        lat: true,
                        den: t
                    }
                ] : []
            ],
            cachChung: 1.2,
            tranhNoi: 2.4,
            do: [
                {
                    anh: [
                        `prop_kho_cracked_grey_stone`,
                        `prop_kho_flat_grey_stone`,
                        `prop_kho_small_pebbles`
                    ],
                    noi: `chan_vach`,
                    mat: 40,
                    cach: 3,
                    k: [
                        0.7,
                        1.1
                    ],
                    cum: 0.6,
                    gan: 0.9,
                    sat: 0.8
                },
                {
                    anh: [
                        `nen_bl_bui_kho_tuyet`,
                        `nen_bl_go_tuyet_nho`
                    ],
                    noi: `dat`,
                    mat: 8,
                    cach: 6,
                    k: [
                        0.8,
                        1
                    ],
                    bet: true,
                    cum: 0.6
                },
                ...e === `do_thach` ? [
                    {
                        anh: [
                            `nen_mc_dong_da_vun`,
                            `nen_mc_vet_quang`,
                            `nen_mc_soi_da`
                        ],
                        noi: `dat`,
                        mat: 14,
                        cach: 5,
                        k: [
                            0.8,
                            1.05
                        ],
                        bet: true,
                        cum: 0.5
                    }
                ] : []
            ]
        };
    }
    let inst_tt_dau_bong = V(`dau_bong`);
    let inst_tt_do_thach = V(`do_thach`);
    let inst_tt_giu_den = V(`giu_den`);
    let ke = {
        x: 15,
        y: 14
    };
    let H = {
        v1: [
            4.2,
            7.05
        ],
        v2: [
            25.6,
            6.65
        ],
        v3: [
            3.6,
            13.53
        ],
        v4: [
            26.4,
            12.86
        ],
        v5: [
            9.5,
            4.63
        ]
    };
    let U = (e)=>({
            x: H[e][0],
            y: H[e][1]
        });
    let W = (e)=>{
        if (e === `tuong_bac`) {
            return `the`;
        }
        if (e === `khan_dai`) {
            return `da`;
        }
        return `bo`;
    };
    let Ae = {
        hinh: `prop_tl_vong_tran_dot_pha`,
        rong: 512,
        cao: 508
    };
    function je(e, t, n) {
        let r = n * 32 / (Ae.rong / 2);
        return {
            hinh: Ae.hinh,
            x: e,
            y: Math.round((t + 0.45 * Ae.cao * r / 32) * 100) / 100,
            k: Math.round(r * 1000) / 1000,
            nen: true
        };
    }
    let G = {
        mau: `#7fe8dc`,
        r: 3
    };
    let Me = {
        mau: `#7fe8dc`,
        r: 2.2
    };
    let Ne = {
        mau: `#b8a0ff`,
        r: 3
    };
    let Pe = {
        mau: `#b8a0ff`,
        r: 2.2
    };
    let inst_thap_thi_luyen = {
        nen: [
            `prop_tl_san_dot_pha_a`,
            `prop_tl_san_dot_pha_b`
        ],
        duong: `prop_tl_san_dot_pha_b`,
        loai: W,
        the: {
            mat: [
                74,
                78,
                90
            ],
            vach: [
                62,
                66,
                78
            ],
            khe: [
                20,
                22,
                30
            ],
            vien: [
                132,
                140,
                156
            ],
            hat: 0.5,
            caoMax: 3.4
        },
        da: {
            anh: `prop_tl_vach_dot_pha`,
            cao: [
                2.8,
                3.6
            ],
            cot: [
                0.6,
                1
            ],
            mat: [
                68,
                72,
                84
            ],
            vach: [
                58,
                62,
                74
            ],
            khe: [
                18,
                20,
                28
            ],
            vien: [
                126,
                134,
                150
            ],
            tam: 1.3,
            lo: 0.4,
            hat: 0.5,
            vat: 0.2,
            khoi: 1.4,
            mach: {
                mau: [
                    96,
                    224,
                    212
                ],
                mat: 0.22,
                den: {
                    r: 1.1,
                    mau: 7334104,
                    cach: 4.5
                }
            }
        },
        vungNen: [
            {
                anh: `prop_tl_san_dot_pha_a`,
                tam: [
                    ke.x,
                    ke.y
                ],
                r: [
                    8.4,
                    8.4
                ],
                mem: 2.6,
                nhan: [
                    1.3,
                    1.36,
                    1.4
                ]
            }
        ],
        dat: {
            soi: 0.03,
            soiMau: [
                100,
                104,
                116
            ],
            mang: 0.3,
            tiB: 0.15,
            phang: 0.15
        },
        bong: {
            dam: 0.45
        },
        tong: [
            0.9,
            0.93,
            1
        ],
        loi: {
            rong: 1,
            dam: 0.3
        },
        dong: {
            hatSang: {
                so: 14,
                mau: 9433312
            }
        },
        vatThem: [
            je(ke.x, ke.y, 3.3),
            {
                hinh: `prop_pg_bac_xuong_ben`,
                x: 15,
                y: 3.1,
                k: 1.3
            },
            {
                hinh: `prop_t15_tuong_lau_cot`,
                x: 12.4,
                y: 3.15
            },
            {
                hinh: `prop_t15_tuong_lau_cot`,
                x: 17.6,
                y: 3.15,
                lat: true
            },
            {
                hinh: `prop_t15_tuong_lau_cot`,
                x: 5,
                y: 3.15
            },
            {
                hinh: `prop_t15_tuong_lau_cot`,
                x: 25,
                y: 3.15,
                lat: true
            },
            {
                hinh: `prop_pg25_gia_den_vach`,
                x: 7.4,
                y: 3.1,
                den: Me
            },
            {
                hinh: `prop_pg25_gia_den_vach`,
                x: 22.6,
                y: 3.1,
                lat: true,
                den: Me
            },
            {
                hinh: `prop_pg25_gia_den_vach`,
                x: 1.8,
                y: 3.1,
                den: Me
            },
            {
                hinh: `prop_pg25_gia_den_vach`,
                x: 28.2,
                y: 3.1,
                lat: true,
                den: Me
            },
            {
                hinh: `prop_t15_tuong_lau_cot`,
                x: 5,
                y: 25.05
            },
            {
                hinh: `prop_t15_tuong_lau_cot`,
                x: 10.5,
                y: 25.05
            },
            {
                hinh: `prop_t15_tuong_lau_cot`,
                x: 19.5,
                y: 25.05,
                lat: true
            },
            {
                hinh: `prop_t15_tuong_lau_cot`,
                x: 25,
                y: 25.05,
                lat: true
            },
            {
                hinh: `prop_phu_chung_den_da_a`,
                x: 7,
                y: 6.6,
                k: 0.5,
                den: G
            },
            {
                hinh: `prop_phu_chung_den_da_a`,
                x: 23,
                y: 6.6,
                k: 0.5,
                lat: true,
                den: G
            },
            {
                hinh: `prop_phu_chung_den_da_c`,
                x: 7,
                y: 21.6,
                k: 0.5,
                den: G
            },
            {
                hinh: `prop_phu_chung_den_da_c`,
                x: 23,
                y: 21.6,
                k: 0.5,
                lat: true,
                den: G
            },
            {
                hinh: `prop_trai_bronze_incense_burner`,
                ...U(`v1`),
                k: 1.3
            },
            {
                hinh: `prop_pg25_mach_thach_vach`,
                ...U(`v2`),
                k: 0.75
            },
            {
                hinh: `prop_phu_chung_den_da_b`,
                ...U(`v3`),
                k: 0.5,
                den: Me
            },
            {
                hinh: `prop_gpt_gia_sach_tang_kinh`,
                ...U(`v4`),
                k: 0.72,
                lat: true
            },
            {
                hinh: `prop_kho_small_stone_stele`,
                ...U(`v5`),
                k: 1.6
            }
        ],
        cachChung: 1.1,
        tranhNoi: 2.2,
        do: [
            {
                anh: [
                    `prop_kho_cracked_grey_stone`,
                    `prop_kho_flat_grey_stone`,
                    `prop_kho_rubble_pile`
                ],
                noi: `chan_vach`,
                mat: 380,
                cach: 2.6,
                k: [
                    0.7,
                    1.05
                ],
                cum: 0.6,
                gan: 0.8,
                sat: 1,
                mau: 12896984
            },
            {
                anh: [
                    `prop_kho_small_pebbles`,
                    `prop_kho_flat_grey_stone`
                ],
                noi: `dat`,
                mat: 45,
                cach: 3,
                k: [
                    0.7,
                    1
                ],
                cum: 0.7,
                con: 1,
                gan: 0.9,
                bong: false,
                mau: 13159640,
                nen: {
                    ngoai: 0
                }
            },
            {
                anh: [
                    `prop_kho_small_bones`,
                    `prop_kho_rib_bones`,
                    `prop_kho_small_animal_skull`
                ],
                noi: `chan_vach`,
                mat: 40,
                cach: 6,
                k: [
                    0.8,
                    1
                ],
                cum: 0.5,
                gan: 1.2,
                sat: 1.2
            },
            {
                anh: [
                    `prop_tl_vet_nut_san`
                ],
                noi: `dat`,
                mat: 4,
                cach: 9,
                k: [
                    0.4,
                    0.6
                ],
                bet: true,
                cum: 0.4,
                nen: {
                    ngoai: 0
                }
            },
            {
                anh: [
                    `nen_ms_mach_nguyen_thach`
                ],
                noi: `chan_vach`,
                mat: 30,
                cach: 9,
                k: [
                    0.55,
                    0.8
                ],
                bet: true,
                cum: 0.4,
                sat: 1
            }
        ],
        voDai: false
    };
    let inst_loi_dai_bong = {
        nen: [
            `prop_tl_san_lau_a`,
            `prop_tl_san_lau_b`
        ],
        duong: `prop_tl_san_lau_b`,
        loai: W,
        the: {
            mat: [
                138,
                136,
                156
            ],
            vach: [
                106,
                104,
                126
            ],
            khe: [
                40,
                38,
                54
            ],
            vien: [
                196,
                192,
                218
            ],
            hat: 0.4,
            caoMax: 3
        },
        da: {
            anh: `nen_ms_da_vach_hang`,
            cao: [
                2.4,
                3.2
            ],
            cot: [
                0.55,
                0.95
            ],
            mat: [
                132,
                130,
                150
            ],
            vach: [
                100,
                98,
                120
            ],
            khe: [
                36,
                34,
                50
            ],
            vien: [
                192,
                188,
                214
            ],
            tam: 1.5,
            lo: 0.25,
            hat: 0.4,
            vat: 0.22,
            mach: {
                mau: [
                    176,
                    150,
                    255
                ],
                mat: 0.24,
                den: {
                    r: 1.1,
                    mau: 11836671,
                    cach: 4.5
                }
            }
        },
        vungNen: [
            {
                anh: `prop_tl_san_lau_b`,
                tam: [
                    ke.x,
                    ke.y
                ],
                r: [
                    9,
                    9
                ],
                mem: 1.6,
                nhan: [
                    0.74,
                    0.72,
                    0.86
                ]
            }
        ],
        dat: {
            soi: 0.02,
            soiMau: [
                150,
                148,
                168
            ],
            mang: 0.3,
            tiB: 0.5,
            phang: 0.2
        },
        bong: {
            dam: 0.38
        },
        tong: [
            0.92,
            0.92,
            1.03
        ],
        loi: {
            rong: 1,
            dam: 0.3
        },
        dong: {
            suong: {
                so: 7,
                mau: 13156584,
                a: 0.26
            },
            hatSang: {
                so: 16,
                mau: 13220095
            }
        },
        vatThem: [
            je(ke.x, ke.y, 7.9),
            {
                hinh: `prop_pg25_cum_tinh_the_lon`,
                x: 15,
                y: 4.3,
                den: Ne
            },
            {
                hinh: `prop_pg25_cum_tinh_the_lon`,
                x: 15,
                y: 24.3,
                lat: true,
                den: Ne
            },
            {
                hinh: `prop_pg25_cum_tinh_the_lon`,
                x: 5.2,
                y: 14.4,
                lat: true,
                den: Ne
            },
            {
                hinh: `prop_pg25_cum_tinh_the_lon`,
                x: 24.8,
                y: 14.4,
                den: Ne
            },
            {
                hinh: `prop_phu_chung_den_da_d`,
                x: 8.1,
                y: 7.1,
                k: 0.5,
                den: Pe
            },
            {
                hinh: `prop_phu_chung_den_da_d`,
                x: 21.9,
                y: 7.1,
                k: 0.5,
                lat: true,
                den: Pe
            },
            {
                hinh: `prop_phu_chung_den_da_d`,
                x: 8.1,
                y: 20.9,
                k: 0.5,
                den: Pe
            },
            {
                hinh: `prop_phu_chung_den_da_d`,
                x: 21.9,
                y: 20.9,
                k: 0.5,
                lat: true,
                den: Pe
            },
            {
                hinh: `prop_pg25_gia_den_vach`,
                x: 6,
                y: 3.1,
                den: Pe
            },
            {
                hinh: `prop_pg25_gia_den_vach`,
                x: 11,
                y: 3.1,
                den: Pe
            },
            {
                hinh: `prop_pg25_gia_den_vach`,
                x: 19,
                y: 3.1,
                lat: true,
                den: Pe
            },
            {
                hinh: `prop_pg25_gia_den_vach`,
                x: 24,
                y: 3.1,
                lat: true,
                den: Pe
            },
            {
                hinh: `prop_pg25_mach_thach_vach`,
                ...U(`v1`),
                k: 0.7
            },
            {
                hinh: `prop_pg25_mach_thach_vach`,
                ...U(`v2`),
                k: 0.75,
                lat: true
            },
            {
                hinh: `prop_pg25_mach_thach_vach`,
                ...U(`v3`),
                k: 0.7
            },
            {
                hinh: `prop_pg25_mach_thach_vach`,
                ...U(`v4`),
                k: 0.75,
                lat: true
            },
            {
                hinh: `prop_phu_chung_den_da_b`,
                ...U(`v5`),
                k: 0.5,
                den: Pe
            }
        ],
        cachChung: 1.1,
        tranhNoi: 2.2,
        do: [
            {
                anh: [
                    `prop_kho_cracked_grey_stone`,
                    `prop_kho_flat_grey_stone`
                ],
                noi: `chan_vach`,
                mat: 300,
                cach: 2.6,
                k: [
                    0.7,
                    1
                ],
                cum: 0.6,
                gan: 0.8,
                sat: 1,
                mau: 13683940
            },
            {
                anh: [
                    `prop_kho_pale_blue_crystals`,
                    `prop_phu_mach_sau_tinh_the`
                ],
                noi: `chan_vach`,
                mat: 90,
                cach: 4,
                k: [
                    0.7,
                    1
                ],
                cum: 0.6,
                gan: 1.1,
                sat: 1,
                mau: 14734591
            },
            {
                anh: [
                    `prop_kho_small_pebbles`,
                    `prop_kho_flat_grey_stone`
                ],
                noi: `dat`,
                mat: 30,
                cach: 3.5,
                k: [
                    0.7,
                    1
                ],
                cum: 0.7,
                con: 1,
                gan: 0.9,
                bong: false,
                mau: 14999792,
                nen: {
                    ngoai: 0
                }
            },
            {
                anh: [
                    `prop_kho_pale_blue_crystals`
                ],
                noi: `dat`,
                mat: 10,
                cach: 6,
                k: [
                    0.6,
                    0.85
                ],
                cum: 0.5,
                gan: 1.2,
                mau: 14734591,
                nen: {
                    ngoai: 0
                }
            }
        ],
        voDai: false
    };
    let zone_luc_bien = {
        nen: [
            `nen_lgb_dat_vang_a`,
            `nen_lgb_dat_vang_b`
        ],
        duong: `nen_lgb_dat_vang_b`,
        da: {
            anh: `nen_ms_da_vach_hang`,
            kieuMat: `dat`,
            matAnh: `nen_lgb_dat_vang_a`,
            cao: [
                2.2,
                3.6
            ],
            cot: [
                0.8,
                1.7
            ],
            mat: [
                128,
                92,
                52
            ],
            vach: [
                104,
                92,
                82
            ],
            khe: [
                26,
                20,
                18
            ],
            vien: [
                196,
                160,
                104
            ],
            lo: 0.9,
            bui: 0.4,
            co: [
                176,
                138,
                64
            ],
            hat: 0.5,
            khoi: 2.2,
            tron: 0.7,
            ben: 2.2,
            loang: 0.7
        },
        dat: {
            soi: 0.13,
            soiMau: [
                150,
                140,
                128
            ],
            mang: 0.85,
            tiB: 0.45,
            cong: 0.55,
            diu: 0.4
        },
        vungNen: [
            {
                anh: `nen_lgb_dat_mo_lo_thien`,
                noi: `mo_lo_thien`,
                r: [
                    27,
                    21
                ],
                mem: 6,
                dam: 0.85
            }
        ],
        bong: {
            dam: 0.5
        },
        tong: [
            1.08,
            1.03,
            0.96
        ],
        loi: {
            rong: 1.1,
            dam: 0.75,
            vet: {
                rong: 3,
                dam: 0.6
            }
        },
        cachChung: 1.2,
        tranhNoi: 2.2,
        do: [
            {
                anh: [
                    `prop_phu_luc_bien_cay_kho`
                ],
                noi: `dinh`,
                mat: 2,
                cach: 9,
                k: [
                    0.75,
                    1.1
                ],
                cum: 0.5,
                gan: 2.4,
                cao: 2.8
            },
            {
                anh: [
                    `prop_phu_luc_bien_bui_gai`,
                    `prop_phu_luc_bien_bui_kho`
                ],
                noi: `dinh`,
                mat: 9,
                cach: 5,
                k: [
                    0.65,
                    1
                ],
                lay: true,
                cum: 0.6,
                con: 1,
                gan: 1.3
            },
            {
                anh: [
                    `prop_phu_luc_bien_mom_da`,
                    `prop_phu_luc_bien_da_cum`,
                    `prop_phu_luc_bien_da_chong`
                ],
                noi: `dinh`,
                mat: 5,
                cach: 7,
                k: [
                    0.6,
                    0.95
                ],
                cum: 0.6,
                con: 1,
                gan: 1.5,
                mau: 15262944
            },
            {
                anh: [
                    `prop_phu_luc_bien_co_kho`,
                    `prop_kho_dry_yellow_grass_tuft`
                ],
                noi: `dinh`,
                mat: 22,
                cach: 2.6,
                k: [
                    0.55,
                    0.9
                ],
                lay: true,
                cum: 0.8,
                con: 3,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `prop_phu_luc_bien_da_vun`,
                    `prop_phu_luc_bien_da_chong`
                ],
                noi: `mep_dinh`,
                mat: 220,
                cach: 3,
                k: [
                    0.4,
                    0.8
                ],
                cum: 0.4,
                con: 2,
                gan: 0.95,
                mau: 15789288
            },
            {
                anh: [
                    `prop_phu_luc_bien_co_kho`,
                    `prop_kho_dry_yellow_grass_tuft`
                ],
                noi: `mep_dinh`,
                mat: 160,
                cach: 2.4,
                k: [
                    0.5,
                    0.85
                ],
                lay: true,
                cum: 0.6,
                con: 2,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `prop_phu_luc_bien_da_vun`,
                    `prop_phu_luc_bien_da_chong`
                ],
                noi: `chan_vach`,
                mat: 100,
                cach: 2.4,
                k: [
                    0.45,
                    0.85
                ],
                cum: 0.35,
                con: 2,
                gan: 0.9,
                mau: 15789288
            },
            {
                anh: [
                    `prop_phu_luc_bien_da_cum`
                ],
                noi: `chan_vach`,
                sat: 0.6,
                mat: 22,
                cach: 5,
                k: [
                    0.45,
                    0.75
                ],
                cum: 0.4,
                gan: 1.2,
                mau: 15789288
            },
            {
                anh: [
                    `prop_phu_luc_bien_da_vun`,
                    `prop_kho_small_pebbles`
                ],
                noi: `chan_vach`,
                mat: 50,
                cach: 2.2,
                k: [
                    0.3,
                    0.45
                ],
                cum: 0.3,
                con: 1,
                gan: 0.7,
                bong: false
            },
            {
                anh: [
                    `prop_phu_luc_bien_co_kho`,
                    `prop_kho_dry_yellow_grass_tuft`
                ],
                noi: `chan_vach`,
                mat: 45,
                cach: 2.6,
                k: [
                    0.55,
                    0.9
                ],
                lay: true,
                cum: 0.6,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `prop_pg25_dong_quang_vang`,
                    `prop_kho_pile_grey_ore`
                ],
                noi: `dat`,
                mat: 26,
                cach: 6,
                k: [
                    0.8,
                    1.1
                ],
                cum: 0.4,
                gan: 1.6,
                quanh: {
                    noi: `^mo_lo_thien_`,
                    r: 7
                }
            },
            {
                anh: [
                    `prop_kho_iron_pickaxe`,
                    `prop_kho_small_bucket`,
                    `prop_kho_rope_coil`,
                    `prop_kho_mine_cart_ore`,
                    `prop_kho_wooden_wheelbarrow`
                ],
                noi: `dat`,
                mat: 22,
                cach: 14,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.3,
                gan: 1.6,
                quanh: {
                    noi: `^mo_lo_thien_`,
                    r: 6
                }
            },
            {
                anh: [
                    `nen_lgb_dong_dat_dao`
                ],
                noi: `dat`,
                mat: 40,
                cach: 6,
                k: [
                    0.7,
                    1
                ],
                bet: true,
                cum: 0.3,
                quanh: {
                    noi: `^mo_lo_thien_`,
                    r: 8
                }
            },
            {
                anh: [
                    `nen_lgb_mep_ho_mo`
                ],
                noi: `dat`,
                mat: 14,
                cach: 9,
                k: [
                    0.6,
                    0.85
                ],
                bet: true,
                cum: 0.2,
                quanh: {
                    noi: `^mo_lo_thien_`,
                    r: 9
                }
            },
            {
                anh: [
                    `nen_lgb_da_vun_quang`
                ],
                noi: `dat`,
                mat: 18,
                cach: 6,
                k: [
                    0.75,
                    1
                ],
                bet: true,
                cum: 0.4,
                quanh: {
                    noi: `^(mo_lo_thien_|chi_dau_lo)`,
                    r: 10
                }
            },
            {
                anh: [
                    `prop_kho_broken_cart_wheel`,
                    `prop_kho_small_crate`,
                    `prop_kho_straw_bundle`
                ],
                noi: `dat`,
                mat: 30,
                cach: 10,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.3,
                gan: 1.4,
                quanh: {
                    noi: `^(tram_nghi_|cho_da_dong|tram_luc_gia)`,
                    r: 6
                }
            },
            {
                anh: [
                    `nen_lgb_vet_chan_nguoi`
                ],
                noi: `dat`,
                mat: 16,
                cach: 8,
                k: [
                    0.8,
                    1
                ],
                bet: true,
                cum: 0.3,
                quanh: {
                    noi: `^(tram_nghi_|cho_da_dong|tram_luc_gia|mo_lo_thien$)`,
                    r: 12
                }
            },
            {
                anh: [
                    `prop_phu_luc_bien_co_kho`,
                    `prop_kho_dry_yellow_grass_tuft`
                ],
                noi: `dat`,
                mat: 34,
                cach: 2.6,
                k: [
                    0.5,
                    0.85
                ],
                lay: true,
                cum: 0.85,
                con: 3,
                gan: 0.85,
                bong: false
            },
            {
                anh: [
                    `prop_phu_luc_bien_bui_gai`,
                    `prop_phu_luc_bien_bui_kho`,
                    `prop_kho_thorny_bush`
                ],
                noi: `dat`,
                mat: 3,
                cach: 7,
                k: [
                    0.5,
                    0.75
                ],
                lay: true,
                cum: 0.65,
                gan: 1.3
            },
            {
                anh: [
                    `prop_phu_luc_bien_da_vun`,
                    `prop_kho_flat_grey_stone`,
                    `prop_kho_small_pebbles`
                ],
                noi: `dat`,
                mat: 16,
                cach: 4,
                k: [
                    0.35,
                    0.6
                ],
                cum: 0.65,
                con: 1,
                gan: 1
            },
            {
                anh: [
                    `prop_kho_dry_twig`,
                    `prop_kho_rib_bones`,
                    `prop_kho_small_animal_skull`
                ],
                noi: `dat`,
                mat: 1.2,
                cach: 14,
                k: [
                    0.85,
                    1.1
                ],
                cum: 0.3,
                gan: 1.2
            },
            {
                anh: [
                    `nen_lgb_vet_nut_kho`
                ],
                noi: `dat`,
                mat: 3,
                cach: 7,
                k: [
                    0.75,
                    1.1
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `nen_lgb_bui_co_kho`
                ],
                noi: `dat`,
                mat: 5,
                cach: 5,
                k: [
                    0.8,
                    1.1
                ],
                bet: true,
                cum: 0.7
            },
            {
                anh: [
                    `nen_lgb_da_vun_quang`
                ],
                noi: `chan_vach`,
                mat: 2.5,
                cach: 9,
                k: [
                    0.75,
                    1
                ],
                bet: true,
                cum: 0.4
            },
            {
                anh: [
                    `prop_phu_luc_bien_lieu_bach_a`,
                    `prop_phu_luc_bien_lieu_bach_b`,
                    `prop_phu_luc_bien_lieu_bach_c`,
                    `prop_phu_luc_bien_lieu_bach_d`
                ],
                noi: `dat`,
                mat: 0.7,
                cach: 12,
                k: [
                    0.8,
                    1
                ],
                cum: 0.7,
                con: 1,
                gan: 2,
                lay: true,
                cao: 2
            },
            {
                anh: [
                    `prop_phu_luc_bien_ngai_a`,
                    `prop_phu_luc_bien_ngai_b`,
                    `prop_phu_luc_bien_ngai_c`,
                    `prop_phu_luc_bien_ngai_d`
                ],
                noi: `dat`,
                mat: 2.5,
                cach: 5,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.8,
                con: 2,
                gan: 1,
                lay: true
            },
            {
                anh: [
                    `prop_phu_luc_bien_co_vang_a`,
                    `prop_phu_luc_bien_co_vang_b`,
                    `prop_phu_luc_bien_co_vang_c`,
                    `prop_phu_luc_bien_co_vang_d`
                ],
                noi: `dat`,
                mat: 4,
                cach: 3.5,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.85,
                con: 2,
                gan: 0.8,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_luc_bien_cay_kho_a`,
                    `prop_phu_luc_bien_cay_kho_b`,
                    `prop_phu_luc_bien_cay_kho_c`,
                    `prop_phu_luc_bien_cay_kho_d`
                ],
                noi: `dinh`,
                mat: 1,
                cach: 12,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.5,
                gan: 2.4,
                cao: 2.8
            },
            {
                anh: [
                    `prop_phu_luc_bien_cay_kho_a`,
                    `prop_phu_luc_bien_cay_kho_b`,
                    `prop_phu_luc_bien_cay_kho_c`,
                    `prop_phu_luc_bien_cay_kho_d`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^mo_lo_thien`,
                    r: 14
                },
                mat: 2,
                cach: 14,
                k: [
                    0.8,
                    1
                ],
                cum: 0.3,
                gan: 2.4,
                cao: 2.8
            }
        ],
        dong: {
            bui: {
                so: 40,
                mau: 14203000
            },
            conTrung: 2,
            chim: 1,
            nang: 0.6
        }
    };
    let zone_mo_cu = {
        nen: [
            `nen_mc_dat_mo_a`,
            `nen_mc_dat_mo_b`
        ],
        duong: `nen_vlh_dat_duong_rung`,
        loai: (e)=>{
            if (e.startsWith(`rung`)) {
                return `rung`;
            }
            if (e.startsWith(`nuoc`)) {
                return `nuoc`;
            }
            return `da`;
        },
        da: {
            anh: `prop_tl_vach_ham_mo`,
            kieuMat: `dat`,
            matAnh: `prop_tl_vach_ham_mo`,
            cao: [
                2,
                3.2
            ],
            cot: [
                0.5,
                1.05
            ],
            mat: [
                62,
                52,
                46
            ],
            vach: [
                112,
                86,
                66
            ],
            khe: [
                22,
                14,
                10
            ],
            vien: [
                170,
                140,
                108
            ],
            lo: 0.9,
            hat: 0.4,
            bui: 0.25,
            khoi: 1.6,
            tron: 0.65,
            ben: 1.8,
            loang: 0.6,
            chong: {
                go: [
                    104,
                    72,
                    44
                ],
                cach: 3.4
            }
        },
        rung: {
            nen: [
                22,
                32,
                18
            ],
            toi: [
                20,
                38,
                22
            ],
            tan: [
                58,
                96,
                44
            ],
            sang: [
                132,
                168,
                78
            ],
            o: 1.9,
            cao: 6
        },
        nuoc: {
            nong: [
                70,
                108,
                104
            ],
            sau: [
                18,
                48,
                58
            ],
            bot: [
                170,
                210,
                206
            ],
            troi: [
                120,
                160,
                168
            ],
            uot: [
                120,
                104,
                92
            ],
            trong: 0.55,
            chay: [
                0.05,
                0.02
            ],
            dong: {
                lap: 16,
                la: 0,
                gon: 3
            }
        },
        dat: {
            soi: 0.3,
            soiMau: [
                140,
                112,
                92
            ],
            mang: 0.7,
            tiB: 0.5,
            cong: 0.7
        },
        vungNen: [
            {
                anh: `nen_vlh_reu_day`,
                ngoai: true,
                mem: 2.5,
                dam: 0.95,
                nhan: [
                    0.92,
                    0.96,
                    0.9
                ]
            }
        ],
        ray: {
            go: [
                100,
                70,
                46
            ],
            sat: [
                74,
                72,
                78
            ],
            dam: [
                132,
                118,
                104
            ],
            boNgoai: true
        },
        bong: {
            dam: 0.42
        },
        tong: [
            1.08,
            1.04,
            1
        ],
        loi: {
            rong: 1,
            dam: 0.55,
            theoDuLieu: true
        },
        cachChung: 1.1,
        tranhNoi: 2.4,
        do: [
            {
                anh: [
                    `prop_phu_mo_cu_da_vun_a`,
                    `prop_phu_mo_cu_da_vun_b`,
                    `prop_phu_mo_cu_da_vun_c`,
                    `prop_phu_mo_cu_da_vun_d`
                ],
                noi: `chan_vach`,
                mat: 50,
                cach: 4,
                k: [
                    0.6,
                    0.85
                ],
                cum: 0.4,
                con: 1,
                gan: 1,
                mau: 14206128,
                nen: {
                    ngoai: 0
                }
            },
            {
                anh: [
                    `nen_mc_dong_da_vun`,
                    `nen_mc_da_tang_nho`
                ],
                noi: `chan_vach`,
                mat: 6,
                cach: 6,
                k: [
                    0.7,
                    1
                ],
                bet: true,
                cum: 0.4,
                nen: {
                    ngoai: 0
                }
            },
            {
                anh: [
                    `prop_phu_mo_cu_da_vun_c`,
                    `prop_phu_mo_cu_da_vun_a`
                ],
                noi: `mep_dinh`,
                mat: 130,
                cach: 3,
                k: [
                    0.7,
                    1
                ],
                cum: 0.5,
                con: 1,
                gan: 1,
                mau: 14206128
            },
            {
                anh: [
                    `nen_mc_vet_cuoc`,
                    `nen_mc_vet_quang`
                ],
                noi: `dat`,
                mat: 50,
                cach: 6,
                k: [
                    0.7,
                    0.95
                ],
                bet: true,
                cum: 0.3,
                quanh: {
                    noi: `^(nut_mo_|vach_mo_can)`,
                    r: 5
                }
            },
            {
                anh: [
                    `nen_mc_ray_go_gay`
                ],
                noi: `dat`,
                mat: 8,
                cach: 12,
                k: [
                    0.75,
                    0.95
                ],
                bet: true,
                cum: 0.3,
                quanh: {
                    ray: true,
                    r: 3
                }
            },
            {
                anh: [
                    `prop_kho_broken_cart_wheel`
                ],
                noi: `dat`,
                mat: 8,
                cach: 10,
                k: [
                    0.8,
                    1
                ],
                cum: 0.3,
                gan: 1.3,
                quanh: {
                    ray: true,
                    r: 3
                }
            },
            {
                anh: [
                    `nen_mc_vung_nuoc_mo`
                ],
                noi: `dat`,
                mat: 1.2,
                cach: 12,
                k: [
                    0.8,
                    1
                ],
                bet: true,
                cum: 0.4,
                nen: {
                    ngoai: 0
                }
            },
            {
                anh: [
                    `nen_mc_dong_da_vun`
                ],
                noi: `dat`,
                mat: 1.5,
                cach: 9,
                k: [
                    0.7,
                    0.95
                ],
                bet: true,
                cum: 0.5,
                nen: {
                    ngoai: 0
                }
            },
            {
                anh: [
                    `prop_kho_tall_wild_grass`,
                    `prop_kho_short_green_grass_tuft`
                ],
                noi: `dat`,
                mat: 120,
                cach: 3,
                k: [
                    0.75,
                    1.05
                ],
                lay: true,
                cum: 0.8,
                con: 2,
                gan: 0.8,
                bong: false,
                nen: {
                    trong: 0
                }
            },
            {
                anh: [
                    `prop_phu_vu_linh_ha_bui_rung`,
                    `prop_phu_vu_linh_ha_duong_xi`
                ],
                noi: `mep_rung`,
                mat: 70,
                cach: 4,
                k: [
                    0.6,
                    0.9
                ],
                lay: true,
                cum: 0.5,
                con: 1,
                gan: 1.2,
                nen: {
                    trong: 0
                }
            },
            {
                anh: [
                    `prop_kho_small_white_wildflowers`,
                    `prop_kho_tiny_blue_flowers`
                ],
                noi: `dat`,
                mat: 14,
                cach: 5,
                k: [
                    0.8,
                    1
                ],
                lay: true,
                cum: 0.85,
                con: 1,
                gan: 0.8,
                bong: false,
                nen: {
                    trong: 0
                }
            },
            {
                anh: [
                    `prop_phu_mach_sau_phien_da_nuoc`
                ],
                noi: `mep_nuoc`,
                mat: 40,
                cach: 4,
                k: [
                    0.45,
                    0.65
                ],
                cum: 0.5,
                gan: 1,
                mau: 15259848
            },
            {
                anh: [
                    `prop_phu_mo_cu_go_chong_a`,
                    `prop_phu_mo_cu_go_chong_b`,
                    `prop_phu_mo_cu_go_chong_c`,
                    `prop_phu_mo_cu_go_chong_d`
                ],
                noi: `chan_vach`,
                sat: 0.55,
                mat: 22,
                cach: 8,
                k: [
                    0.75,
                    0.95
                ],
                cum: 0.4,
                gan: 1.4,
                mau: 14733504,
                nen: {
                    ngoai: 0
                }
            },
            {
                anh: [
                    `prop_phu_mo_cu_tang_da_a`,
                    `prop_phu_mo_cu_tang_da_b`,
                    `prop_phu_mo_cu_tang_da_c`,
                    `prop_phu_mo_cu_tang_da_d`
                ],
                noi: `chan_vach`,
                mat: 20,
                cach: 8,
                k: [
                    0.7,
                    0.95
                ],
                cum: 0.4,
                gan: 1.4,
                mau: 14206128,
                nen: {
                    ngoai: 0
                }
            },
            {
                anh: [
                    `prop_phu_mo_cu_do_mo_a`,
                    `prop_phu_mo_cu_do_mo_b`,
                    `prop_phu_mo_cu_do_mo_c`,
                    `prop_phu_mo_cu_do_mo_d`
                ],
                noi: `dat`,
                mat: 45,
                cach: 5,
                k: [
                    0.75,
                    0.9
                ],
                cum: 0.3,
                gan: 1.4,
                quanh: {
                    noi: `^(nut_mo_|lan_tho$)`,
                    r: 7
                }
            },
            {
                anh: [
                    `prop_phu_mo_cu_da_vun_a`,
                    `prop_phu_mo_cu_da_vun_b`,
                    `prop_phu_mo_cu_da_vun_c`,
                    `prop_phu_mo_cu_da_vun_d`,
                    `prop_phu_mo_cu_tang_da_a`,
                    `prop_phu_mo_cu_tang_da_b`,
                    `prop_phu_mo_cu_tang_da_c`,
                    `prop_phu_mo_cu_tang_da_d`
                ],
                noi: `chan_vach`,
                mat: 60,
                cach: 6,
                k: [
                    0.7,
                    0.95
                ],
                cum: 0.5,
                con: 1,
                gan: 1.2,
                nen: {
                    trong: 0
                }
            },
            {
                anh: [
                    `prop_phu_mo_cu_go_chong_a`,
                    `prop_phu_mo_cu_go_chong_b`,
                    `prop_phu_mo_cu_go_chong_c`,
                    `prop_phu_mo_cu_go_chong_d`
                ],
                noi: `dat`,
                mat: 0.8,
                cach: 12,
                k: [
                    0.8,
                    0.95
                ],
                cum: 0.4,
                gan: 1.6,
                nen: {
                    trong: 0
                }
            }
        ],
        dong: {
            bui: {
                so: 22,
                mau: 13150344
            },
            giot: 4,
            la: {
                so: 6,
                mau: [
                    7244346,
                    9083458,
                    10521154
                ]
            }
        }
    };
    function khop(e) {
        return e.rong === 160 && e.cao === 120 && e.chan.some((e)=>(e.id ?? ``).startsWith(`ct_`));
    }
    let Be = [
        `prop_phu_luc_bien_co_kho`,
        `prop_kho_dry_yellow_grass_tuft`
    ];
    let inst_chien_truong = {
        nen: [
            `prop_tl_co_bai_a`,
            `nen_lgb_dat_vang_a`
        ],
        duong: `nen_lgb_duong_xe_mo`,
        loai: (e)=>{
            if (e.startsWith(`ct_rung`)) {
                return `rung`;
            }
            if (e.startsWith(`ct_rao`)) {
                return `the`;
            }
            if (e.startsWith(`ct_tuong`)) {
                return `bo`;
            }
            return `da`;
        },
        boVat: [
            `prop_trai_ke_da_goc`,
            `prop_trai_ke_da_1`,
            `prop_trai_ke_da_2`
        ],
        da: {
            anh: `nen_ms_da_vach_hang`,
            kieuMat: `dat`,
            matAnh: `nen_lgb_dat_vang_a`,
            cao: [
                1.8,
                3.2
            ],
            cot: [
                0.7,
                1.5
            ],
            mat: [
                132,
                112,
                72
            ],
            vach: [
                112,
                106,
                98
            ],
            khe: [
                28,
                24,
                22
            ],
            vien: [
                196,
                182,
                140
            ],
            lo: 0.7,
            bui: 0.3,
            co: [
                176,
                150,
                78
            ],
            hat: 0.5,
            khoi: 1.8,
            tron: 0.6,
            ben: 1.8,
            loang: 0.6,
            tuNhien: true
        },
        the: {
            mat: [
                96,
                68,
                42
            ],
            vach: [
                112,
                78,
                48
            ],
            khe: [
                34,
                22,
                14
            ],
            vien: [
                168,
                126,
                80
            ],
            cot: [
                0.26,
                0.38
            ],
            hat: 0.6,
            caoMax: 1.9
        },
        rung: {
            nen: [
                44,
                32,
                20
            ],
            toi: [
                70,
                40,
                24
            ],
            tan: [
                158,
                90,
                40
            ],
            sang: [
                226,
                168,
                78
            ],
            o: 1.8,
            cao: 6,
            bien: 0.7,
            vuon: 0.45
        },
        dat: {
            soi: 0.06,
            soiMau: [
                150,
                140,
                120
            ],
            mang: 0.6,
            tiB: 0.42,
            cong: 0.5,
            diu: 0.3,
            co: 0.05,
            coMau: [
                176,
                150,
                84
            ]
        },
        vungNen: [
            {
                anh: `nen_mc_dat_mo_a`,
                tam: [
                    80,
                    76
                ],
                r: [
                    12,
                    10
                ],
                mem: 3,
                dam: 0.95
            },
            {
                anh: `nen_lgb_dat_vang_b`,
                tam: [
                    14,
                    61
                ],
                r: [
                    17,
                    16
                ],
                mem: 5,
                dam: 0.7,
                nhan: [
                    0.8,
                    1.02,
                    0.78
                ]
            },
            {
                anh: `nen_lgb_dat_vang_b`,
                tam: [
                    146,
                    61
                ],
                r: [
                    17,
                    16
                ],
                mem: 5,
                dam: 0.75,
                nhan: [
                    1.12,
                    0.98,
                    0.74
                ]
            },
            {
                anh: `prop_tl_co_bai_b`,
                tam: [
                    80,
                    15
                ],
                r: [
                    15,
                    9
                ],
                mem: 4,
                dam: 0.55,
                nhan: [
                    0.92,
                    1.02,
                    0.86
                ]
            },
            {
                anh: `nen_lgb_dat_vang_a`,
                tam: [
                    80,
                    101
                ],
                r: [
                    36,
                    9
                ],
                mem: 8,
                dam: 0.45,
                nhan: [
                    0.96,
                    0.9,
                    0.78
                ]
            }
        ],
        bong: {
            dam: 0.48
        },
        tong: [
            1.05,
            0.97,
            0.82
        ],
        loi: {
            rong: 1,
            dam: 0.72,
            vet: {
                rong: 3.5,
                dam: 0.65
            }
        },
        cachChung: 1.1,
        tranhNoi: 2.4,
        do: [
            {
                anh: Be,
                noi: `dinh`,
                mat: 24,
                cach: 2.6,
                k: [
                    0.55,
                    0.9
                ],
                lay: true,
                cum: 0.8,
                con: 3,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `prop_phu_luc_bien_bui_gai`,
                    `prop_phu_luc_bien_bui_kho`
                ],
                noi: `dinh`,
                mat: 8,
                cach: 5,
                k: [
                    0.6,
                    0.95
                ],
                lay: true,
                cum: 0.6,
                con: 1,
                gan: 1.3
            },
            {
                anh: [
                    `prop_phu_luc_bien_mom_da`,
                    `prop_phu_luc_bien_da_chong`
                ],
                noi: `dinh`,
                mat: 4,
                cach: 7,
                k: [
                    0.55,
                    0.9
                ],
                cum: 0.6,
                gan: 1.5,
                mau: 14999772
            },
            {
                anh: Be,
                noi: `mep_dinh`,
                mat: 140,
                cach: 2.4,
                k: [
                    0.5,
                    0.85
                ],
                lay: true,
                cum: 0.6,
                con: 2,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `prop_phu_luc_bien_da_vun`,
                    `prop_phu_luc_bien_da_chong`
                ],
                noi: `chan_vach`,
                mat: 80,
                cach: 2.4,
                k: [
                    0.45,
                    0.8
                ],
                cum: 0.35,
                con: 2,
                gan: 0.9,
                mau: 15657700
            },
            {
                anh: [
                    `prop_phu_luc_bien_da_cum`
                ],
                noi: `chan_vach`,
                sat: 0.6,
                mat: 14,
                cach: 6,
                k: [
                    0.4,
                    0.65
                ],
                cum: 0.4,
                gan: 1.2,
                mau: 15657700
            },
            {
                anh: Be,
                noi: `chan_vach`,
                mat: 50,
                cach: 2.6,
                k: [
                    0.55,
                    0.9
                ],
                lay: true,
                cum: 0.6,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `prop_kho_thorny_bush`,
                    `prop_phu_luc_bien_bui_kho`
                ],
                noi: `mep_rung`,
                mat: 40,
                cach: 3.5,
                k: [
                    0.6,
                    0.9
                ],
                lay: true,
                cum: 0.6,
                con: 1,
                gan: 1.1,
                mau: 15784112
            },
            {
                anh: [
                    `prop_phu_luc_bien_cay_kho`
                ],
                noi: `mep_rung`,
                mat: 6,
                cach: 9,
                k: [
                    0.7,
                    0.95
                ],
                cum: 0.5,
                gan: 2,
                cao: 2.8
            },
            {
                anh: [
                    `prop_phu_luc_bien_da_vun`,
                    `prop_kho_small_pebbles`,
                    `prop_kho_flat_grey_stone`
                ],
                noi: `dat`,
                nen: {
                    trong: 0
                },
                mat: 60,
                cach: 3,
                k: [
                    0.4,
                    0.7
                ],
                cum: 0.5,
                con: 1,
                gan: 0.9
            },
            {
                anh: [
                    `nen_lgb_da_vun_quang`,
                    `nen_mc_dong_da_vun`
                ],
                noi: `dat`,
                nen: {
                    trong: 0
                },
                mat: 30,
                cach: 5,
                k: [
                    0.7,
                    1
                ],
                bet: true,
                cum: 0.4
            },
            {
                anh: Be,
                noi: `dat`,
                nen: {
                    ngoai: 0
                },
                mat: 40,
                cach: 2.6,
                k: [
                    0.5,
                    0.85
                ],
                lay: true,
                cum: 0.85,
                con: 3,
                gan: 0.85,
                bong: false
            },
            {
                anh: [
                    `prop_kho_tall_wild_grass`
                ],
                noi: `dat`,
                nen: {
                    ngoai: 0
                },
                mat: 10,
                cach: 3.5,
                k: [
                    0.6,
                    0.9
                ],
                lay: true,
                cum: 0.8,
                con: 2,
                gan: 0.9,
                bong: false,
                mau: 15785120
            },
            {
                anh: [
                    `prop_kho_small_white_wildflowers`
                ],
                noi: `dat`,
                nen: {
                    ngoai: 0
                },
                mat: 3,
                cach: 4,
                k: [
                    0.6,
                    0.85
                ],
                lay: true,
                cum: 0.85,
                con: 2,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `prop_phu_luc_bien_bui_gai`,
                    `prop_kho_thorny_bush`
                ],
                noi: `dat`,
                nen: {
                    ngoai: 0
                },
                mat: 2.2,
                cach: 8,
                k: [
                    0.5,
                    0.75
                ],
                lay: true,
                cum: 0.6,
                gan: 1.3,
                mau: 16049348
            },
            {
                anh: [
                    `prop_phu_luc_bien_da_vun`,
                    `prop_kho_flat_grey_stone`,
                    `prop_kho_small_pebbles`
                ],
                noi: `dat`,
                mat: 10,
                cach: 4,
                k: [
                    0.35,
                    0.6
                ],
                cum: 0.65,
                con: 1,
                gan: 1
            },
            {
                anh: [
                    `prop_kho_dry_twig`,
                    `prop_kho_broken_cart_wheel`,
                    `prop_kho_rib_bones`
                ],
                noi: `dat`,
                nen: {
                    ngoai: 0
                },
                mat: 0.8,
                cach: 16,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.3,
                gan: 1.2
            },
            {
                anh: [
                    `nen_lgb_bui_co_kho`
                ],
                noi: `dat`,
                mat: 5,
                cach: 5,
                k: [
                    0.8,
                    1.1
                ],
                bet: true,
                cum: 0.7
            },
            {
                anh: [
                    `nen_lgb_vet_nut_kho`
                ],
                noi: `dat`,
                nen: {
                    ngoai: 0
                },
                mat: 1.5,
                cach: 9,
                k: [
                    0.75,
                    1.05
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `nen_lgb_vet_chan_nguoi`
                ],
                noi: `dat`,
                mat: 0.8,
                cach: 12,
                k: [
                    0.85,
                    1
                ],
                bet: true,
                cum: 0.3
            },
            {
                anh: [
                    `prop_phu_luc_bien_co_vang_a`,
                    `prop_phu_luc_bien_co_vang_b`,
                    `prop_phu_luc_bien_co_vang_c`,
                    `prop_phu_luc_bien_co_vang_d`
                ],
                noi: `dat`,
                nen: {
                    ngoai: 0
                },
                mat: 4,
                cach: 3.5,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.85,
                con: 2,
                gan: 0.8,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_luc_bien_ngai_a`,
                    `prop_phu_luc_bien_ngai_b`,
                    `prop_phu_luc_bien_ngai_c`,
                    `prop_phu_luc_bien_ngai_d`
                ],
                noi: `dat`,
                nen: {
                    ngoai: 0
                },
                mat: 2,
                cach: 5,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.8,
                con: 2,
                gan: 1,
                lay: true
            },
            {
                anh: [
                    `prop_phu_lang_coc_co_kho_a`,
                    `prop_phu_lang_coc_co_kho_b`,
                    `prop_phu_lang_coc_co_kho_c`,
                    `prop_phu_lang_coc_co_kho_d`
                ],
                noi: `dinh`,
                mat: 6,
                cach: 3.5,
                k: [
                    0.8,
                    1.05
                ],
                cum: 0.8,
                con: 2,
                gan: 0.9,
                lay: true,
                bong: false
            },
            {
                anh: [
                    `prop_phu_luc_bien_cay_kho_a`,
                    `prop_phu_luc_bien_cay_kho_b`,
                    `prop_phu_luc_bien_cay_kho_c`,
                    `prop_phu_luc_bien_cay_kho_d`
                ],
                noi: `mep_rung`,
                mat: 3,
                cach: 12,
                k: [
                    0.85,
                    1.05
                ],
                cum: 0.5,
                gan: 2.4,
                cao: 2.8
            }
        ],
        dong: {
            bui: {
                so: 34,
                mau: 15126688
            },
            la: {
                so: 10,
                mau: [
                    13136940,
                    14721088,
                    10111524
                ]
            },
            conTrung: 1,
            chim: 0.8,
            nang: 0.5,
            khoi: [
                [
                    7,
                    52
                ],
                [
                    153,
                    52
                ]
            ],
            suong: {
                so: 5,
                mau: 15262420,
                a: 0.22
            }
        }
    };
    let He = {
        inst_chien_truong: {
            khop,
            keThua: `zone_bac_linh`
        }
    };
    function Ue(e) {
        let t = He[e];
        if (t) {
            return a(e) && t.khop(o(e));
        }
        return null;
    }
    function We(e) {
        if (Ue(e) === false) {
            return He[e].keThua;
        }
    }
    let Ge = [
        `prop_gpt_thong_tuyet_cao_a`,
        `prop_gpt_thong_tuyet_cao_b`
    ];
    let Ke = [
        `prop_gpt_thong_tuyet_non_a`,
        `prop_gpt_thong_tuyet_non_b`
    ];
    function qe(e) {
        if (e.startsWith(`nuoc`)) {
            return `nuoc`;
        }
        if (e.startsWith(`tuong`)) {
            return `the`;
        }
        if (e.startsWith(`rao`) || e.startsWith(`nha`) || e.startsWith(`vc_`)) {
            return `bo`;
        }
        return `da`;
    }
    let Je = {
        anh: `nen_ms_da_vach_hang`,
        cao: [
            1.6,
            3.2
        ],
        cot: [
            0.55,
            1.1
        ],
        mat: [
            116,
            120,
            130
        ],
        vach: [
            84,
            88,
            102
        ],
        khe: [
            26,
            28,
            38
        ],
        vien: [
            186,
            194,
            208
        ],
        tam: 1.5,
        lo: 0.45,
        tuyet: 0.82,
        hat: 0.45
    };
    let Ye = {
        nong: [
            104,
            158,
            176
        ],
        sau: [
            36,
            84,
            112
        ],
        bot: [
            236,
            244,
            250
        ],
        troi: [
            218,
            234,
            244
        ],
        uot: [
            196,
            204,
            220
        ],
        trong: 0.35,
        chay: [
            0.1,
            0.05
        ],
        lang: true,
        dong: {
            lap: 30,
            la: 0,
            gon: 4
        },
        bang: {
            rong: 1.8,
            mau: [
                200,
                224,
                238
            ]
        }
    };
    let dat = {
        soi: 0.03,
        soiMau: [
            138,
            144,
            158
        ],
        co: 0.03,
        coMau: [
            150,
            136,
            104
        ],
        mang: 0.32,
        tiB: 0.5,
        phang: 0.7,
        song: 0.6,
        songMau: [
            0.8,
            0.87,
            1
        ],
        gon: 0.95,
        lap: 0.6
    };
    function Ze(e = 1) {
        return [
            {
                anh: Ke,
                noi: `chan_vach`,
                sat: 0.7,
                mat: 16 * e,
                cach: 6,
                k: [
                    0.7,
                    1.05
                ],
                cum: 0.8,
                con: 2,
                gan: 1.6,
                cao: 3
            },
            {
                anh: Ge,
                noi: `chan_vach`,
                sat: 0.7,
                mat: 5 * e,
                cach: 9,
                k: [
                    0.75,
                    1
                ],
                cum: 0.8,
                con: 1,
                gan: 2,
                cao: 6
            },
            {
                anh: Ge,
                noi: `dinh`,
                mat: 8,
                cach: 6,
                k: [
                    0.8,
                    1.1
                ],
                cum: 0.75,
                con: 1,
                gan: 1.8,
                cao: 6
            },
            {
                anh: [
                    `prop_pg_da_tuyet_cum`,
                    `nen_bl_bui_kho_tuyet`
                ],
                noi: `dinh`,
                mat: 6,
                cach: 6,
                k: [
                    0.55,
                    0.95
                ],
                cum: 0.5,
                gan: 1.4
            },
            {
                anh: [
                    `prop_pg_cay_kho_bang`
                ],
                noi: `chan_vach`,
                sat: 0.7,
                mat: 4,
                cach: 12,
                k: [
                    0.75,
                    1
                ],
                cum: 0.4,
                gan: 2,
                cao: 2.5,
                mau: 14673136
            },
            {
                anh: [
                    `prop_pg_da_tuyet_cum`
                ],
                noi: `chan_vach`,
                mat: 26,
                cach: 4.5,
                k: [
                    0.45,
                    0.85
                ],
                cum: 0.45,
                con: 1,
                gan: 1.1
            },
            {
                anh: [
                    `nen_bl_bui_kho_tuyet`,
                    `nen_bl_mang_co_lo`
                ],
                noi: `chan_vach`,
                mat: 22,
                cach: 4,
                k: [
                    0.45,
                    0.75
                ],
                lay: true,
                cum: 0.55,
                gan: 1,
                bong: false
            },
            {
                anh: [
                    `nen_bl_soi_tuyet`,
                    `nen_bl_go_tuyet_nho`
                ],
                noi: `chan_vach`,
                mat: 8,
                cach: 6,
                k: [
                    0.8,
                    1.1
                ],
                bet: true,
                cum: 0.4
            },
            {
                anh: [
                    `nen_bl_mang_co_lo`
                ],
                noi: `dat`,
                mat: 9 * e,
                cach: 3,
                k: [
                    0.28,
                    0.5
                ],
                lay: true,
                cum: 0.9,
                con: 2,
                gan: 0.75,
                bong: false
            },
            {
                anh: [
                    `prop_kho_dry_yellow_grass_tuft`,
                    `prop_phu_lang_coc_co_kho`
                ],
                noi: `dat`,
                mat: 5 * e,
                cach: 3.4,
                k: [
                    0.6,
                    0.9
                ],
                lay: true,
                cum: 0.9,
                con: 2,
                gan: 0.8,
                bong: false,
                mau: 15129796
            },
            {
                anh: [
                    `nen_bl_bui_kho_tuyet`
                ],
                noi: `dat`,
                mat: 2.4 * e,
                cach: 6,
                k: [
                    0.5,
                    0.85
                ],
                lay: true,
                cum: 0.75,
                con: 1,
                gan: 1.1
            },
            {
                anh: [
                    `prop_pg_da_tuyet_cum`
                ],
                noi: `dat`,
                mat: 1.6,
                cach: 9,
                k: [
                    0.4,
                    0.7
                ],
                cum: 0.6,
                gan: 1.2
            },
            {
                anh: [
                    `nen_bl_go_tuyet_nho`
                ],
                noi: `dat`,
                mat: 3,
                cach: 8,
                k: [
                    0.8,
                    1.2
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `nen_bl_soi_tuyet`
                ],
                noi: `dat`,
                mat: 2.4,
                cach: 8,
                k: [
                    0.8,
                    1.1
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `nen_bl_vet_chan_soi`
                ],
                noi: `dat`,
                mat: 0.7,
                cach: 14,
                k: [
                    0.9,
                    1.1
                ],
                bet: true
            },
            {
                anh: [
                    `nen_bl_vet_nut_bang`
                ],
                noi: `dat`,
                mat: 0.25,
                cach: 22,
                k: [
                    0.85,
                    1.1
                ],
                bet: true
            }
        ];
    }
    let Qe = [
        {
            anh: [
                `prop_pg_da_tuyet_cum`
            ],
            noi: `mep_nuoc`,
            mat: 60,
            cach: 3.4,
            k: [
                0.4,
                0.75
            ],
            cum: 0.55,
            con: 1,
            gan: 0.9
        },
        {
            anh: [
                `nen_bl_mang_co_lo`,
                `nen_bl_bui_kho_tuyet`
            ],
            noi: `mep_nuoc`,
            mat: 90,
            cach: 3,
            k: [
                0.45,
                0.8
            ],
            lay: true,
            cum: 0.7,
            con: 1,
            gan: 0.85,
            bong: false
        },
        {
            anh: [
                `prop_kho_reeds_clump`
            ],
            noi: `nuoc_nong`,
            mat: 40,
            cach: 3.2,
            k: [
                0.8,
                1.2
            ],
            lay: true,
            cum: 0.5,
            con: 1,
            gan: 0.9,
            bong: false,
            mau: 14736588
        },
        {
            anh: [
                `nen_bl_soi_tuyet`
            ],
            noi: `mep_nuoc`,
            mat: 12,
            cach: 6,
            k: [
                0.7,
                1
            ],
            bet: true,
            cum: 0.5
        }
    ];
    let $e = {
        tuyet: 150,
        bui: {
            so: 30,
            mau: 15922943
        },
        chim: 0.3,
        tuyetBay: 14,
        lapLanh: {
            so: 16,
            mau: 16777215
        }
    };
    let zone_thao_nguyen_tuyet = {
        nen: [
            `nen_bl_tuyet_a`,
            `nen_bl_tuyet_b`
        ],
        duong: `nen_bl_dat_bun_tuyet`,
        loai: qe,
        da: Je,
        nuoc: Ye,
        dat,
        bong: {
            dam: 0.42
        },
        caoDo: {
            mat: 0.25
        },
        tong: [
            0.98,
            1,
            1.03
        ],
        loi: {
            rong: 1,
            dam: 0.4
        },
        loiThem: [
            {
                qua: [
                    `tu_tuong_gioi`,
                    `go_soi_gio_vuong`,
                    `cua_bac`
                ],
                rong: 1.8
            },
            {
                qua: [
                    `tram_tuong_gioi`,
                    `cho_tru_u_da`,
                    `cua_dong`
                ],
                rong: 1.6
            },
            {
                qua: [
                    `tu_tuong_gioi`,
                    `cho_tru_leu_hoang`,
                    `cua_tay`
                ],
                rong: 1.6
            },
            {
                qua: [
                    `cho_tru_hang_da`,
                    `cua_dong_bac`
                ],
                rong: 1.3
            },
            {
                qua: [
                    `go_soi_gio_vuong`,
                    `cho_tru_hang_da`
                ],
                rong: 1.2
            }
        ],
        cachChung: 1.1,
        tranhNoi: 3,
        do: [
            ...Ze(),
            ...Qe,
            {
                anh: [
                    `prop_kho_small_animal_skull`,
                    `prop_kho_small_bones`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^go_soi_gio_vuong$`,
                    r: 14
                },
                mat: 14,
                cach: 6,
                k: [
                    0.9,
                    1.2
                ],
                cum: 0.5,
                gan: 1,
                mau: 15264496
            },
            {
                anh: [
                    `nen_lc_long_soi_rung`,
                    `nen_lc_xuong_thu`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^go_soi_gio_vuong$`,
                    r: 14
                },
                mat: 8,
                cach: 8,
                k: [
                    0.85,
                    1.05
                ],
                bet: true,
                cum: 0.5
            },
            {
                anh: [
                    `nen_bl_vet_chan_soi`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^go_soi_gio_vuong$`,
                    r: 16
                },
                mat: 8,
                cach: 6,
                k: [
                    0.9,
                    1.1
                ],
                bet: true,
                cum: 0.3
            }
        ],
        dong: $e
    };
    let zone_ho_nguyet_nha = {
        ...zone_thao_nguyen_tuyet,
        nuoc: {
            ...Ye,
            nong: [
                96,
                160,
                184
            ],
            sau: [
                28,
                74,
                112
            ],
            bang: {
                rong: 2.4,
                mau: [
                    204,
                    228,
                    242
                ]
            },
            dong: {
                lap: 40,
                la: 0,
                gon: 6
            }
        },
        loiThem: [
            {
                qua: [
                    `cua_dong`,
                    `cho_tru_bo_ho`,
                    `bo_ho_nam`,
                    `cua_nam`
                ],
                rong: 1.6
            },
            {
                qua: [
                    `cua_dong`,
                    `cho_tru_da`
                ],
                rong: 1.2
            }
        ],
        do: [
            ...Ze(),
            ...Qe,
            {
                anh: [
                    `prop_kho_tall_reeds`
                ],
                noi: `nuoc_nong`,
                mat: 30,
                cach: 3,
                k: [
                    0.9,
                    1.3
                ],
                lay: true,
                cum: 0.5,
                con: 1,
                gan: 0.9,
                bong: false,
                mau: 14736588
            }
        ]
    };
    let zone_vuong_dinh = {
        ...(({ nuoc, ...rest })=>rest)(zone_thao_nguyen_tuyet),
        the: {
            mat: [
                150,
                146,
                140
            ],
            vach: [
                104,
                98,
                96
            ],
            khe: [
                40,
                36,
                36
            ],
            vien: [
                214,
                208,
                200
            ],
            hat: 0.4,
            caoMax: 3
        },
        san: {
            mau: [
                158,
                158,
                166
            ],
            vua: [
                92,
                94,
                106
            ],
            o: 0.62,
            reu: 0.65,
            reuMau: [
                226,
                232,
                242
            ]
        },
        loiThem: [
            {
                qua: [
                    `cua_nam`,
                    `doanh_lien_quan_nam`
                ],
                rong: 1.6
            },
            {
                qua: [
                    `doanh_lien_quan_tay`,
                    `phuc_dia_vuong_dinh`,
                    `doanh_lien_quan_dong`
                ],
                rong: 1.2
            }
        ],
        do: [
            ...Ze(0.6),
            {
                anh: [
                    `nen_bl_go_tuyet_nho`
                ],
                noi: `dat`,
                mat: 1.6,
                cach: 10,
                k: [
                    0.7,
                    1
                ],
                bet: true,
                cum: 0.5
            },
            {
                anh: [
                    `prop_kho_cracked_grey_stone`,
                    `prop_kho_flat_grey_stone`
                ],
                noi: `chan_vach`,
                mat: 10,
                cach: 6,
                k: [
                    0.6,
                    0.9
                ],
                cum: 0.5,
                gan: 1.1,
                mau: 14474468
            }
        ]
    };
    let zone_doanh_trai_toc = {
        nen: [
            `nen_bl_tuyet_a`,
            `nen_bl_tuyet_b`
        ],
        duong: `nen_bl_dat_bun_tuyet`,
        loai: qe,
        da: Je,
        dat: {
            ...dat,
            gon: 0.6,
            lap: 0.4
        },
        bong: {
            dam: 0.42
        },
        caoDo: {
            mat: 0.25
        },
        tong: [
            0.99,
            1,
            1.02
        ],
        loi: {
            rong: 1.2,
            dam: 0.55
        },
        loiThem: [
            {
                qua: [
                    `cua_tay`,
                    `cho_npc_giao_dich`,
                    `cho_npc_nhiem_vu`,
                    `cho_npc_khe_uoc`
                ],
                rong: 2.2
            },
            {
                qua: [
                    `cho_npc_nhiem_vu`,
                    `cho_npc_dan`
                ],
                rong: 1.6
            },
            {
                qua: [
                    `cho_npc_te_su`,
                    `cho_npc_quan_nhu`
                ],
                rong: 1.6
            }
        ],
        nenNha: {
            loc: (e)=>e.startsWith(`vc_`),
            rong: 1.4,
            nam: 2
        },
        datThem: [
            {
                x: 64,
                y: 47,
                r: 9
            },
            {
                x: 31,
                y: 52,
                r: 3
            },
            {
                x: 92,
                y: 52,
                r: 3
            }
        ],
        cachChung: 1.1,
        tranhNoi: 2.4,
        do: [
            ...Ze(0.7),
            {
                anh: [
                    `nen_bt_vet_banh_xe`,
                    `nen_bl_vet_chan_soi`
                ],
                noi: `dat`,
                mat: 1.2,
                cach: 10,
                k: [
                    0.8,
                    1
                ],
                bet: true,
                cum: 0.4
            },
            {
                anh: [
                    `prop_kho_straw_bundle`,
                    `prop_kho_small_crate`,
                    `prop_kho_pile_of_sticks`
                ],
                noi: `chan_bo`,
                mat: 16,
                cach: 5,
                k: [
                    0.8,
                    1
                ],
                cum: 0.4,
                gan: 1.1,
                mau: 14999768
            },
            {
                anh: [
                    `prop_phu_chung_duoc_a`,
                    `prop_phu_chung_duoc_b`
                ],
                noi: `chan_bo`,
                mat: 3,
                cach: 12,
                k: [
                    0.85,
                    1
                ],
                cum: 0.3,
                gan: 1.4,
                sang: {
                    mau: 16748592,
                    r: 3
                }
            }
        ],
        dong: {
            ...$e,
            tuyet: 110,
            khoi: [
                [
                    64,
                    48.4
                ],
                [
                    40,
                    20
                ],
                [
                    86,
                    69.5
                ],
                [
                    28,
                    63.5
                ]
            ]
        }
    };
    let zone_cho_giao_hoi = {
        ...zone_doanh_trai_toc,
        loiThem: [
            {
                qua: [
                    `cua_nam`,
                    `cho_npc_tap_hoa`,
                    `san_cho`,
                    `cho_npc_ban_co`
                ],
                rong: 2.6
            },
            {
                qua: [
                    `san_cho`,
                    `cho_npc_song_bac`
                ],
                rong: 1.6
            },
            {
                qua: [
                    `san_cho`,
                    `cho_npc_no_thu`
                ],
                rong: 1.6
            },
            {
                qua: [
                    `cua_nam`,
                    `cho_npc_hang_lau`
                ],
                rong: 1.2
            }
        ],
        datThem: [
            {
                x: 48,
                y: 37,
                r: 7
            },
            {
                x: 22,
                y: 29,
                r: 4
            },
            {
                x: 72,
                y: 26,
                r: 6
            }
        ],
        dong: {
            ...$e,
            tuyet: 110,
            khoi: [
                [
                    48,
                    36.4
                ],
                [
                    20,
                    51.5
                ]
            ]
        }
    };
    let zone_coc_noan_chieu = {
        nen: [
            `nen_ht_co_lau_ua`,
            `nen_ht_bun_den_b`
        ],
        duong: `nen_bl_dat_bun_tuyet`,
        loai: qe,
        da: {
            ...Je,
            tuyet: 0.45,
            mat: [
                104,
                104,
                106
            ],
            vach: [
                74,
                74,
                80
            ],
            cao: [
                1.4,
                3
            ],
            reu: {
                mau: [
                    70,
                    90,
                    60
                ],
                mat: 0.3
            }
        },
        nuoc: {
            nong: [
                92,
                150,
                150
            ],
            sau: [
                30,
                84,
                92
            ],
            bot: [
                226,
                236,
                236
            ],
            troi: [
                206,
                226,
                232
            ],
            uot: [
                112,
                116,
                104
            ],
            trong: 0.3,
            chay: [
                0,
                1
            ],
            am: 4,
            dong: {
                lap: 30,
                la: 0,
                gon: 4,
                bot: 12
            },
            daBo: 0.35,
            daGiua: 0.25,
            daMau: [
                92,
                96,
                104
            ]
        },
        dat: {
            soi: 0.04,
            soiMau: [
                104,
                104,
                96
            ],
            mang: 0.55,
            tiB: 0.42,
            phang: 0.4,
            song: 0.35,
            songMau: [
                0.86,
                0.92,
                0.96
            ],
            uot: {
                mau: [
                    120,
                    124,
                    112
                ],
                mat: 0.3
            }
        },
        bong: {
            dam: 0.38
        },
        tong: [
            0.97,
            1,
            1
        ],
        loi: {
            rong: 1,
            dam: 0.45
        },
        loiThem: [
            {
                qua: [
                    `cua_bac`,
                    `cho_tru_suoi_nong`,
                    `san_soi_rau_doc_vuong`
                ],
                rong: 1.6
            },
            {
                qua: [
                    `san_soi_rau_doc_vuong`,
                    `tuyen_truy_duoi`
                ],
                rong: 1.4
            },
            {
                qua: [
                    `cho_tru_suoi_nong`,
                    `cot_moc_ma_gia`
                ],
                rong: 1.2
            }
        ],
        cachChung: 1.1,
        tranhNoi: 3,
        do: [
            {
                anh: [
                    `prop_kho_reeds_clump`,
                    `prop_kho_tall_reeds`
                ],
                noi: `mep_nuoc`,
                mat: 160,
                cach: 2.4,
                k: [
                    0.9,
                    1.4
                ],
                lay: true,
                cum: 0.45,
                con: 2,
                gan: 0.75,
                bong: false,
                mau: 14210236
            },
            {
                anh: [
                    `nen_ht_cum_lau`
                ],
                noi: `nuoc_nong`,
                mat: 140,
                cach: 3,
                k: [
                    0.6,
                    1
                ],
                lay: true,
                cum: 0.3,
                con: 2,
                gan: 1,
                bong: false
            },
            {
                anh: [
                    `prop_kho_smooth_river_stones`,
                    `prop_pg_da_tuyet_cum`
                ],
                noi: `mep_nuoc`,
                mat: 30,
                cach: 4,
                k: [
                    0.45,
                    0.8
                ],
                cum: 0.5,
                gan: 1
            },
            {
                anh: [
                    `prop_kho_mud_puddle`,
                    `nen_ht_dat_kho_nut`
                ],
                noi: `dat`,
                mat: 1.2,
                cach: 9,
                k: [
                    0.7,
                    1
                ],
                bet: true,
                cum: 0.6
            },
            {
                anh: [
                    `prop_kho_reeds_clump`,
                    `prop_kho_tall_wild_grass`
                ],
                noi: `dat`,
                mat: 8,
                cach: 3,
                k: [
                    0.7,
                    1.05
                ],
                lay: true,
                cum: 0.85,
                con: 3,
                gan: 0.8,
                bong: false,
                mau: 13157540
            },
            {
                anh: [
                    `prop_kho_dead_leafless_tree`
                ],
                noi: `chan_vach`,
                sat: 0.6,
                mat: 10,
                cach: 9,
                k: [
                    0.85,
                    1.1
                ],
                cum: 0.5,
                gan: 2,
                cao: 3,
                mau: 13684940
            },
            {
                anh: [
                    `prop_pg_da_tuyet_cum`,
                    `prop_kho_cracked_grey_stone`
                ],
                noi: `chan_vach`,
                mat: 40,
                cach: 3.6,
                k: [
                    0.45,
                    0.85
                ],
                cum: 0.5,
                con: 1,
                gan: 1
            },
            {
                anh: [
                    `nen_bl_mang_co_lo`
                ],
                noi: `chan_vach`,
                mat: 20,
                cach: 3,
                k: [
                    0.25,
                    0.4
                ],
                lay: true,
                cum: 0.6,
                gan: 0.8,
                bong: false
            },
            {
                anh: [
                    `prop_pg_da_tuyet_cum`
                ],
                noi: `dinh`,
                mat: 6,
                cach: 6,
                k: [
                    0.5,
                    0.9
                ],
                cum: 0.5,
                gan: 1.3
            },
            {
                anh: [
                    `prop_kho_rib_bones`,
                    `prop_kho_small_bones`
                ],
                noi: `dat`,
                quanh: {
                    noi: `^san_soi_rau_doc_vuong$`,
                    r: 12
                },
                mat: 12,
                cach: 6,
                k: [
                    0.9,
                    1.1
                ],
                cum: 0.4,
                gan: 1
            },
            {
                anh: [
                    `nen_bl_go_tuyet_nho`,
                    `nen_bl_soi_tuyet`
                ],
                noi: `dat`,
                mat: 3.5,
                cach: 7,
                k: [
                    0.9,
                    1.3
                ],
                bet: true,
                cum: 0.7
            },
            {
                anh: [
                    `nen_bl_go_tuyet_nho`
                ],
                noi: `chan_vach`,
                mat: 14,
                cach: 5,
                k: [
                    0.9,
                    1.2
                ],
                bet: true,
                cum: 0.5
            }
        ],
        dong: {
            tuyet: 50,
            suong: {
                so: 12,
                mau: 15266032,
                a: 0.28
            },
            chim: 0.3,
            bui: {
                so: 10,
                mau: 15922943
            },
            khoi: [
                [
                    40,
                    38
                ],
                [
                    72,
                    28
                ],
                [
                    56,
                    70
                ],
                [
                    88,
                    98
                ],
                [
                    28,
                    100
                ]
            ]
        }
    };
    let ot = {
        x: 15,
        y: 14
    };
    let st = {
        zone_thao_nguyen_tuyet,
        zone_ho_nguyet_nha,
        zone_vuong_dinh,
        zone_doanh_trai_toc,
        zone_cho_giao_hoi,
        zone_coc_noan_chieu,
        inst_lau_chan_duong: {
            nen: [
                `prop_tl_san_dot_pha_a`,
                `prop_tl_san_dot_pha_b`
            ],
            duong: `prop_tl_san_dot_pha_b`,
            loai: qe,
            the: {
                mat: [
                    92,
                    64,
                    56
                ],
                vach: [
                    78,
                    50,
                    44
                ],
                khe: [
                    26,
                    16,
                    14
                ],
                vien: [
                    168,
                    120,
                    96
                ],
                hat: 0.45,
                caoMax: 3.4
            },
            da: {
                anh: `prop_tl_vach_dot_pha`,
                cao: [
                    2.8,
                    3.6
                ],
                cot: [
                    0.6,
                    1
                ],
                mat: [
                    84,
                    62,
                    56
                ],
                vach: [
                    72,
                    50,
                    44
                ],
                khe: [
                    22,
                    14,
                    12
                ],
                vien: [
                    160,
                    116,
                    92
                ],
                tam: 1.3,
                lo: 0.4,
                hat: 0.5,
                vat: 0.2,
                khoi: 1.4,
                mach: {
                    mau: [
                        240,
                        196,
                        110
                    ],
                    mat: 0.2,
                    den: {
                        r: 1.1,
                        mau: 16762992,
                        cach: 4.5
                    }
                }
            },
            vungNen: [
                {
                    anh: `prop_tl_san_dot_pha_a`,
                    tam: [
                        ot.x,
                        ot.y
                    ],
                    r: [
                        8.4,
                        8.4
                    ],
                    mem: 2.6,
                    nhan: [
                        1.36,
                        1.3,
                        1.18
                    ]
                }
            ],
            dat: {
                soi: 0.03,
                soiMau: [
                    110,
                    100,
                    96
                ],
                mang: 0.3,
                tiB: 0.15,
                phang: 0.15
            },
            bong: {
                dam: 0.45
            },
            tong: [
                1.02,
                0.96,
                0.92
            ],
            loi: {
                rong: 1,
                dam: 0.3
            },
            dong: {
                hatSang: {
                    so: 14,
                    mau: 16767120
                }
            },
            vatThem: [
                {
                    hinh: `prop_tl_vong_tran_dot_pha`,
                    x: ot.x,
                    y: 17.6,
                    k: 0.41,
                    nen: true
                }
            ],
            cachChung: 1.1,
            tranhNoi: 2.2,
            do: [
                {
                    anh: [
                        `prop_kho_cracked_grey_stone`,
                        `prop_kho_flat_grey_stone`,
                        `prop_kho_rubble_pile`
                    ],
                    noi: `chan_vach`,
                    mat: 380,
                    cach: 2.6,
                    k: [
                        0.7,
                        1.05
                    ],
                    cum: 0.6,
                    gan: 0.8,
                    sat: 1,
                    mau: 14205108
                },
                {
                    anh: [
                        `prop_kho_small_pebbles`,
                        `prop_kho_flat_grey_stone`
                    ],
                    noi: `dat`,
                    mat: 45,
                    cach: 3,
                    k: [
                        0.7,
                        1
                    ],
                    cum: 0.7,
                    con: 1,
                    gan: 0.9,
                    bong: false,
                    mau: 14208196,
                    nen: {
                        ngoai: 0
                    }
                },
                {
                    anh: [
                        `prop_tl_vet_nut_san`
                    ],
                    noi: `dat`,
                    mat: 4,
                    cach: 9,
                    k: [
                        0.4,
                        0.6
                    ],
                    bet: true,
                    cum: 0.4,
                    nen: {
                        ngoai: 0
                    }
                },
                {
                    anh: [
                        `nen_ms_mach_nguyen_thach`
                    ],
                    noi: `chan_vach`,
                    mat: 30,
                    cach: 9,
                    k: [
                        0.55,
                        0.8
                    ],
                    bet: true,
                    cum: 0.4,
                    sat: 1
                }
            ],
            voDai: false
        }
    };
    function ct(e) {
        let { nuoc, loiThem, datThem, ...rest } = e;
        return {
            ...rest,
            do: (e.do ?? []).filter((e)=>!e.quanh).map((e)=>({
                    ...e,
                    mat: e.mat * 2.5
                }))
        };
    }
    let lt = {
        inst_hang_dia_thu: ct({
            ...zone_coc_noan_chieu,
            dong: {
                ...zone_coc_noan_chieu.dong,
                khoi: []
            }
        }),
        inst_huyet_soi_tuyet: ct(zone_thao_nguyen_tuyet)
    };
    let ut = (e, t)=>({
            hinh: `prop_kho_wooden_signpost_two`,
            x: e,
            y: t - 0.8,
            k: 1
        });
    let dt = {
        zone_vuong_dinh: [
            ut(26, 24),
            ut(18, 66),
            ut(128, 9)
        ],
        zone_ho_nguyet_nha: [
            ut(100, 28),
            ut(172, 26)
        ]
    };
    let sang = [
        0.8,
        1
    ];
    let pt = [
        `prop_kho_clover_patch`,
        `prop_kho_short_green_grass_tuft`
    ];
    let mt = {
        zone_khe_coc: {
            bien: {
                la: [
                    16774336,
                    12380372
                ],
                kho: [
                    16773320,
                    15260864
                ],
                hoa: [
                    16777215,
                    14998783
                ],
                sang
            },
            tham: [
                {
                    anh: pt,
                    noi: `dat`,
                    mat: 150,
                    cach: 2.6,
                    k: [
                        1.5,
                        2.1
                    ],
                    cum: 0.85,
                    con: 3,
                    gan: 0.7
                },
                {
                    anh: [
                        `prop_kho_small_white_wildflowers`,
                        `prop_kho_tiny_blue_flowers`,
                        `prop_kho_dandelions`
                    ],
                    noi: `dat`,
                    mat: 40,
                    cach: 3.5,
                    k: [
                        1.5,
                        2
                    ],
                    cum: 0.9,
                    con: 3,
                    gan: 0.75
                },
                {
                    anh: pt,
                    noi: `mep_nuoc`,
                    mat: 120,
                    cach: 2.6,
                    k: [
                        1.5,
                        2.1
                    ],
                    cum: 0.7,
                    con: 2,
                    gan: 0.7
                }
            ]
        },
        zone_ta_gia_trai: {
            bien: {
                la: [
                    16773316,
                    13165772
                ],
                kho: [
                    16773320,
                    15260864
                ],
                hoa: [
                    16777215,
                    16770256
                ],
                sang
            },
            tham: [
                {
                    anh: pt,
                    noi: `dat`,
                    mat: 120,
                    cach: 2.6,
                    k: [
                        1.5,
                        2.1
                    ],
                    cum: 0.85,
                    con: 3,
                    gan: 0.7
                },
                {
                    anh: [
                        `prop_kho_dandelions`,
                        `prop_kho_small_white_wildflowers`
                    ],
                    noi: `dat`,
                    mat: 26,
                    cach: 3.5,
                    k: [
                        1.5,
                        2
                    ],
                    cum: 0.9,
                    con: 2,
                    gan: 0.75
                }
            ]
        },
        zone_vu_linh_ha: {
            bien: {
                la: [
                    16772280,
                    11853000
                ],
                kho: [
                    16771264,
                    14733496
                ],
                hoa: [
                    16777215,
                    15259903
                ],
                sang
            },
            tham: [
                {
                    anh: [
                        `prop_kho_short_green_grass_tuft`,
                        `prop_kho_small_fern_plant`,
                        `prop_kho_clover_patch`
                    ],
                    noi: `dat`,
                    mat: 130,
                    cach: 2.8,
                    k: [
                        1.5,
                        2.1
                    ],
                    cum: 0.85,
                    con: 3,
                    gan: 0.7
                },
                {
                    anh: [
                        `prop_kho_small_fern_plant`,
                        `prop_kho_short_green_grass_tuft`
                    ],
                    noi: `mep_rung`,
                    mat: 90,
                    cach: 2.6,
                    k: [
                        1.6,
                        2.2
                    ],
                    cum: 0.7,
                    con: 2,
                    gan: 0.7
                }
            ]
        },
        zone_lang_coc: {
            bien: {
                la: [
                    16769216,
                    15255736
                ],
                kho: [
                    16767160,
                    14991536
                ],
                hoa: [
                    16777215,
                    16769232
                ],
                sang
            },
            tham: [
                {
                    anh: [
                        `prop_kho_dry_yellow_grass_tuft`
                    ],
                    noi: `dat`,
                    mat: 70,
                    cach: 2.4,
                    k: [
                        1.4,
                        2
                    ],
                    cum: 0.85,
                    con: 3,
                    gan: 0.7,
                    mau: 16046276
                },
                {
                    anh: [
                        `prop_kho_small_pebbles`
                    ],
                    noi: `dat`,
                    mat: 14,
                    cach: 4,
                    k: [
                        1.3,
                        1.8
                    ],
                    cum: 0.7,
                    con: 2,
                    gan: 0.8,
                    mau: 15251616
                }
            ]
        },
        inst_chien_truong: {
            bien: {
                la: [
                    16773312,
                    14474416
                ],
                kho: [
                    16773316,
                    15517856
                ],
                hoa: [
                    16777215,
                    16773336
                ],
                sang
            },
            tham: [
                {
                    anh: [
                        `prop_kho_dry_yellow_grass_tuft`
                    ],
                    noi: `dat`,
                    mat: 70,
                    cach: 2.4,
                    k: [
                        1.4,
                        2
                    ],
                    cum: 0.85,
                    con: 3,
                    gan: 0.7
                },
                {
                    anh: [
                        `prop_kho_short_green_grass_tuft`
                    ],
                    noi: `dat`,
                    mat: 30,
                    cach: 2.6,
                    k: [
                        1.4,
                        2
                    ],
                    cum: 0.85,
                    con: 2,
                    gan: 0.7,
                    mau: 15261872
                },
                {
                    anh: [
                        `prop_kho_small_pebbles`
                    ],
                    noi: `dat`,
                    mat: 10,
                    cach: 4,
                    k: [
                        1.3,
                        1.8
                    ],
                    cum: 0.7,
                    con: 2,
                    gan: 0.8
                }
            ]
        },
        zone_luc_bien: {
            bien: {
                la: [
                    16773320,
                    15260856
                ],
                kho: [
                    16773312,
                    15257768
                ],
                hoa: [
                    16777215,
                    16773336
                ],
                sang
            },
            tham: [
                {
                    anh: [
                        `prop_kho_dry_yellow_grass_tuft`
                    ],
                    noi: `dat`,
                    mat: 60,
                    cach: 2.4,
                    k: [
                        1.4,
                        2
                    ],
                    cum: 0.85,
                    con: 3,
                    gan: 0.7
                },
                {
                    anh: [
                        `prop_kho_small_pebbles`
                    ],
                    noi: `dat`,
                    mat: 12,
                    cach: 4,
                    k: [
                        1.3,
                        1.8
                    ],
                    cum: 0.7,
                    con: 2,
                    gan: 0.8
                }
            ]
        },
        zone_hac_thuy: {
            bien: {
                la: [
                    15265984,
                    12636360
                ],
                kho: [
                    15262912,
                    13159612
                ],
                hoa: [
                    15790304,
                    14209256
                ],
                sang: [
                    0.76,
                    0.96
                ]
            },
            tham: [
                {
                    anh: [
                        `prop_kho_tall_wild_grass`,
                        `prop_kho_short_green_grass_tuft`
                    ],
                    noi: `mep_nuoc`,
                    mat: 90,
                    cach: 2.6,
                    k: [
                        1.4,
                        2
                    ],
                    cum: 0.8,
                    con: 3,
                    gan: 0.7,
                    mau: 13158568
                }
            ]
        },
        zone_bac_linh: {
            bien: {
                la: [
                    15791359,
                    13688048
                ],
                kho: [
                    15789296,
                    13949156
                ],
                hoa: [
                    16777215,
                    15265023
                ],
                sang: [
                    0.86,
                    1
                ]
            },
            tham: [
                {
                    anh: [
                        `nen_bl_mang_co_lo`
                    ],
                    noi: `dat`,
                    mat: 7,
                    cach: 3,
                    k: [
                        0.22,
                        0.34
                    ],
                    cum: 0.9,
                    con: 2,
                    gan: 0.7
                }
            ]
        },
        zone_mach_sau: {
            bien: {
                la: [
                    14221296,
                    14209279
                ],
                kho: [
                    14741744,
                    14210288
                ],
                hoa: [
                    14745588,
                    14735615
                ],
                sang: [
                    0.84,
                    1
                ]
            },
            tham: []
        },
        zone_mo_cu: {
            bien: {
                la: [
                    16773336,
                    14213352
                ],
                kho: [
                    16773336,
                    14212328
                ],
                hoa: [
                    16777215,
                    15263999
                ],
                sang
            },
            tham: []
        },
        zone_ben_thuong: {
            bien: {
                la: [
                    16774344,
                    13166808
                ],
                kho: [
                    16773320,
                    15260864
                ],
                hoa: [
                    16777215,
                    15261951
                ],
                sang
            },
            tham: [
                {
                    anh: pt,
                    noi: `dat`,
                    mat: 70,
                    cach: 2.6,
                    k: [
                        1.5,
                        2.1
                    ],
                    cum: 0.85,
                    con: 2,
                    gan: 0.7
                }
            ]
        }
    };
    function ht(anh) {
        let t = {
            hoa: 0,
            kho: 0,
            la: 0
        };
        for (let n of anh){
            let e = n.replace(/^prop_kho_/, `prop_`);
            if (/(flower|chrysanthemum|dandelion|lily|hoa_dai|bui_hoa)/.test(e)) {
                t.hoa++;
            } else if (/(dry_|co_kho|bui_kho|straw|reed|_lau)/.test(e)) {
                t.kho++;
            } else if (/(grass|clover|fern|duong_xi|bui_|bush|_co_|co_cao|thong_non|cay_bui|herb)/.test(e)) {
                t.la++;
            }
        }
        let n = Math.max(t.hoa, t.kho, t.la);
        if (n) {
            if (t.hoa === n) {
                return `hoa`;
            }
            if (t.kho === n) {
                return `kho`;
            }
            return `la`;
        }
        return null;
    }
    let gt = /(bui_to|bui_vua|hang_bui|bui_rung|cay_bui|thong_non|bui_thu|cay_kho|bui_gai|bui_kho|thorny_bush|cum_lau|mep_bo_lau|duong_xi|bui_hoa|mang_co_lo)/;
    let _t = {
        du: {
            lay: 1.45,
            bet: 1.6,
            con: 1,
            tham: 1,
            domDom: 1.8
        },
        nhe: {
            lay: 1.15,
            bet: 1.3,
            con: 0,
            tham: 0.6,
            domDom: 1.3
        }
    };
    let vt = new Map;
    function yt(e, t, n) {
        if (!t || t === `tat`) {
            return e;
        }
        let r = mt[n];
        if (!r) {
            return e;
        }
        let i = vt.get(e);
        if (!i) {
            i = new Map;
            vt.set(e, i);
        }
        let a = i.get(t);
        if (a) {
            return a;
        }
        let o = _t[t];
        let s = e.do.map((e)=>{
            let t = ht(e.anh);
            if (!t || e.sang || e.quanh) {
                return e;
            }
            if (e.bet) {
                return {
                    ...e,
                    mat: e.mat * o.bet,
                    bien: {
                        mau: r.bien[t],
                        sang: r.bien.sang
                    }
                };
            }
            if (!e.lay || e.anh.some((e)=>gt.test(e))) {
                return {
                    ...e,
                    bien: {
                        mau: r.bien[t],
                        sang: r.bien.sang
                    }
                };
            }
            return {
                ...e,
                mat: e.mat * o.lay,
                cumLoai: true,
                con: (e.con ?? 0) + o.con,
                bien: {
                    mau: r.bien[t],
                    sang: r.bien.sang
                }
            };
        });
        for (let e of r.tham){
            let t = ht(e.anh) ?? `la`;
            s.push({
                ...e,
                mat: e.mat * o.tham,
                bet: true,
                bong: false,
                cumLoai: true,
                bien: {
                    mau: r.bien[t],
                    sang: r.bien.sang
                }
            });
        }
        let c = e.dong ? {
            ...e.dong,
            ...e.dong.domDom ? {
                domDom: Math.round(e.dong.domDom * o.domDom)
            } : {}
        } : undefined;
        let l = {
            ...e,
            do: s,
            ...c ? {
                dong: c
            } : {}
        };
        i.set(t, l);
        return l;
    }
    let bt = (e)=>e.map(([hinh, t, y_1, k_1, i])=>({
                hinh,
                x: t,
                y: y_1,
                k: k_1,
                lat: i === 1
            }));
    let xt = bt([
        [
            `prop_phu_hac_thuy_goc_muc_c`,
            200.4,
            52.4,
            0.49,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_a`,
            201.8,
            52.1,
            0.46,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_d`,
            200.5,
            53.9,
            0.42,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_b`,
            199.9,
            51.3,
            0.43,
            1
        ],
        [
            `nen_ht_cum_lau`,
            53.9,
            113.5,
            0.37,
            0
        ],
        [
            `nen_ht_cum_lau`,
            8.9,
            109.7,
            0.44,
            1
        ],
        [
            `nen_ht_cum_lau`,
            279.7,
            176.4,
            0.37,
            0
        ],
        [
            `prop_phu_hac_thuy_goc_muc_d`,
            274.7,
            36.7,
            0.47,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_d`,
            273.7,
            37.3,
            0.46,
            0
        ],
        [
            `nen_ht_cum_lau`,
            274.7,
            34.8,
            0.28,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            214.5,
            28.6,
            0.48,
            1
        ],
        [
            `nen_ht_cum_lau`,
            213.5,
            27.8,
            0.33,
            0
        ],
        [
            `nen_ht_cum_lau`,
            55.6,
            73.6,
            0.43,
            1
        ],
        [
            `prop_phu_hac_thuy_da_den_b`,
            55.2,
            74.8,
            0.41,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            50.8,
            52.4,
            0.49,
            1
        ],
        [
            `prop_phu_hac_thuy_go_bun_c`,
            49.2,
            53.4,
            0.43,
            0
        ],
        [
            `nen_ht_cum_lau`,
            52.4,
            53,
            0.36,
            0
        ],
        [
            `nen_ht_cum_lau`,
            49.4,
            51.1,
            0.36,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            210.7,
            66.3,
            0.47,
            1
        ],
        [
            `nen_ht_cum_lau`,
            209.1,
            65.8,
            0.35,
            0
        ],
        [
            `nen_ht_cum_lau`,
            212.7,
            66.6,
            0.29,
            0
        ],
        [
            `nen_ht_cum_lau`,
            166.5,
            206,
            0.35,
            1
        ],
        [
            `nen_ht_cum_lau`,
            34.1,
            235.4,
            0.31,
            1
        ],
        [
            `nen_ht_cum_lau`,
            226.5,
            225,
            0.34,
            1
        ],
        [
            `nen_ht_cum_lau`,
            226.3,
            228,
            0.32,
            1
        ],
        [
            `prop_phu_hac_thuy_da_den_a`,
            227.6,
            225.3,
            0.42,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            176.6,
            5,
            0.46,
            1
        ],
        [
            `nen_ht_cum_lau`,
            175.2,
            5.2,
            0.41,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            86.8,
            10.7,
            0.46,
            1
        ],
        [
            `nen_ht_cum_lau`,
            86.7,
            9.5,
            0.29,
            0
        ],
        [
            `nen_ht_cum_lau`,
            273.6,
            226.8,
            0.36,
            0
        ],
        [
            `prop_phu_hac_thuy_da_den_a`,
            275.4,
            225.7,
            0.4,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            28.4,
            102.4,
            0.51,
            1
        ],
        [
            `nen_ht_cum_lau`,
            29.1,
            103.8,
            0.3,
            0
        ],
        [
            `prop_phu_hac_thuy_da_den_a`,
            197.3,
            18.5,
            0.42,
            0
        ],
        [
            `nen_ht_cum_lau`,
            292.9,
            235.6,
            0.31,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            28.4,
            204.7,
            0.51,
            1
        ],
        [
            `prop_phu_hac_thuy_go_bun_c`,
            26.7,
            203.5,
            0.4,
            0
        ],
        [
            `nen_ht_cum_lau`,
            29.7,
            205.7,
            0.37,
            0
        ],
        [
            `nen_ht_cum_lau`,
            27.8,
            203.2,
            0.33,
            0
        ],
        [
            `nen_ht_cum_lau`,
            151.1,
            32.8,
            0.42,
            0
        ],
        [
            `nen_ht_cum_lau`,
            154.4,
            32.4,
            0.41,
            0
        ],
        [
            `prop_phu_hac_thuy_da_den_d`,
            260.8,
            242.5,
            0.45,
            1
        ],
        [
            `prop_phu_hac_thuy_da_den_a`,
            176.8,
            20.3,
            0.44,
            1
        ],
        [
            `prop_phu_hac_thuy_da_den_c`,
            175.8,
            20.6,
            0.44,
            0
        ],
        [
            `nen_ht_cum_lau`,
            123.2,
            15.8,
            0.42,
            1
        ],
        [
            `nen_ht_cum_lau`,
            126.3,
            15.9,
            0.35,
            1
        ],
        [
            `nen_ht_cum_lau`,
            157.5,
            197.6,
            0.3,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            238.3,
            244.4,
            0.47,
            1
        ],
        [
            `prop_phu_hac_thuy_go_bun_c`,
            237.1,
            244.8,
            0.44,
            0
        ],
        [
            `nen_ht_cum_lau`,
            239.3,
            245.5,
            0.36,
            0
        ],
        [
            `nen_ht_cum_lau`,
            236.4,
            243.7,
            0.34,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            62.6,
            220.5,
            0.49,
            0
        ],
        [
            `prop_phu_hac_thuy_go_bun_b`,
            64.2,
            221,
            0.46,
            0
        ],
        [
            `nen_ht_cum_lau`,
            61.1,
            219.5,
            0.35,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            224.5,
            206.5,
            0.45,
            0
        ],
        [
            `nen_ht_cum_lau`,
            225.7,
            206.6,
            0.31,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            12.5,
            248.4,
            0.45,
            1
        ],
        [
            `prop_phu_hac_thuy_go_bun_a`,
            11.1,
            249.2,
            0.4,
            1
        ],
        [
            `nen_ht_cum_lau`,
            13.1,
            250.3,
            0.29,
            0
        ],
        [
            `nen_ht_cum_lau`,
            12.5,
            247.3,
            0.34,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            48.5,
            174.5,
            0.45,
            1
        ],
        [
            `prop_phu_hac_thuy_go_bun_a`,
            49.7,
            174.6,
            0.42,
            0
        ],
        [
            `nen_ht_cum_lau`,
            47.5,
            175.4,
            0.3,
            1
        ],
        [
            `prop_phu_hac_thuy_goc_muc_c`,
            26.5,
            118.4,
            0.42,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_d`,
            24.9,
            118.3,
            0.45,
            0
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_a`,
            26.4,
            119.5,
            0.46,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_b`,
            25.5,
            117.4,
            0.42,
            1
        ],
        [
            `nen_ht_cum_lau`,
            28.8,
            118.7,
            0.32,
            1
        ],
        [
            `nen_ht_cum_lau`,
            61.5,
            60.3,
            0.38,
            1
        ],
        [
            `prop_phu_hac_thuy_goc_muc_d`,
            284.3,
            126.6,
            0.47,
            0
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_b`,
            283.1,
            127.1,
            0.45,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_d`,
            285.9,
            125.7,
            0.46,
            0
        ],
        [
            `nen_ht_cum_lau`,
            284.9,
            125,
            0.35,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            272.5,
            148.5,
            0.51,
            0
        ],
        [
            `nen_ht_cum_lau`,
            274.4,
            147.4,
            0.35,
            0
        ],
        [
            `nen_ht_cum_lau`,
            271.3,
            148.5,
            0.36,
            1
        ],
        [
            `nen_ht_cum_lau`,
            235.5,
            235.8,
            0.41,
            0
        ],
        [
            `nen_ht_cum_lau`,
            237.4,
            233.1,
            0.31,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            266.6,
            42.2,
            0.48,
            0
        ],
        [
            `prop_phu_hac_thuy_go_bun_c`,
            265.1,
            42,
            0.46,
            0
        ],
        [
            `nen_ht_cum_lau`,
            265.6,
            40.8,
            0.28,
            0
        ],
        [
            `nen_ht_cum_lau`,
            161.9,
            49.4,
            0.4,
            0
        ],
        [
            `prop_phu_hac_thuy_da_den_b`,
            161.6,
            51.6,
            0.4,
            1
        ],
        [
            `prop_phu_hac_thuy_da_den_d`,
            79.2,
            196.3,
            0.45,
            0
        ],
        [
            `prop_phu_hac_thuy_goc_muc_a`,
            54.5,
            14.5,
            0.43,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_a`,
            56,
            14.1,
            0.4,
            1
        ],
        [
            `nen_ht_cum_lau`,
            54.6,
            15.7,
            0.29,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            208.5,
            14.2,
            0.51,
            1
        ],
        [
            `prop_phu_hac_thuy_go_bun_b`,
            207.5,
            15.6,
            0.42,
            0
        ],
        [
            `nen_ht_cum_lau`,
            209.7,
            15.3,
            0.31,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            94.5,
            56.5,
            0.45,
            0
        ],
        [
            `nen_ht_cum_lau`,
            93.8,
            55.6,
            0.36,
            1
        ],
        [
            `nen_ht_cum_lau`,
            96.2,
            57.6,
            0.35,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            226.4,
            154.5,
            0.51,
            1
        ],
        [
            `nen_ht_cum_lau`,
            226.8,
            156,
            0.29,
            1
        ],
        [
            `nen_ht_cum_lau`,
            149.3,
            188.7,
            0.44,
            0
        ],
        [
            `prop_phu_hac_thuy_goc_muc_b`,
            262.8,
            122.5,
            0.45,
            0
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_b`,
            261.1,
            122.4,
            0.46,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_a`,
            264.1,
            121.9,
            0.47,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_d`,
            263,
            123.6,
            0.45,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            8.2,
            32.3,
            0.52,
            1
        ],
        [
            `prop_phu_hac_thuy_go_bun_a`,
            9.4,
            33.6,
            0.41,
            1
        ],
        [
            `nen_ht_cum_lau`,
            10.5,
            31.6,
            0.32,
            0
        ],
        [
            `nen_ht_cum_lau`,
            8.5,
            34.4,
            0.29,
            0
        ],
        [
            `nen_ht_cum_lau`,
            32.8,
            135.3,
            0.38,
            0
        ],
        [
            `prop_phu_hac_thuy_da_den_d`,
            144.7,
            220.7,
            0.42,
            0
        ],
        [
            `prop_phu_hac_thuy_xuong_a`,
            143.9,
            219.5,
            0.43,
            1
        ],
        [
            `nen_ht_cum_lau`,
            277.4,
            238.7,
            0.36,
            1
        ],
        [
            `nen_ht_cum_lau`,
            201.1,
            38.9,
            0.31,
            0
        ],
        [
            `prop_phu_hac_thuy_da_den_a`,
            199.7,
            37.8,
            0.42,
            0
        ],
        [
            `nen_ht_cum_lau`,
            176.8,
            209.7,
            0.41,
            1
        ],
        [
            `prop_phu_hac_thuy_da_den_a`,
            176.4,
            211.4,
            0.4,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            84.3,
            220.1,
            0.47,
            1
        ],
        [
            `prop_phu_hac_thuy_go_bun_c`,
            82.8,
            219.5,
            0.4,
            0
        ],
        [
            `nen_ht_cum_lau`,
            84.7,
            221.6,
            0.35,
            1
        ],
        [
            `prop_phu_hac_thuy_da_den_a`,
            226.8,
            166.4,
            0.4,
            0
        ],
        [
            `prop_phu_hac_thuy_xuong_c`,
            226.9,
            167.5,
            0.4,
            1
        ],
        [
            `nen_ht_cum_lau`,
            266.9,
            113.3,
            0.36,
            0
        ],
        [
            `prop_phu_hac_thuy_da_den_b`,
            267.4,
            112.1,
            0.41,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            238.2,
            66.7,
            0.46,
            1
        ],
        [
            `prop_phu_hac_thuy_go_bun_b`,
            236.5,
            65.9,
            0.41,
            0
        ],
        [
            `nen_ht_cum_lau`,
            239.5,
            66.6,
            0.35,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            82.5,
            232.5,
            0.5,
            1
        ],
        [
            `nen_ht_cum_lau`,
            82.2,
            230.7,
            0.38,
            0
        ],
        [
            `nen_ht_cum_lau`,
            80.8,
            233.7,
            0.28,
            0
        ],
        [
            `prop_phu_hac_thuy_da_den_a`,
            8.5,
            236.8,
            0.46,
            0
        ],
        [
            `prop_phu_hac_thuy_xuong_a`,
            10,
            236.1,
            0.38,
            0
        ],
        [
            `prop_phu_hac_thuy_goc_muc_d`,
            288.7,
            58.5,
            0.48,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_a`,
            289.8,
            58.1,
            0.48,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_b`,
            287.5,
            59,
            0.45,
            1
        ],
        [
            `nen_ht_cum_lau`,
            290.7,
            58.7,
            0.36,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            20.5,
            184.5,
            0.46,
            1
        ],
        [
            `nen_ht_cum_lau`,
            21.3,
            185.5,
            0.34,
            0
        ],
        [
            `nen_ht_cum_lau`,
            18.8,
            183.2,
            0.35,
            1
        ],
        [
            `prop_phu_hac_thuy_goc_muc_b`,
            144.3,
            24.2,
            0.49,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_a`,
            145.1,
            25.8,
            0.4,
            0
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_d`,
            145.8,
            23.8,
            0.45,
            1
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_b`,
            144.4,
            23.2,
            0.42,
            0
        ],
        [
            `nen_ht_cum_lau`,
            146,
            25.3,
            0.32,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            112.5,
            252.6,
            0.51,
            1
        ],
        [
            `prop_phu_hac_thuy_go_bun_b`,
            111.6,
            252,
            0.45,
            0
        ],
        [
            `nen_ht_cum_lau`,
            113.7,
            252.2,
            0.36,
            1
        ],
        [
            `prop_phu_hac_thuy_goc_muc_a`,
            284.2,
            162.5,
            0.45,
            0
        ],
        [
            `prop_phu_hac_thuy_hoa_doc_b`,
            285.5,
            161.7,
            0.43,
            0
        ]
    ]);
    let St = bt([
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            20.6,
            141.2,
            0.44,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            23.2,
            140.7,
            0.48,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            27.4,
            140.6,
            0.49,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            30,
            141.5,
            0.48,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            31.9,
            141.3,
            0.5,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            34.1,
            141,
            0.45,
            0
        ],
        [
            `prop_cay_chet`,
            47.1,
            141.3,
            1.03,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            49.1,
            140.6,
            0.48,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            26,
            143.1,
            0.51,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            31.1,
            142.5,
            0.46,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_c`,
            35.2,
            143,
            0.51,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            37.2,
            143.1,
            0.5,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_c`,
            41.4,
            142.5,
            0.51,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            43.4,
            142.6,
            0.49,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            46.1,
            143.4,
            0.49,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            20.7,
            144.8,
            0.46,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_c`,
            24.7,
            144.6,
            0.46,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            29.6,
            145.2,
            0.46,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            33.7,
            144.9,
            0.51,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            40.4,
            144.8,
            0.48,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_a`,
            45,
            145.3,
            0.45,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            47,
            144.7,
            0.46,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            49.5,
            145.4,
            0.47,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_a`,
            22.3,
            146.6,
            0.52,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_b`,
            25.7,
            146.5,
            0.47,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            30.8,
            147.1,
            0.51,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_d`,
            32.8,
            146.5,
            0.47,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            35.3,
            146.7,
            0.49,
            1
        ],
        [
            `prop_cay_chet`,
            37.8,
            146.9,
            1.04,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            39.8,
            146.8,
            0.51,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_d`,
            42,
            146.9,
            0.44,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_b`,
            22.8,
            149.2,
            0.49,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            25.1,
            148.6,
            0.47,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            27.7,
            149.4,
            0.47,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            29.3,
            149.5,
            0.47,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_d`,
            38.8,
            149.4,
            0.48,
            0
        ],
        [
            `prop_cay_chet`,
            44.9,
            149.2,
            1.04,
            0
        ],
        [
            `prop_cay_chet`,
            47.6,
            149.3,
            0.91,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_a`,
            49.2,
            149.4,
            0.51,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            21.8,
            150.6,
            0.49,
            0
        ],
        [
            `prop_cay_chet`,
            24.4,
            150.9,
            0.96,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            31.2,
            150.6,
            0.51,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            33.2,
            151,
            0.52,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_c`,
            35.4,
            151.4,
            0.46,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            39,
            151.3,
            0.49,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            41.8,
            150.9,
            0.5,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            20.6,
            153.4,
            0.51,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_d`,
            25.3,
            153.4,
            0.47,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            29.1,
            152.6,
            0.49,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_b`,
            40.7,
            152.7,
            0.51,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            47.4,
            152.7,
            0.46,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            49.5,
            152.9,
            0.44,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            23.4,
            154.7,
            0.46,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_b`,
            26.8,
            155.5,
            0.47,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            36.6,
            154.5,
            0.5,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            38.9,
            154.9,
            0.45,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_b`,
            42,
            155.1,
            0.47,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_b`,
            44.3,
            154.7,
            0.47,
            0
        ],
        [
            `prop_cay_chet`,
            20.8,
            157.1,
            0.93,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            22.5,
            157.5,
            0.46,
            1
        ],
        [
            `prop_cay_chet`,
            27.1,
            157.3,
            0.85,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            29.5,
            156.8,
            0.51,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            44.9,
            156.7,
            0.49,
            0
        ],
        [
            `prop_cay_chet`,
            48.9,
            156.8,
            0.99,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            30.8,
            159.4,
            0.49,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_b`,
            36.8,
            159,
            0.46,
            0
        ],
        [
            `prop_cay_chet`,
            41.5,
            159.5,
            0.91,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_d`,
            43.4,
            159.2,
            0.48,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            45.5,
            159.3,
            0.45,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_d`,
            241,
            170.6,
            0.5,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_d`,
            249.6,
            170.6,
            0.46,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_c`,
            251.9,
            170.6,
            0.5,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_d`,
            256.1,
            171.4,
            0.51,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_a`,
            260.8,
            170.9,
            0.46,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            265,
            171,
            0.52,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            246.6,
            173.4,
            0.45,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_d`,
            255.3,
            173.4,
            0.45,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_c`,
            256.9,
            173.1,
            0.45,
            1
        ],
        [
            `prop_cay_chet`,
            259.3,
            172.5,
            1.03,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            261.9,
            173.2,
            0.51,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            267.7,
            172.8,
            0.45,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            247.4,
            174.9,
            0.51,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            249.5,
            174.7,
            0.46,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            254,
            174.8,
            0.51,
            1
        ],
        [
            `prop_cay_chet`,
            261.1,
            175.2,
            1.02,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_d`,
            262.7,
            174.7,
            0.46,
            0
        ],
        [
            `prop_cay_chet`,
            264.6,
            174.9,
            0.98,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            267.3,
            175.1,
            0.44,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            269.8,
            175.1,
            0.49,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_a`,
            243.4,
            176.8,
            0.45,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            245.6,
            177,
            0.45,
            1
        ],
        [
            `prop_cay_chet`,
            253.1,
            177.3,
            1.04,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_d`,
            257.6,
            176.8,
            0.45,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            265.8,
            176.9,
            0.48,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            247.8,
            179.1,
            0.5,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_c`,
            251.9,
            179.4,
            0.46,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_a`,
            254.1,
            178.7,
            0.5,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            256.4,
            178.8,
            0.46,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            258.2,
            178.9,
            0.51,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_c`,
            260.7,
            179.2,
            0.49,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            264.5,
            179,
            0.49,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_b`,
            267.2,
            178.8,
            0.47,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            268.7,
            179.3,
            0.45,
            0
        ],
        [
            `prop_cay_chet`,
            243.5,
            180.8,
            0.97,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_b`,
            246.5,
            180.8,
            0.49,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_a`,
            250.1,
            180.9,
            0.5,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            261.2,
            181.3,
            0.47,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            265.9,
            181.3,
            0.48,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            240.6,
            182.6,
            0.47,
            1
        ],
        [
            `prop_cay_chet`,
            242.7,
            183.1,
            0.86,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            247,
            182.9,
            0.49,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            251.9,
            183,
            0.47,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            253.9,
            182.8,
            0.44,
            0
        ],
        [
            `prop_cay_chet`,
            255.8,
            183.3,
            1.01,
            1
        ],
        [
            `prop_cay_chet`,
            260.9,
            183.2,
            0.99,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            267.3,
            182.9,
            0.47,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_c`,
            269.5,
            182.7,
            0.44,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            242.3,
            184.8,
            0.48,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_a`,
            244.3,
            185.4,
            0.5,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_a`,
            245.8,
            185.5,
            0.48,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            250.6,
            184.9,
            0.45,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            254.7,
            184.6,
            0.52,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_a`,
            263.3,
            185.1,
            0.49,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_c`,
            268.7,
            185.2,
            0.47,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_c`,
            240.9,
            186.6,
            0.48,
            1
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_a`,
            243.4,
            187.3,
            0.45,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            247.2,
            187.4,
            0.46,
            1
        ],
        [
            `prop_cay_chet`,
            251.5,
            187,
            1.02,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_d`,
            256.1,
            187,
            0.46,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_b`,
            265.3,
            186.7,
            0.49,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_c`,
            269.5,
            186.6,
            0.49,
            0
        ],
        [
            `prop_cay_chet`,
            244,
            189,
            1.04,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_c`,
            253.3,
            188.8,
            0.47,
            0
        ],
        [
            `prop_phu_hac_thuy_re_duoc_c`,
            255.3,
            188.6,
            0.52,
            0
        ],
        [
            `prop_phu_hac_thuy_cay_chet_reu_b`,
            257.7,
            188.7,
            0.49,
            0
        ],
        [
            `prop_cay_chet`,
            259.9,
            189.2,
            0.97,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_a`,
            262.2,
            188.7,
            0.46,
            1
        ],
        [
            `prop_phu_hac_thuy_re_duoc_b`,
            266.1,
            189.2,
            0.47,
            1
        ],
        [
            `prop_cay_chet`,
            268.5,
            188.5,
            1.02,
            1
        ]
    ]);
    let Ct = bt([
        [
            `prop_phu_ben_thuong_luoi_day_c`,
            33.6,
            20.9,
            0.49,
            1
        ],
        [
            `prop_phu_ben_thuong_luoi_day_d`,
            35,
            20.9,
            0.46,
            1
        ],
        [
            `prop_phu_ben_thuong_hang_a`,
            83.6,
            5.8,
            0.45,
            1
        ],
        [
            `prop_phu_ben_thuong_hang_b`,
            85,
            5.8,
            0.48,
            0
        ],
        [
            `prop_phu_ben_thuong_hang_d`,
            3.6,
            55.9,
            0.5,
            0
        ],
        [
            `prop_phu_ben_thuong_hang_a`,
            10.6,
            55.9,
            0.49,
            0
        ],
        [
            `prop_phu_ben_thuong_luoi_day_c`,
            12,
            55.9,
            0.46,
            0
        ],
        [
            `prop_phu_ben_thuong_hang_b`,
            78.6,
            53.9,
            0.48,
            1
        ],
        [
            `prop_phu_ben_thuong_luoi_day_c`,
            66.6,
            12.8,
            0.48,
            0
        ],
        [
            `prop_phu_ben_thuong_hang_b`,
            77.6,
            25.9,
            0.47,
            1
        ],
        [
            `prop_phu_ben_thuong_hang_d`,
            83.6,
            25.9,
            0.46,
            0
        ],
        [
            `prop_phu_ben_thuong_luoi_day_a`,
            26.6,
            19.9,
            0.45,
            0
        ],
        [
            `prop_phu_ben_thuong_hang_b`,
            28,
            19.9,
            0.47,
            0
        ],
        [
            `prop_phu_ben_thuong_luoi_day_c`,
            10.6,
            38.9,
            0.48,
            0
        ],
        [
            `prop_phu_ben_thuong_luoi_day_a`,
            15.6,
            6.8,
            0.48,
            1
        ],
        [
            `prop_phu_ben_thuong_luoi_day_c`,
            20.6,
            6.8,
            0.49,
            0
        ],
        [
            `prop_phu_ben_thuong_hang_c`,
            62.6,
            6.8,
            0.49,
            1
        ],
        [
            `prop_phu_ben_thuong_luoi_day_c`,
            67.6,
            6.8,
            0.45,
            0
        ],
        [
            `prop_phu_ben_thuong_hang_a`,
            80.6,
            13.8,
            0.49,
            0
        ],
        [
            `prop_phu_ben_thuong_luoi_day_d`,
            85.6,
            13.8,
            0.49,
            1
        ],
        [
            `prop_phu_ben_thuong_hang_b`,
            59.6,
            43.9,
            0.45,
            1
        ],
        [
            `prop_phu_ben_thuong_luoi_day_a`,
            65.6,
            43.9,
            0.45,
            0
        ],
        [
            `prop_phu_ben_thuong_hang_d`,
            9.6,
            5.8,
            0.5,
            0
        ],
        [
            `prop_phu_ben_thuong_hang_b`,
            26.6,
            5.8,
            0.45,
            0
        ],
        [
            `prop_phu_ben_thuong_luoi_day_a`,
            73.6,
            5.8,
            0.45,
            0
        ],
        [
            `prop_phu_ben_thuong_hang_d`,
            80.6,
            5.8,
            0.49,
            1
        ],
        [
            `prop_phu_ben_thuong_hang_c`,
            74.6,
            12.8,
            0.5,
            0
        ],
        [
            `prop_phu_ben_thuong_luoi_day_d`,
            87.6,
            24.9,
            0.48,
            0
        ],
        [
            `prop_phu_ben_thuong_hang_c`,
            3.6,
            45.9,
            0.46,
            1
        ],
        [
            `prop_phu_ben_thuong_hang_a`,
            11.6,
            45.9,
            0.49,
            0
        ],
        [
            `prop_phu_ben_thuong_hang_c`,
            28.6,
            46.9,
            0.49,
            0
        ],
        [
            `prop_phu_ben_thuong_hang_a`,
            33.6,
            46.9,
            0.46,
            1
        ],
        [
            `prop_phu_ben_thuong_hang_b`,
            38.6,
            46.9,
            0.46,
            1
        ],
        [
            `prop_phu_ben_thuong_luoi_day_a`,
            44.6,
            46.9,
            0.48,
            1
        ]
    ]);
    let wt = {
        zone_bac_linh: bt([
            [
                `prop_phu_bac_linh_cay_bang_a`,
                24.4,
                84.6,
                0.47,
                1
            ],
            [
                `prop_gpt_thong_tuyet_non_a`,
                24.4,
                83.1,
                0.72,
                1
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                23.8,
                85.6,
                0.35,
                1
            ],
            [
                `prop_phu_bac_linh_cay_bang_b`,
                62.8,
                118.7,
                0.42,
                1
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                62.7,
                119.7,
                0.35,
                0
            ],
            [
                `prop_phu_bac_linh_tung_tuyet_a`,
                170.7,
                132.6,
                0.46,
                1
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                169.9,
                131.8,
                0.3,
                1
            ],
            [
                `nen_bl_mang_co_lo`,
                172.2,
                133.1,
                0.34,
                0
            ],
            [
                `prop_phu_bac_linh_cay_bang_c`,
                34.6,
                58.7,
                0.45,
                1
            ],
            [
                `prop_gpt_thong_tuyet_non_b`,
                33.7,
                57.8,
                0.81,
                0
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                36.4,
                58.6,
                0.33,
                1
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                33.3,
                58.8,
                0.38,
                1
            ],
            [
                `prop_phu_bac_linh_tung_tuyet_c`,
                170,
                114.5,
                0.5,
                0
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                171.8,
                114.3,
                0.34,
                1
            ],
            [
                `nen_bl_mang_co_lo`,
                169.1,
                113.4,
                0.33,
                0
            ],
            [
                `nen_bl_mang_co_lo`,
                172.8,
                114.9,
                0.31,
                0
            ],
            [
                `prop_phu_bac_linh_hong_mai_b`,
                88.5,
                50.3,
                0.5,
                1
            ],
            [
                `nen_bl_mang_co_lo`,
                90.1,
                50.9,
                0.3,
                1
            ],
            [
                `prop_phu_bac_linh_hong_mai_c`,
                56.5,
                88.3,
                0.44,
                1
            ],
            [
                `nen_bl_mang_co_lo`,
                55.3,
                88.4,
                0.28,
                1
            ],
            [
                `prop_phu_bac_linh_cay_bang_b`,
                154.5,
                84.5,
                0.46,
                0
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                152.8,
                84.4,
                0.34,
                0
            ],
            [
                `prop_phu_bac_linh_cay_bang_a`,
                66.1,
                26.4,
                0.47,
                1
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                65.1,
                26.2,
                0.35,
                0
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                68.4,
                26.7,
                0.36,
                1
            ],
            [
                `prop_phu_bac_linh_cay_bang_c`,
                24.4,
                126.5,
                0.43,
                0
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                25.2,
                127.2,
                0.35,
                1
            ],
            [
                `prop_phu_bac_linh_cay_bang_c`,
                168.5,
                32.5,
                0.49,
                1
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                169.1,
                31.3,
                0.33,
                0
            ],
            [
                `prop_phu_bac_linh_tung_tuyet_b`,
                102.4,
                66.4,
                0.42,
                0
            ],
            [
                `prop_gpt_thong_tuyet_non_a`,
                102.9,
                67.9,
                0.8,
                1
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                103.5,
                67.1,
                0.34,
                0
            ],
            [
                `nen_bl_mang_co_lo`,
                101.6,
                67.9,
                0.3,
                1
            ],
            [
                `prop_phu_bac_linh_tung_tuyet_b`,
                42.2,
                84.3,
                0.44,
                1
            ],
            [
                `prop_gpt_thong_tuyet_non_a`,
                41.3,
                85.4,
                0.83,
                0
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                43.7,
                86.2,
                0.35,
                1
            ],
            [
                `prop_phu_bac_linh_hong_mai_c`,
                122.8,
                100.5,
                0.45,
                1
            ],
            [
                `nen_bl_mang_co_lo`,
                121.7,
                100.4,
                0.3,
                1
            ],
            [
                `prop_phu_bac_linh_cay_bang_b`,
                12.5,
                24.4,
                0.5,
                0
            ],
            [
                `prop_gpt_thong_tuyet_non_b`,
                11.6,
                25.3,
                0.71,
                0
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                13.9,
                24.8,
                0.37,
                0
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                10.8,
                24.7,
                0.38,
                0
            ],
            [
                `prop_phu_bac_linh_hong_mai_a`,
                100.6,
                24.6,
                0.45,
                1
            ],
            [
                `nen_bl_mang_co_lo`,
                100.9,
                23.3,
                0.29,
                0
            ],
            [
                `prop_phu_bac_linh_tung_tuyet_b`,
                74,
                128.6,
                0.47,
                1
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                74.3,
                126.9,
                0.29,
                1
            ],
            [
                `nen_bl_mang_co_lo`,
                75.2,
                129,
                0.31,
                1
            ],
            [
                `prop_phu_bac_linh_cay_bang_c`,
                28.6,
                16.4,
                0.45,
                1
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                27.6,
                16.7,
                0.32,
                1
            ],
            [
                `prop_phu_bac_linh_hong_mai_b`,
                12.5,
                124.5,
                0.5,
                1
            ],
            [
                `nen_bl_mang_co_lo`,
                10.7,
                124.8,
                0.31,
                0
            ],
            [
                `prop_phu_bac_linh_tung_tuyet_a`,
                46.3,
                114.4,
                0.47,
                1
            ],
            [
                `prop_gpt_thong_tuyet_non_a`,
                47,
                116.1,
                0.78,
                1
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                48.1,
                115.4,
                0.32,
                1
            ],
            [
                `nen_bl_mang_co_lo`,
                48.8,
                113.8,
                0.28,
                1
            ],
            [
                `prop_phu_bac_linh_cay_bang_c`,
                22.2,
                42.3,
                0.49,
                0
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                23.2,
                41.9,
                0.38,
                0
            ],
            [
                `prop_phu_bac_linh_tung_tuyet_c`,
                86.6,
                66.5,
                0.47,
                1
            ],
            [
                `prop_gpt_thong_tuyet_non_a`,
                84.9,
                66.4,
                0.79,
                1
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                86.4,
                68.4,
                0.32,
                0
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                88.4,
                66.1,
                0.33,
                1
            ],
            [
                `nen_bl_mang_co_lo`,
                87.7,
                65.2,
                0.31,
                0
            ],
            [
                `prop_phu_bac_linh_tung_tuyet_c`,
                88.8,
                108.6,
                0.42,
                0
            ],
            [
                `prop_gpt_thong_tuyet_non_b`,
                90.4,
                108.8,
                0.75,
                0
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                88.1,
                107.5,
                0.29,
                1
            ],
            [
                `nen_bl_mang_co_lo`,
                89.5,
                107.3,
                0.31,
                1
            ],
            [
                `prop_phu_bac_linh_tung_tuyet_c`,
                82.5,
                22.1,
                0.44,
                0
            ],
            [
                `prop_gpt_thong_tuyet_non_b`,
                81.2,
                22.9,
                0.73,
                1
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                81.4,
                20.7,
                0.36,
                0
            ],
            [
                `nen_bl_bui_kho_tuyet`,
                84,
                22.8,
                0.32,
                0
            ],
            [
                `prop_phu_bac_linh_hong_mai_b`,
                164.6,
                18.4,
                0.45,
                1
            ],
            [
                `nen_bl_mang_co_lo`,
                163.3,
                19.7,
                0.32,
                1
            ],
            [
                `nen_bl_mang_co_lo`,
                165.3,
                17.3,
                0.31,
                0
            ],
            [
                `prop_phu_bac_linh_hong_mai_c`,
                138.4,
                136.5,
                0.48,
                0
            ],
            [
                `nen_bl_mang_co_lo`,
                137.7,
                135.7,
                0.36,
                1
            ]
        ]),
        zone_hac_thuy: [
            ...xt,
            ...St
        ],
        zone_mach_sau: bt([
            [
                `prop_phu_mach_sau_lan_hang_d`,
                41.5,
                40.2,
                0.46,
                0
            ],
            [
                `prop_phu_mach_sau_lan_hang_c`,
                40.6,
                41.5,
                0.49,
                0
            ],
            [
                `prop_phu_mach_sau_soi_den`,
                41.8,
                41.2,
                0.38,
                0
            ],
            [
                `prop_phu_mach_sau_lan_hang_c`,
                88.1,
                90.9,
                0.47,
                1
            ],
            [
                `prop_phu_mach_sau_lan_hang_d`,
                88.7,
                91.7,
                0.51,
                1
            ],
            [
                `prop_phu_mach_sau_lan_hang_d`,
                47.4,
                64.9,
                0.51,
                1
            ],
            [
                `prop_phu_mach_sau_lan_hang_c`,
                45.3,
                64.1,
                0.48,
                0
            ],
            [
                `prop_phu_mach_sau_lan_hang_b`,
                46.7,
                64,
                0.52,
                1
            ],
            [
                `prop_phu_mach_sau_soi_den`,
                45.1,
                65.3,
                0.38,
                0
            ],
            [
                `prop_phu_mach_sau_lan_hang_c`,
                105.6,
                88.9,
                0.47,
                1
            ],
            [
                `prop_phu_mach_sau_lan_hang_d`,
                104.8,
                87.5,
                0.51,
                0
            ],
            [
                `prop_phu_mach_sau_mang_da`,
                92.6,
                80.4,
                0.42,
                0
            ],
            [
                `prop_phu_mach_sau_soi_den`,
                91,
                80.7,
                0.4,
                0
            ],
            [
                `prop_phu_mach_sau_nam_sang_b`,
                22.8,
                28,
                0.5,
                1
            ],
            [
                `prop_phu_mach_sau_nam_sang_d`,
                22.7,
                29.4,
                0.54,
                0
            ],
            [
                `prop_phu_mach_sau_nam_sang_a`,
                21.4,
                28.8,
                0.57,
                1
            ],
            [
                `prop_phu_mach_sau_lan_hang_a`,
                77.4,
                43.3,
                0.49,
                0
            ],
            [
                `prop_phu_mach_sau_lan_hang_c`,
                76,
                43.4,
                0.48,
                1
            ],
            [
                `prop_phu_mach_sau_lan_hang_b`,
                75.9,
                41.7,
                0.51,
                1
            ],
            [
                `prop_phu_mach_sau_soi_den`,
                77,
                41.9,
                0.37,
                0
            ],
            [
                `prop_phu_mach_sau_nam_sang_c`,
                90.8,
                116,
                0.55,
                1
            ],
            [
                `prop_phu_mach_sau_nam_sang_a`,
                91.8,
                116.1,
                0.52,
                1
            ],
            [
                `prop_phu_mach_sau_lan_hang_b`,
                58,
                24.6,
                0.47,
                0
            ],
            [
                `prop_phu_mach_sau_lan_hang_c`,
                55.4,
                24.6,
                0.48,
                1
            ],
            [
                `prop_phu_mach_sau_lan_hang_d`,
                56.2,
                25.6,
                0.48,
                1
            ],
            [
                `prop_phu_mach_sau_soi_den`,
                56.4,
                23.9,
                0.39,
                0
            ],
            [
                `prop_phu_mach_sau_tinh_the`,
                34.5,
                48.6,
                0.45,
                1
            ],
            [
                `prop_phu_mach_sau_da_vun`,
                35.8,
                48.2,
                0.4,
                1
            ],
            [
                `prop_phu_mach_sau_lan_hang_a`,
                33.6,
                47.7,
                0.46,
                0
            ],
            [
                `prop_phu_mach_sau_lan_hang_b`,
                36.3,
                49.1,
                0.48,
                1
            ],
            [
                `prop_phu_mach_sau_lan_hang_b`,
                45.5,
                51.2,
                0.46,
                0
            ],
            [
                `prop_phu_mach_sau_lan_hang_c`,
                47.3,
                50.3,
                0.48,
                0
            ],
            [
                `prop_phu_mach_sau_soi_den`,
                45.2,
                50.2,
                0.36,
                0
            ],
            [
                `prop_phu_mach_sau_lan_hang_d`,
                114,
                88.3,
                0.45,
                0
            ],
            [
                `prop_phu_mach_sau_lan_hang_a`,
                114.8,
                89.7,
                0.5,
                1
            ],
            [
                `prop_phu_mach_sau_lan_hang_c`,
                115.7,
                87.8,
                0.52,
                0
            ],
            [
                `prop_phu_mach_sau_soi_den`,
                113,
                89.2,
                0.38,
                0
            ],
            [
                `prop_phu_mach_sau_nam_sang_d`,
                111.8,
                12.9,
                0.52,
                0
            ],
            [
                `prop_phu_mach_sau_nam_sang_a`,
                110,
                13.1,
                0.53,
                0
            ],
            [
                `prop_phu_mach_sau_nam_sang_d`,
                86.5,
                65.9,
                0.54,
                1
            ],
            [
                `prop_phu_mach_sau_nam_sang_c`,
                87.6,
                66.2,
                0.52,
                0
            ],
            [
                `prop_phu_mach_sau_duong_xi_bac_b`,
                84.8,
                66.7,
                0.47,
                0
            ],
            [
                `prop_phu_mach_sau_tinh_the`,
                116.6,
                20.3,
                0.43,
                0
            ],
            [
                `prop_phu_mach_sau_da_vun`,
                117,
                21.9,
                0.4,
                0
            ],
            [
                `prop_phu_mach_sau_lan_hang_b`,
                117.4,
                20.9,
                0.48,
                0
            ],
            [
                `prop_phu_mach_sau_lan_hang_a`,
                103.9,
                114.8,
                0.48,
                0
            ],
            [
                `prop_phu_mach_sau_lan_hang_b`,
                105.4,
                114,
                0.52,
                0
            ],
            [
                `prop_phu_mach_sau_soi_den`,
                105.4,
                115.8,
                0.37,
                0
            ]
        ]),
        zone_vu_linh_ha: bt([
            [
                `prop_phu_vu_linh_ha_duong_xi_to_a`,
                66.3,
                36.6,
                0.44,
                0
            ],
            [
                `prop_phu_vu_linh_ha_da_reu`,
                67.7,
                37.4,
                0.34,
                1
            ],
            [
                `prop_phu_vu_linh_ha_nam_b`,
                65.4,
                37.7,
                0.44,
                0
            ],
            [
                `prop_phu_vu_linh_ha_phong_do_b`,
                80.6,
                38.6,
                0.44,
                0
            ],
            [
                `prop_phu_vu_linh_ha_bui_thu`,
                79,
                39.5,
                0.44,
                1
            ],
            [
                `prop_phu_vu_linh_ha_duong_xi_to_b`,
                82.1,
                39.7,
                0.42,
                0
            ],
            [
                `prop_phu_vu_linh_ha_go_reu_c`,
                72.6,
                55.3,
                0.46,
                0
            ],
            [
                `prop_phu_vu_linh_ha_nam_a`,
                74,
                55.9,
                0.44,
                1
            ],
            [
                `prop_phu_vu_linh_ha_duong_xi_to_c`,
                71.1,
                54.6,
                0.42,
                0
            ],
            [
                `prop_phu_vu_linh_ha_da_reu`,
                90.6,
                50.9,
                0.36,
                0
            ],
            [
                `prop_phu_vu_linh_ha_duong_xi_to_a`,
                89.3,
                50.1,
                0.42,
                1
            ],
            [
                `prop_phu_vu_linh_ha_bui_thu`,
                91.9,
                51.7,
                0.42,
                0
            ]
        ]),
        zone_ben_thuong: Ct
    };
    [
        ...xt,
        ...St
    ];
    let Tt = {
        zone_lang_coc,
        zone_khe_coc,
        zone_vu_linh_ha,
        zone_ta_gia_trai,
        zone_bac_linh,
        zone_hac_thuy,
        zone_ben_thuong: be,
        zone_luc_bien,
        zone_mach_sau,
        zone_mo_cu,
        inst_chien_truong,
        inst_loi_dai: we,
        inst_loi_dai_ba_ba: we,
        inst_loi_dai_bong,
        inst_thap_thi_luyen,
        inst_tru_so_bang,
        inst_tt_dau_bong,
        inst_tt_do_thach,
        inst_tt_giu_den,
        ...st,
        ...lt
    };
    let Et = {};
    for (let [e, t] of Object.entries(wt)){
        let n = Tt[e];
        if (n && t.length) {
            Tt[e] = {
                ...n,
                vatThem: [
                    ...n.vatThem ?? [],
                    ...t
                ]
            };
        }
    }
    for (let [e, t] of Object.entries(dt)){
        let n = Tt[e];
        if (n && t.length) {
            Tt[e] = {
                ...n,
                vatThem: [
                    ...n.vatThem ?? [],
                    ...t
                ]
            };
        }
    }
    let Dt = {
        ...Et,
        ...Tt
    };
    let Ot = {
        inst_dem_trang: `zone_ta_gia_trai`,
        inst_trai_dem_t04: `zone_ta_gia_trai`,
        inst_loan_chien: `inst_chien_truong`,
        inst_dai_hoi_anh_hung: `inst_lau_chan_duong`
    };
    function kt(e) {
        return We(e) ?? e;
    }
    let At = (e)=>Ot[e] ?? kt(e);
    function jt(e) {
        return Dt[At(e)];
    }
    function Mt(e) {
        let t = [];
        if (e.da.kieuMat === `dat` && e.da.matAnh) {
            t.push(e.da.matAnh);
        }
        for (let n of e.vungNen ?? []){
            t.push(n.anh);
        }
        return [
            ...new Set(t)
        ];
    }
    let Nt = new WeakMap;
    function Pt(e) {
        let t = Nt.get(e);
        if (t) {
            return t;
        }
        let n = 0;
        let r = 0;
        let i = 0;
        let a = 0;
        for(let t = 0; t < e.w * e.h * 4; t += 16){
            n += e.d[t];
            r += e.d[t + 1];
            i += e.d[t + 2];
            a++;
        }
        t = [
            n / a || 1,
            r / a || 1,
            i / a || 1
        ];
        Nt.set(e, t);
        return t;
    }
    let Ft = new WeakMap;
    function It(e) {
        let t = Ft.get(e);
        if (t !== undefined) {
            return t;
        }
        let n = 0;
        let r = e.w * e.h;
        for(let t = 0; t < r * 4; t += 16){
            n += e.d[t] * 0.3 + e.d[t + 1] * 0.55 + e.d[t + 2] * 0.15;
        }
        t = n / (r / 4);
        Ft.set(e, t);
        return t;
    }
    let Lt = new WeakMap;
    function Rt(e) {
        let t = Lt.get(e);
        if (t) {
            return t;
        }
        let n = 0;
        let r = 0;
        let i = 0;
        let a = 0;
        for(let t = 0; t < e.w * e.h * 4; t += 16){
            n += e.d[t];
            r += e.d[t + 1];
            i += e.d[t + 2];
            a++;
        }
        t = [
            n / a,
            r / a,
            i / a
        ];
        Lt.set(e, t);
        return t;
    }
    function zt(e, t, n, r, i) {
        let a = t * 64;
        let o = n * 64;
        if (r === 1) {
            let e = a;
            a = o;
            o = -e;
        } else if (r === 2) {
            a = -a;
            o = -o;
        } else if (r === 3) {
            let e = a;
            a = -o;
            o = e;
        }
        let s = (Math.floor(a) % e.w + e.w) % e.w;
        let c = ((Math.floor(o) % e.h + e.h) % e.h * e.w + s) * 4;
        K[i] = e.d[c];
        K[i + 1] = e.d[c + 1];
        K[i + 2] = e.d[c + 2];
    }
    function Bt(e, t, n, r) {
        let i = (Math.floor(t * 64) % e.w + e.w) % e.w;
        let a = ((Math.floor(n * 64) % e.h + e.h) % e.h * e.w + i) * 4;
        return (e.d[a] * 0.3 + e.d[a + 1] * 0.55 + e.d[a + 2] * 0.15 - r) / r;
    }
    let K = new Float32Array(12);
    let q = p();
    let J = p();
    let Y = P();
    let Vt = P();
    let Ht = -0.6;
    let Ut = -0.8;
    let X = {
        r: 0.5,
        g: 0.5,
        b: 0.5,
        a00: 0.5,
        a10: 0.5,
        a01: 0.5,
        a11: 0.5,
        k: 0,
        w: 0,
        p: 32,
        n5: 0.5,
        wx: 0,
        wy: 0
    };
    function Z(e) {
        return e[X.k] * X.a00 + e[X.k + 1] * X.a10 + e[X.k + X.w] * X.a01 + e[X.k + X.w + 1] * X.a11;
    }
    function Wt(e, t) {
        let n = 0;
        let r = 0;
        if (t[X.k] >= 0.5) {
            n += e[X.k] * X.a00;
            r += X.a00;
        }
        if (t[X.k + 1] >= 0.5) {
            n += e[X.k + 1] * X.a10;
            r += X.a10;
        }
        if (t[X.k + X.w] >= 0.5) {
            n += e[X.k + X.w] * X.a01;
            r += X.a01;
        }
        if (t[X.k + X.w + 1] >= 0.5) {
            n += e[X.k + X.w + 1] * X.a11;
            r += X.a11;
        }
        if (r > 0.0001) {
            return n / r;
        }
        for(let n = -1; n <= 2; n++){
            for(let r = -1; r <= 2; r++){
                let i = X.k + n * X.w + r;
                if (i >= 0 && i < t.length && t[i] >= 0.5) {
                    return e[i];
                }
            }
        }
        return 0;
    }
    function Gt(e, t, n, r, i) {
        return (e[t] * (1 - n) + e[t + 1] * n) * (1 - r) + (e[t + i] * (1 - n) + e[t + i + 1] * n) * r;
    }
    function Q(e, t, n, r) {
        X.r += (e - X.r) * r;
        X.g += (t - X.g) * r;
        X.b += (n - X.b) * r;
    }
    function $(e) {
        X.r *= e;
        X.g *= e;
        X.b *= e;
    }
    function Kt(e, t, n, r, i, a) {
        let o = 0.3;
        let s = Math.floor(e / o);
        let c = Math.floor(t / o);
        let d = 0.6 / a;
        for(let a = 0; a <= 1; a++){
            for(let f = -1; f <= 1; f++){
                let p = s + f;
                let m = c + a;
                if (l(p, m, r) >= n) {
                    continue;
                }
                let h = (p + 0.25 + 0.5 * u(p, m, r)) * o;
                let _ = (m + 0.55 + 0.4 * l(m, p, r + 1)) * o;
                let v = e - h;
                let y = t - _;
                if (y > 0.012 || y < -0.2 || v < -0.11 || v > 0.11) {
                    continue;
                }
                let b = 0.1 + 0.07 * u(m, p, r + 2);
                for(let e = 0; e < 4; e++){
                    let t = (e - 1.5) * 0.045 + (l(p * 4 + e, m, r + 3) - 0.5) * 0.03;
                    let n = -b * (e === 1 || e === 2 ? 1 : 0.72);
                    let a = g((v * t + y * n) / (t * t + n * n));
                    let o = v - t * a;
                    let s = y - n * a;
                    if (o * o + s * s < d * d * (1.4 - a * 0.6)) {
                        let e = 0.62 + 0.55 * a;
                        X.r = i[0] * e;
                        X.g = i[1] * e;
                        X.b = i[2] * e;
                        return true;
                    }
                }
            }
        }
        return false;
    }
    let qt = {
        xs: -1,
        h: 0,
        tren: false,
        dt: 0
    };
    function Jt(e, t, n, r, i, a, o, s, c = 0) {
        if (n > 0.05) {
            let r = (1 - Math.exp(-n / 3)) * o;
            let a = 1 + 0.042 * Math.min(n, 10) * o * (0.45 + 0.55 * s);
            let c = 16 * Math.min(1, n / 6) * o * (0.45 + 0.55 * s);
            X.r = X.r * a + c;
            X.g = X.g * a + c * 0.9;
            X.b = X.b * a * (1 - 0.05 * r) + c * 0.45;
            let l = X.r * 0.3 + X.g * 0.55 + X.b * 0.15;
            Q(l * 1.06 + 8, l * 1.03 + 8, l * 0.74, 0.32 * r * s);
            let u = h(0.5, 0.78, d(e / 2.6, t / 2.6, i + 401) * 0.7 + d(e / 0.9, t / 0.9, i + 402) * 0.3) * 0.16 * r * s;
            if (u > 0) {
                Q(X.r * 1.1 + 18, X.g * 1.07 + 12, X.b * 1.02 + 4, u);
            }
        }
        if (r < 1.1) {
            let n = h(1.1, 0.4, r);
            if (n > 0) {
                $(1 - 0.08 * n * o);
            }
            if (r > 0.3 && r < 1 && c < 0.4) {
                let n = 0.3;
                m(e / n, t / n, i + 413, 0.85, 1, J);
                if (l(J.i, J.j, i + 414) < 0.22 * o) {
                    let r = 0.16 + 0.18 * u(J.i, J.j, i + 415);
                    let o = e / n - J.px;
                    let s = t / n - J.py;
                    let c = Math.max(0.001, J.d1);
                    if (c < r) {
                        let e = (o * Ht + s * Ut) / c;
                        let t = (0.72 + 0.25 * l(J.i, J.j, i + 416)) * (0.82 + 0.42 * e * Math.sqrt(c / r)) * (1 - 0.35 * h(0.75, 1, c / r));
                        X.r = a.mat[0] * t * 1.1;
                        X.g = a.mat[1] * t * 1.08;
                        X.b = a.mat[2] * t * 1.04;
                    } else {
                        if (c < r * 1.5 && o * 0.6 + s * 0.8 > 0) {
                            $(0.8);
                        }
                    }
                }
            }
            Xt(e, t, r, i, a, o, c);
        }
    }
    let Yt = {
        k: _.vien
    };
    function Xt(e, t, n, r, i, a, o = 0) {
        let s = 0.32 + 0.4 * d(e * 1.1, t * 1.1, r + 411);
        if (n >= s) {
            return;
        }
        let c = i.reu?.mau ?? [
            86,
            112,
            52
        ];
        let u = Math.max(0, n) / s;
        let f = Math.floor(e * 26);
        let p = l(f, Math.floor((t + 0.09 * l(f, 1, r + 419)) * 6), r + 418);
        let m = (0.7 + 0.55 * p) * (1.12 - 0.3 * u);
        let g = (1 - h(0.62, 1, u + (p - 0.5) * 0.45)) * 0.92 * a * (1 - o);
        if (g > 0) {
            Q(c[0] * 1.2 * m, c[1] * 1.3 * m, c[2] * 1.02 * m, g);
        }
        let _ = (1 - h(0.02, 0.05 + 0.05 * d(e * 3, t * 3, r + 417), n)) * (0.45 + 0.55 * p);
        if (_ > 0) {
            Q(i.vien[0] * 1.1 + c[0] * 0.25, i.vien[1] * 1.08 + c[1] * 0.3, i.vien[2] * 0.92 + c[2] * 0.1, Math.min(1, _ * (0.8 + Yt.k) * a));
        }
    }
    function Zt(e, t, n, r, i, a) {
        let o = h(2.5, 7, n) * a;
        if (o > 0) {
            let e = g(t / n) ** 1.6;
            X.r *= 1 - 0.42 * e * o;
            X.g *= 1 - 0.38 * e * o;
            X.b *= 1 - 0.26 * e * o;
        }
        let s = (0.16 + 0.42 * d(e * 2.1, n, r + 421)) * Math.min(1, 0.4 + n / 4);
        let c = i.reu?.mau ?? [
            86,
            112,
            52
        ];
        let f = s * (0.5 + 0.8 * l(Math.floor(e * 18), 7, r + 422));
        if (t < f) {
            let n = (0.7 + 0.45 * l(Math.floor(e * 18), Math.floor(t * 20), r + 423)) * (1 - 0.35 * t / Math.max(0.05, f));
            Q(c[0] * 1.2 * n, c[1] * 1.22 * n, c[2] * 1.05 * n, 0.9 * a);
        } else {
            if (t < f + 0.1) {
                $(1 - 0.38 * a * (1 - (t - f) / 0.1));
            }
        }
        let p = Math.floor(e * 7);
        if (l(p, 3, r + 424) < 0.16) {
            let n = (p + 0.3 + 0.4 * u(p, 4, r + 425)) / 7 + Math.sin(t * 5 + p) * 0.02;
            let i = 0.4 + 1 * l(p, 5, r + 426);
            if (Math.abs(e - n) < 0.022 * (1 - t / i) + 0.008 && t < i) {
                Q(64, 48, 34, 0.85 * a);
            }
        }
    }
    function Qt(e, t, n, r) {
        let i = e * r;
        let a = t > 1.2 ? h(1.2, 6.5, t) * r * (1 - h(0, 1.1, n)) ** 2 : 0;
        if (!(i <= 0.002 && a <= 0.002)) {
            X.r *= 1 - 0.32 * i - 0.2 * a;
            X.g *= 1 - 0.27 * i - 0.19 * a;
            X.b *= 1 - 0.15 * i - 0.16 * a;
            Q(88, 100, 112, 0.07 * i);
        }
    }
    function $t(e) {
        X.r *= 1 - e;
        X.g *= 1 - e * 0.93;
        X.b *= 1 - e * 0.72;
    }
    let en = new WeakMap;
    function tn(e, t, n, r, i, a, o, s = new Uint8ClampedArray(Math.round(a * o) ** 2 * 4), c = 0, f = Math.round(a * o)) {
        let p = Math.round(a * o);
        let v = en.get(n);
        if (!v) {
            v = [
                n.da,
                n.the ? {
                    ...n.da,
                    ...n.the
                } : n.da
            ];
            en.set(n, v);
        }
        let [y, b, x] = n.tong;
        let e_seed = e.seed;
        let C = e.W;
        let w = e.W1;
        X.w = C;
        X.p = o;
        let T = It(t.da);
        let E = n.dat?.soi ?? 0.25;
        let D = n.dat?.soiMau ?? n.da.mat;
        let O = n.dat?.mang ?? 0.5;
        let k = n.dat?.co ?? 0;
        let A = n.dat?.coMau ?? n.da.co ?? [
            170,
            140,
            80
        ];
        let j = n.da.lo ?? 0.6;
        let ee = 0.51 + (0.5 - (n.dat?.tiB ?? 0.5)) * 0.4;
        let te = n.dat?.phang ?? 0;
        let ne = e.gX ? n.dat?.song ?? 0 : 0;
        let N = n.dat?.songMau ?? [
            0.86,
            0.9,
            1
        ];
        let P = n.dat?.gon ?? 0;
        let re = n.dat?.lap ?? 0;
        let F = n.dat?.uot;
        let ie = Rt(t.nenA);
        let ae = Rt(t.nenB);
        let I = n.da.tuyet ?? 0;
        let e_tang = e.tang;
        let R = n.caoDo?.mat ?? 1;
        let oe = n.caoDo?.chan ?? 1;
        let se = n.caoDo?.thap?.nuoc ?? _.nuoc;
        Yt.k = n.caoDo?.thap?.vien ?? _.vien;
        let e_nuoc = e.nuoc;
        let e_kNuoc = e.kNuoc;
        let e_rung = e.rung;
        let e_kRung = e.kRung;
        let e_san = e.san;
        let e_ruong = e.ruong;
        let n_nuoc = n.nuoc;
        let n_rung = n.rung;
        let n_san = n.san;
        let n_ruong = n.ruong;
        let ve = n.dat?.cong ?? 0;
        let ye = n.dat?.diu ?? 0;
        let be = ye ? (()=>{
            let e = Pt(t.nenA);
            let n = Pt(t.nenB);
            return [
                (e[0] + n[0]) / 2,
                (e[1] + n[1]) / 2,
                (e[2] + n[2]) / 2
            ];
        })() : [
            0,
            0,
            0
        ];
        let xe = (n.vungNen ?? []).map((n)=>{
            if (e.vn?.length) {
                return t.them?.[n.anh];
            }
        });
        let z = n.da.kieuMat === `dat` ? t.them?.[n.da.matAnh ?? ``] ?? t.nenA : null;
        gn.anh = z;
        gn.tb = z ? Pt(z) : gn.tb;
        let Se = n.ray && e.ray?.length ? rn(e, r, i, a) : null;
        let B = null;
        if (n.loi.vet) {
            B = [];
            for (let t of e.duong){
                if (!(t.rong < n.loi.vet.rong)) {
                    for(let e = 1; e < t.diem.length; e++){
                        let [n, o] = t.diem[e - 1];
                        let [s, c] = t.diem[e];
                        if (!(Math.max(n, s) < r - 3 || Math.min(n, s) > r + a + 3 || Math.max(o, c) < i - 3 || Math.min(o, c) > i + a + 3)) {
                            B.push(n, o, s, c, t.rong);
                        }
                    }
                }
            }
            if (!B.length) {
                B = null;
            }
        }
        for(let a = c; a < Math.min(p, f); a++){
            let c = i + (a + 0.5) / o;
            for(let i = 0; i < p; i++){
                let f = r + (i + 0.5) / o;
                let _ = Math.min(e.W - 1.001, Math.max(0, f * 4 - 0.5));
                let z = Math.min(e.H - 1.001, Math.max(0, c * 4 - 0.5));
                let Ce = _ | 0;
                let we = z | 0;
                let Te = _ - Ce;
                let V = z - we;
                X.k = we * C + Ce;
                X.a00 = (1 - Te) * (1 - V);
                X.a10 = Te * (1 - V);
                X.a01 = (1 - Te) * V;
                X.a11 = Te * V;
                let Ee = Math.min(e.W1 - 1.001, Math.max(0, f - 0.5));
                let De = Math.min(e.H1 - 1.001, Math.max(0, c - 0.5));
                let Oe = Ee | 0;
                let ke = De | 0;
                let H = Ee - Oe;
                let U = De - ke;
                let W = ke * w + Oe;
                let Ae = (e.n1[W] * (1 - H) + e.n1[W + 1] * H) * (1 - U) + (e.n1[W + w] * (1 - H) + e.n1[W + w + 1] * H) * U;
                let je = (e.n2[W] * (1 - H) + e.n2[W + 1] * H) * (1 - U) + (e.n2[W + w] * (1 - H) + e.n2[W + w + 1] * H) * U;
                let G = Z(e.da);
                let Me = (e.n3[W] * (1 - H) + e.n3[W + 1] * H) * (1 - U) + (e.n3[W + w] * (1 - H) + e.n3[W + w + 1] * H) * U;
                let Ne = (e.n4[W] * (1 - H) + e.n4[W + 1] * H) * (1 - U) + (e.n4[W + w] * (1 - H) + e.n4[W + w + 1] * H) * U;
                X.n5 = (e.n5[W] * (1 - H) + e.n5[W + 1] * H) * (1 - U) + (e.n5[W + w] * (1 - H) + e.n5[W + w + 1] * H) * U;
                let Pe = ve ? f + (Ne - 0.5) * 2 * ve + (Me - 0.5) * 1.4 * ve : f;
                let Fe = ve ? c + (X.n5 - 0.5) * 2.4 * ve + (Ne - 0.5) * 1.2 * ve : c;
                X.wx = Pe;
                X.wy = Fe;
                zt(t.nenA, Pe, Fe, 0, 0);
                zt(t.nenB, Pe + 3.7, Fe + 5.3, 1, 3);
                let Ie = h(ee - 0.09, ee + 0.09, Ae);
                X.r = K[0] * (1 - Ie) + K[3] * Ie;
                X.g = K[1] * (1 - Ie) + K[4] * Ie;
                X.b = K[2] * (1 - Ie) + K[5] * Ie;
                if (te > 0) {
                    Q(ie[0] * (1 - Ie) + ae[0] * Ie, ie[1] * (1 - Ie) + ae[1] * Ie, ie[2] * (1 - Ie) + ae[2] * Ie, te);
                }
                if (ye) {
                    let e = ye * (0.75 + 0.5 * Me);
                    X.r += (be[0] - X.r) * e;
                    X.g += (be[1] - X.g) * e;
                    X.b += (be[2] - X.b) * e;
                }
                for(let t = 0; t < xe.length; t++){
                    let r = xe[t];
                    if (!r) {
                        continue;
                    }
                    let i = Z(e.vn[t]);
                    if (i < 0.01) {
                        continue;
                    }
                    zt(r, Pe + 1.9 * t, Fe + 2.7 * t, t % 2 ? 3 : 0, 9);
                    let a = n.vungNen[t].nhan;
                    Q(K[9] * (a ? a[0] : 1), K[10] * (a ? a[1] : 1), K[11] * (a ? a[2] : 1), i);
                }
                $((0.9 + 0.2 * je) * (1 + (Me - 0.5) * 0.3 * O));
                if (ne > 0 && G < 0.6) {
                    let t = -(Gt(e.gX, W, H, U, w) * Ht + Gt(e.gY, W, H, U, w) * Ut) * 2.4;
                    $(1 + ne * g(t, -0.6, 0.6));
                    if (t < 0) {
                        let e = Math.min(1, -t * 3.5) * ne;
                        X.r *= 1 + (N[0] - 1) * e;
                        X.g *= 1 + (N[1] - 1) * e;
                        X.b *= 1 + (N[2] - 1) * e;
                    }
                }
                if (P > 0) {
                    let e = f * 0.82 - c * 0.57;
                    let t = f * 0.57 + c * 0.82;
                    let n = d(e / 3.4, t / 0.24, e_seed + 151);
                    let r = h(0.35, 0.75, d(f / 9, c / 9, e_seed + 152));
                    $(1 + P * 0.1 * (n - 0.5) * r);
                    let i = h(0.6, 0.64, n) * (1 - h(0.66, 0.7, n)) * r;
                    if (i > 0) {
                        let e = i * P * 0.16;
                        X.r *= 1 - e * 1.3;
                        X.g *= 1 - e;
                        X.b *= 1 - e * 0.45;
                    } else {
                        if (n > 0.7 && n < 0.74) {
                            $(1 + 0.05 * P * r);
                        }
                    }
                }
                if (F) {
                    let e = h(1 - F.mat, 1 - F.mat + 0.16, d(f / 4.6, c / 4.6, e_seed + 153) * 0.75 + d(f / 1.4, c / 1.4, e_seed + 154) * 0.25);
                    if (e > 0) {
                        X.r *= 1 + (F.mau[0] / 255 - 1) * e;
                        X.g *= 1 + (F.mau[1] / 255 - 1) * e;
                        X.b *= 1 + (F.mau[2] / 255 - 1) * e;
                        let t = h(0.66, 0.84, d(f / 1.8, c / 0.45, e_seed + 155)) * h(0.6, 1, e) * 0.1;
                        if (t > 0) {
                            Q(150, 162, 156, t);
                        }
                    }
                }
                let Le = Z(e.loi);
                if (Le > 0.01) {
                    let e = h(0.15, 0.75, Le + (d(f * 2.2, c * 2.2, e_seed + 303) - 0.5) * 0.55) * n.loi.dam;
                    zt(t.duong, f + 1.3, c + 2.1, 0, 6);
                    Q(K[6] * 1.06, K[7] * 1.04, K[8], e);
                    if (B && Le > 0.25) {
                        nn(f, c, B, n.loi.vet.dam * h(0.25, 0.7, Le), e_seed);
                    }
                }
                let Re = G < 0.5 ? Z(e.kDa) : 0;
                let ze = G < 0.5 ? Z(e.len) : 0;
                if (G < 0.5) {
                    let e = E * h(0.4, 0.78, Me * 0.5 + Ne * 0.5) * (1 - Le * 0.6);
                    if (e > 0.02) {
                        let t = 0.42;
                        m(f / t, c / t, e_seed + 71, 0.85, 0.8, q);
                        if (l(q.i, q.j, e_seed + 72) < e) {
                            let e = 0.14 + 0.26 * u(q.i, q.j, e_seed + 73);
                            let n = f / t - q.px;
                            let r = (c / t - q.py) / 0.8;
                            let i = Math.max(0.001, q.d1);
                            if (q.d1 < e) {
                                let t = (n * Ht + r * Ut) / i;
                                let a = i / e;
                                let o = l(q.i, q.j, e_seed + 74);
                                let s = (0.62 + 0.3 * o) * (0.86 + 0.38 * t * Math.sqrt(a)) * (1 - 0.4 * h(0.72, 1, a));
                                X.r = D[0] * (0.9 + 0.2 * o) * s;
                                X.g = D[1] * s;
                                X.b = D[2] * (1.1 - 0.2 * o) * s;
                            } else {
                                if (q.d1 < e * 1.45 && n * 0.6 + r * 0.8 > 0) {
                                    $(1 - 0.32 * (1 - h(e, e * 1.45, q.d1)));
                                }
                            }
                        }
                    }
                    if (k > 0 && Le < 0.4) {
                        let e = k * h(0.5, 0.8, d(f / 5, c / 5, e_seed + 68)) * (1 - Le * 2);
                        if (e > 0.01) {
                            Kt(f, c, e, e_seed + 69, A, o);
                        }
                    }
                }
                if (e_san && n_san) {
                    let n = Z(e_san);
                    let r = e.kSan ? Z(e.kSan) : n > 0.5 ? 1 : -1;
                    if (n > 0.02 || r > -0.6) {
                        let i = n_san.o;
                        m(f / i, c / (i * 0.82), e_seed + 111, 0.8, 1, q);
                        let a;
                        let o = 0;
                        if (e.kSan) {
                            let t = M(e, e.kSan, q.px * i, q.py * i * 0.82);
                            let n = 0.5 + 1.6 * d(q.px * i / 5, q.py * i / 5, e_seed + 118);
                            let r = t > 0.05 && (t > n || l(q.i, q.j, e_seed + 117) < 0.25 + t / n * 0.75);
                            let s = Math.min(1, Math.max(G, e_nuoc ? Z(e_nuoc) : 0, e_rung ? Z(e_rung) : 0) * 2);
                            a = r ? 1 - s : 0;
                            o = 1 - h(0, n + 0.6, t);
                        } else {
                            a = h(0.3, 0.62, n + (d(f * 1.8, c * 1.8, e_seed + 115) - 0.5) * 0.35);
                        }
                        if (a > 0) {
                            let e = (q.d2 - q.d1) * i;
                            let r = l(q.i, q.j, e_seed + 112);
                            let s = f / i - q.px;
                            let p = c / (i * 0.82) - q.py;
                            let m = Math.max(0.001, q.d1);
                            let g = (1 - h(0.025, 0.16, e)) * ((s * Ht + p * Ut) / m);
                            let _ = Bt(t.da, f * 1.7 + 4.1, c * 1.7, T) * 0.16;
                            let v = 1 + 0.08 * h(0.6, 1, n);
                            let y = (1 + g * 0.42 + _) * v * (1 - 0.16 * (1 - h(0.03, 0.13, e)));
                            let b = n_san.mau[0] * (0.8 + 0.3 * r) * y;
                            let x = n_san.mau[1] * (0.82 + 0.28 * r) * y;
                            let C = n_san.mau[2] * (0.84 + 0.26 * r) * y;
                            if (e < 0.035) {
                                let t = h(0.012, 0.035, e);
                                let n = n_san.vua[0];
                                let r = n_san.vua[1];
                                let i = n_san.vua[2];
                                if (n_san.reu && d(f / 2.5, c / 2.5, e_seed + 116) > 1 - n_san.reu) {
                                    let e = n_san.reuMau ?? [
                                        70,
                                        96,
                                        52
                                    ];
                                    n = e[0];
                                    r = e[1];
                                    i = e[2];
                                }
                                b = n + (b - n) * t;
                                x = r + (x - r) * t;
                                C = i + (C - i) * t;
                            } else {
                                if (u(q.i, q.j, e_seed + 113) < 0.12 && Math.abs(d(f * 7 + r * 9, c * 7, e_seed + 114) - 0.5) < 0.025) {
                                    b *= 0.55;
                                    x *= 0.55;
                                    C *= 0.55;
                                }
                            }
                            if (o > 0) {
                                let e = o * 0.35;
                                b += (X.r - b) * e;
                                x += (X.g - x) * e;
                                C += (X.b - C) * e;
                            }
                            Q(b, x, C, a);
                        } else {
                            if (e.kSan && r > -0.5 && r < 0.6 && q.d1 < 0.3 && l(q.i, q.j, e_seed + 119) < 0.35) {
                                $(0.9);
                            }
                        }
                    }
                }
                if (e_ruong && n_ruong && e.kRuong) {
                    let t = Z(e.kRuong);
                    if (t > -0.35) {
                        sn(f, c, t, e_seed, n_ruong);
                    }
                }
                if (Se) {
                    an(f, c, Se, n.ray, e_seed);
                }
                if (G < 0.5) {
                    let t = (1 - h(0, 1.6, Re)) * 0.3 + (1 - h(0, 0.5, ze)) * 0.14;
                    if (I >= 0.5) {
                        X.r *= 1 - t * 1.15;
                        X.g *= 1 - t * 0.95;
                        X.b *= 1 - t * 0.6;
                    } else {
                        $(1 - t);
                    }
                    if (j > 0 && Re < 1.5 && !(e_ruong && e.kRuong && Z(e.kRuong) > 0)) {
                        on(f, c, Re, ze, j, e_seed, v[0]);
                    }
                }
                if (e_nuoc && e_kNuoc && n_nuoc) {
                    let t = Z(e_kNuoc);
                    if (t > -Math.max(0.9, n_nuoc.am ?? 0)) {
                        un(e, f, c, t, Z(e_nuoc), e_seed, n_nuoc, Ce, H, U, W);
                    }
                    if (n_nuoc.daBo && t > -0.75 && t < 0.75 || n_nuoc.daGiua && t > 0.6) {
                        cn(e, f, c, t, e_seed, n_nuoc, v[0]);
                    }
                }
                let Be = h(0.46, 0.54, G);
                if (Be > 0) {
                    let n = X.r;
                    let r = X.g;
                    let i = X.b;
                    let a = e.the[X.k] === 1 || e.the[X.k + 1] === 1 || e.the[X.k + C] === 1;
                    mn(e, t, f, c, a ? v[1] : v[0], a, e_seed, T, je, n, r, i);
                    if (a && e_tang) {
                        if (qt.xs >= 0) {
                            let t = qt.h - qt.xs;
                            if (M(e, e_tang, f, c - t - 0.4) - M(e, e_tang, f, c + qt.xs + 0.4) > 0.3) {
                                Zt(f, t, qt.h, e_seed, v[1], R);
                            }
                        } else if (qt.tren) {
                            let t = M(e, e_tang, f, c - Math.max(0, -Z(e.len)) - 0.5);
                            if (t - Z(e_tang) > 0.3) {
                                X.r = n;
                                X.g = r;
                                X.b = i;
                                Jt(f, c, t, qt.dt, e_seed, v[1], R, 1);
                                qt.tren = false;
                            }
                        }
                    }
                    if (qt.tren && R > 0) {
                        let e = 0.12 * R;
                        X.r *= 1 + e * 1.1;
                        X.g *= 1 + e;
                        X.b *= 1 + e * 0.6;
                    }
                    let o = X.r;
                    let s = X.g;
                    let l = X.b;
                    X.r = n + (o - n) * Be;
                    X.g = r + (s - r) * Be;
                    X.b = i + (l - i) * Be;
                    if (G > 0.46 && G < 0.6) {
                        $(1 - 0.35 * (1 - Math.abs(G - 0.52) / 0.08));
                    }
                }
                for (let n of e.bac){
                    if (f >= n.x0 - xn && f <= n.x1 + xn && c >= n.y0 && c <= n.y1 + Sn) {
                        Cn(t, f, c, n, v[1], e_seed, T);
                    }
                }
                if (e_rung && e_kRung && n_rung) {
                    let t = Z(e_kRung);
                    if (t > -(n_rung.vuon ?? 0.45) - 0.15) {
                        En(e, f, c, Z(e_rung), t, e_seed, n_rung);
                    }
                }
                if (Be < 1) {
                    let t = X.r;
                    let n = X.g;
                    let r = X.b;
                    if (e_tang) {
                        let t = Z(e_tang);
                        let n = t > 0.3 ? Z(e.mep) : 9;
                        if (t > 0.05 || n < 1.1) {
                            Jt(f, c, t, n, e_seed, v[1], R, 1 - Math.max(e_nuoc ? Z(e_nuoc) : 0, e_ruong && !n_ruong?.kho ? Z(e_ruong) : 0, e_rung ? 0.7 * Z(e_rung) : 0), e_rung ? Z(e_rung) : 0);
                        }
                    }
                    if (oe > 0 && G < 0.5) {
                        Qt(Z(e.chanMo), Z(e.hChan), ze, oe);
                        let t = Z(e.bacThap);
                        let n = e.benMo ? Z(e.benMo) : 0;
                        if (t + n > 0.003) {
                            $t(Math.min(0.7, t + n) * oe * (1 - (1 - se) * Math.max(e_nuoc ? Z(e_nuoc) : 0, e_ruong && !n_ruong?.kho ? Z(e_ruong) : 0)));
                        }
                    }
                    if (Be > 0) {
                        X.r = t + (X.r - t) * (1 - Be);
                        X.g = n + (X.g - n) * (1 - Be);
                        X.b = r + (X.b - r) * (1 - Be);
                    }
                }
                if (re > 0 && G < 0.4 && X.g > 200 && l(Math.floor(f * 40), Math.floor(c * 40), e_seed + 156) < re * 0.012) {
                    X.r = 255;
                    X.g = 255;
                    X.b = 255;
                }
                let Ve = (a * p + i) * 4;
                s[Ve] = X.r * y;
                s[Ve + 1] = X.g * b;
                s[Ve + 2] = X.b * x;
                s[Ve + 3] = 255;
            }
        }
        return s;
    }
    function nn(e, t, n, r, i) {
        let a = 9;
        let o = 0;
        for(let r = 0; r < n.length; r += 5){
            let i = n[r];
            let s = n[r + 1];
            let c = n[r + 2] - i;
            let l = n[r + 3] - s;
            let u = c * c + l * l || 1;
            let d = Math.max(0, Math.min(1, ((e - i) * c + (t - s) * l) / u));
            let f = e - i - d * c;
            let p = t - s - d * l;
            let m = Math.hypot(f, p);
            if (m < a) {
                a = m;
                let n = Math.sqrt(u);
                o = ((e - i) * -l + (t - s) * c) / n;
            }
        }
        if (a > 1.1) {
            return;
        }
        let s = (d(e / 6, t / 6, i + 181) - 0.5) * 0.3;
        let c = r * h(0.25, 0.55, d(e / 9 + 3, t / 9, i + 182));
        if (c < 0.02) {
            return;
        }
        let l = Math.abs(Math.abs(o + s) - 0.62);
        if (l < 0.11) {
            $(1 - 0.24 * (1 - h(0.04, 0.11, l)) * c);
            if (l > 0.07) {
                $(1 + 0.12 * c);
            }
        } else if (Math.abs(o + s) < 0.4) {
            $(1 + 0.05 * c);
        }
    }
    function rn(e, t, n, r) {
        let i = [];
        let a = 1.4;
        for (let o of e.ray){
            for(let e = 1; e < o.d.length; e++){
                let [s, c] = o.d[e - 1];
                let [l, u] = o.d[e];
                if (!(Math.max(s, l) < t - a || Math.min(s, l) > t + r + a || Math.max(c, u) < n - a || Math.min(c, u) > n + r + a)) {
                    i.push(s, c, l, u, o.s[e - 1], o.s[e] - o.s[e - 1]);
                }
            }
        }
        return i;
    }
    function an(e, t, n, ray, i) {
        let a = 9;
        let o = 0;
        let s = 0;
        let c = 1;
        let u = 0;
        for(let r = 0; r < n.length; r += 6){
            let i = n[r];
            let l = n[r + 1];
            let d = n[r + 2] - i;
            let f = n[r + 3] - l;
            let p = n[r + 5] || 1;
            let m = Math.max(0, Math.min(1, ((e - i) * d + (t - l) * f) / (p * p)));
            let h = e - i - m * d;
            let g = t - l - m * f;
            let _ = Math.hypot(h, g);
            if (_ < a) {
                a = _;
                c = d / p;
                u = f / p;
                o = (e - i) * -u + (t - l) * c;
                s = n[r + 4] + m * p;
            }
        }
        if (a > 1.15) {
            return;
        }
        let f = 1 - h(0.7, 1.15, a);
        m(e / 0.13, t / 0.13, i + 171, 0.9, 1, J);
        let p = l(J.i, J.j, i + 172);
        let _ = (J.d2 - J.d1 < 0.12 ? 0.62 : 0.86 + 0.3 * p) * (0.9 + 0.2 * d(e / 1.7, t / 1.7, i + 173));
        Q(ray.dam[0] * _, ray.dam[1] * _, ray.dam[2] * _, f * (0.55 + 0.35 * p));
        let v = Math.abs(o);
        let y = Math.floor(s / 0.72);
        let b = (l(y, 7, i + 174) - 0.5) * 0.08;
        let x = s - (y + 0.5) * 0.72 - b;
        let S = l(y, 3, i + 175) < 0.07;
        let C = 0.8 + 0.12 * l(y, 5, i + 176);
        if (!S && Math.abs(x) < 0.12 && v < C) {
            let e = (0.86 + 0.18 * d(o * 9 + y * 3.1, x * 30, i + 177) + (l(y, 9, i + 178) - 0.5) * 0.2) * (x < -0.075 ? 1.12 : x > 0.085 ? 0.6 : 1);
            if (v > C - 0.05) {
                e *= 0.7;
            }
            X.r = ray.go[0] * e;
            X.g = ray.go[1] * e;
            X.b = ray.go[2] * e;
        } else {
            if (!S && x > 0.12 && x < 0.17 && v < C) {
                $(0.7);
            }
        }
        let w = v - 0.45;
        if (Math.abs(w) < 0.04) {
            let n = Math.sign(o || 1) * -u;
            let a = Math.sign(o || 1) * c;
            let s = (n * -0.6 + a * -0.8) * (w / 0.04);
            let l = h(0.45, 0.8, d(e / 2.3, t / 2.3, i + 179));
            let f = 0.8 + 0.55 * g(s, -1, 1) + (Math.abs(w) > 0.03 ? -0.25 : 0);
            X.r = (ray.sat[0] + (150 - ray.sat[0]) * l * 0.5) * f;
            X.g = (ray.sat[1] + (80 - ray.sat[1]) * l * 0.5) * f;
            X.b = (ray.sat[2] + (50 - ray.sat[2]) * l * 0.5) * f;
        } else if (w >= 0.04 && w < 0.075) {
            let e = Math.sign(o || 1) * -u;
            let t = Math.sign(o || 1) * c;
            if (e * 0.6 + t * 0.8 > 0.2) {
                $(0.72);
            }
        } else if (w <= -0.04 && w > -0.075) {
            let e = Math.sign(o || 1) * -u;
            let t = Math.sign(o || 1) * c;
            if (e * 0.6 + t * 0.8 < -0.2) {
                $(0.72);
            }
        }
    }
    function on(e, t, n, r, i, a, o) {
        let s = r < 2.6 ? 1 : 0.45;
        let c = i * (1 - h(0.15, 1.5, n)) * s;
        if (c < 0.03) {
            return;
        }
        let d = 0.5;
        m(e / d, t / d, a + 61, 0.8, 1, J);
        if (l(J.i, J.j, a + 62) > c) {
            return;
        }
        let f = u(J.i, J.j, a + 63);
        let p = (0.12 + 0.16 * f) * (1.2 - 0.5 * h(0, 1.2, n)) / d;
        let g = (l(J.j, J.i, a + 64) - 0.5) * 1.2;
        let _ = e / d - J.px;
        let v = t / d - J.py;
        let y = Math.cos(g);
        let b = Math.sin(g);
        let x = _ * y + v * b;
        let S = (-_ * b + v * y) * 1.15;
        let C = Math.abs(x);
        let w = Math.abs(S);
        if (C < p && w < p) {
            let e = S < p * 0.15;
            let t = e ? 1.08 + 0.18 * (-x / p) * 0.5 : 0.62 + 0.12 * (-x / p);
            t *= 0.85 + 0.3 * f;
            let n = e ? o.mat : o.vach;
            X.r = n[0] * t;
            X.g = n[1] * t;
            X.b = n[2] * t;
            if (e && o.tuyet) {
                Q(236 * (0.9 + 0.1 * f), 241 * (0.9 + 0.1 * f), 250, o.tuyet * 0.85);
            }
            if (p - C < 0.07 || p - w < 0.07 || Math.abs(S - p * 0.15) < 0.04) {
                X.r = X.r * 0.55 + o.khe[0] * 0.45;
                X.g = X.g * 0.55 + o.khe[1] * 0.45;
                X.b = X.b * 0.55 + o.khe[2] * 0.45;
            }
        } else {
            if (x > -p * 0.4 && S > 0 && C < p * 1.35 && w < p * 1.5) {
                $(0.68);
            }
        }
    }
    function sn(e, t, n, r, i) {
        let a = 0.32 + 0.3 * d(e / 2.2, t / 2.2, r + 127);
        let o = t + 0.6 * Math.sin(e / 7.3 + r % 97) + 0.9 * (d(e / 9, 0.5, r + 121) - 0.5);
        let s = 2.4;
        let c = Math.floor(o / s);
        let f = (e)=>(l(e, 3, r + 129) - 0.5) * 0.9;
        let p = c;
        if (o < c * s + f(c)) {
            p--;
        } else if (o >= (c + 1) * s + f(c + 1)) {
            p++;
        }
        let m = p * s + f(p);
        let _ = (p + 1) * s + f(p + 1);
        let v = (o - m) / (_ - m);
        let y = 6 + 6 * l(p, 11, r + 130);
        let b = e + (v - 0.5) * 1.4 * (l(p, 7, r + 128) - 0.5);
        let x = (e)=>y * (e + (l(e, p, r + 122) - 0.5) * 0.6);
        let S = Math.floor(b / y);
        if (b < x(S)) {
            S--;
        } else if (b >= x(S + 1)) {
            S++;
        }
        let C = (b - x(S)) / (x(S + 1) - x(S));
        let w = x(S + 1) - x(S);
        let T = 0.26 / (_ - m);
        let E = 0.24 / w;
        let D;
        let O;
        let k;
        let A = v < T || C < E * 0.5 || C > 1 - E * 0.5;
        if (n < a || A) {
            let o = v < T ? 1 - Math.abs(v / T - 0.4) : n < a ? 1 - Math.abs(n / Math.max(0.05, a) - 0.45) : 0.6;
            let s = 0.8 + 0.3 * g(o);
            D = i.bo[0] * s;
            O = i.bo[1] * s;
            k = i.bo[2] * s;
            if (l(Math.floor(e * 9), Math.floor(t * 9), r + 123) < 0.38) {
                D = D * 0.5 + i.ma[0] * 0.5;
                O = O * 0.5 + i.ma[1] * 0.5;
                k = k * 0.5 + i.ma[2] * 0.5;
            }
            if (n > a - 0.08 && n < a && !A) {
                D *= 0.78;
                O *= 0.8;
                k *= 0.82;
            }
        } else if (i.kho) {
            let n = 0.35 + 0.65 * l(S, p, r + 124);
            let a = (o - m) / 0.6;
            let s = Math.floor(a);
            let c = a - s;
            let f = (0.7 + 0.42 * Math.sin(c * Math.PI)) * (1 + (d(e * 5, t * 5, r + 125) - 0.5) * 0.25);
            D = i.nuoc[0] * f;
            O = i.nuoc[1] * f;
            k = i.nuoc[2] * f;
            if (v > T + 0.04) {
                let a = 0.48;
                let o = Math.floor((e + l(s, S, r + 131) * a) / a);
                let d = (o + 0.5) * a - l(s, S, r + 131) * a;
                let f = (0.1 + 0.11 * n) * (0.8 + 0.4 * l(o, s, r + 132));
                let p = e - d;
                let m = (c - 0.5) * 0.6 * 1.15;
                let h = Math.hypot(p, m);
                if (u(o, s, r + 133) < 0.85 && h < f) {
                    let n = p / f;
                    let a = m / f;
                    let o = Math.sqrt(Math.max(0, 1 - n * n - a * a));
                    let s = Math.max(0, -0.5 * n - 0.6 * a + 0.65 * o);
                    let c = l(Math.floor(e * 20), Math.floor(t * 20), r + 134) < 0.3 ? 0.85 : 1;
                    let u = (0.55 + 0.6 * s) * c;
                    D = (i.ma[0] + (i.maSang[0] - i.ma[0]) * s) * u;
                    O = (i.ma[1] + (i.maSang[1] - i.ma[1]) * s) * u;
                    k = (i.ma[2] + (i.maSang[2] - i.ma[2]) * s) * u;
                } else {
                    if (h < f * 1.35 && m > 0) {
                        D *= 0.72;
                        O *= 0.72;
                        k *= 0.72;
                    }
                }
            }
        } else {
            let s = l(S, p, r + 124);
            let c = (1 - 0.4 * (1 - h(T, T + 0.1, v))) * (1 - 0.28 * (1 - h(a, a + 0.25, n)));
            let f = i.kho ? (d(e * 4, t * 4, r + 125) - 0.5) * 0.25 : h(0.55, 0.85, d(e / 3.2, t / 0.5, r + 125)) * 0.24;
            D = i.nuoc[0] * c * (1 + f);
            O = i.nuoc[1] * c * (1 + f);
            k = i.nuoc[2] * c * (1 + f * (i.kho ? 1 : 1.3));
            if (s > 0.08) {
                let t = (o - m) / 0.24;
                let n = Math.floor(t);
                let a = t - n;
                let c = 0.34 + 0.5 * s;
                if (a > 1 - c && v > T + 0.05) {
                    let t = (a - (1 - c)) / c;
                    let o = Math.floor(e * 18 + l(n, S, r + 131) * 7);
                    let d = 0.45 + 0.55 * l(o, n, r + 132);
                    if (u(o, n, r + 133) < 0.3 + 0.7 * s && t > 1 - d) {
                        let e = (0.66 + 0.4 * (1 - t)) * (o % 2 ? 1.06 : 0.9);
                        let n = 1 - t;
                        D = (i.ma[0] + (i.maSang[0] - i.ma[0]) * n) * e;
                        O = (i.ma[1] + (i.maSang[1] - i.ma[1]) * n) * e;
                        k = (i.ma[2] + (i.maSang[2] - i.ma[2]) * n) * e;
                    } else {
                        if (t > 0.75) {
                            D *= 0.82;
                            O *= 0.86;
                            k *= 0.88;
                        }
                    }
                }
            }
        }
        Q(D, O, k, h(-0.3, 0.02, n));
    }
    function cn(e, t, n, r, i, a, o) {
        let s = r > 0.6;
        let c = s ? 1.7 : 0.8;
        m(t / c, n / (c * 0.8), i + (s ? 171 : 172), 0.85, 1, J);
        let f = l(J.i, J.j, i + 173);
        let p = J.px * c;
        let g = J.py * c * 0.8;
        let _ = s ? (a.daGiua ?? 0) * 0.3 : (a.daBo ?? 0) * h(0.3, 0.62, d(p / 4.5, g / 4.5, i + 174));
        if (u(J.i, J.j, i + 175) > _) {
            return;
        }
        let v = M(e, e.kNuoc, p, g);
        if (s ? v < 1 : v < -0.3 || v > 0.45) {
            return;
        }
        let y = s ? 0.26 + 0.26 * f : 0.2 + 0.28 * f;
        let b = t - p;
        let x = (n - g) * 1.55;
        let S = Math.hypot(b, x) * (0.86 + 0.28 * d(t * 6.5, n * 6.5, i + 179));
        let C = a.daMau ?? o.mat;
        if (S < y) {
            let e = b / y;
            let r = x / y;
            let a = Math.min(1, e * e + r * r);
            let s = Math.sqrt(1 - a);
            let c = (0.48 + 0.75 * Math.max(0, -0.55 * e - 0.65 * r + 0.55 * s)) * (0.82 + 0.32 * l(J.j, J.i, i + 176)) * (1 + (ln(t, n, i) - 0.5) * 0.25);
            if (r > 0.3) {
                c *= 0.7 - 0.3 * (r - 0.3);
            }
            let u = o.reu && r < -0.1 && l(Math.floor(t * 14), Math.floor(n * 14), i + 177) < 0.35 * (o.reu.mat + 0.3) ? 1 : 0;
            X.r = (u ? o.reu.mau[0] : C[0]) * c;
            X.g = (u ? o.reu.mau[1] : C[1]) * c;
            X.b = (u ? o.reu.mau[2] : C[2]) * c;
            if (S > y * 0.88) {
                $(0.55);
            }
        } else if (S < y * 1.5 && (r > 0 || s)) {
            let e = (1 - h(y * 1.05, y * 1.5, S)) * h(0.35, 0.6, d(t * 6, n * 6, i + 178));
            Q(a.bot[0], a.bot[1], a.bot[2], e * 0.75);
        } else {
            if (S < y * 1.35 && x > 0) {
                $(0.78);
            }
        }
    }
    function ln(e, t, n) {
        return l(Math.floor(e * 22), Math.floor(t * 22), n + 180);
    }
    function un(e, t, n, r, i, a, o, s, c, p, g) {
        let _ = o.am ? h(-o.am * (0.25 + 0.75 * f(t / 7, n / 7, a + 178, 2)), -0.9, r) * 0.38 * (0.6 + 0.4 * d(t / 2.3, n / 2.3, a + 179)) : 0;
        let v = Math.max(h(-0.9, -0.05, r), _);
        let y = 1 - v;
        X.r *= y + v * o.uot[0] / 255;
        X.g *= y + v * o.uot[1] / 255;
        X.b *= y + v * o.uot[2] / 255;
        if (i <= 0.3) {
            return;
        }
        let b = 1 - Math.exp(-Math.max(0, r) / 1.3);
        let x = o.nong[0] + (o.sau[0] - o.nong[0]) * b;
        let S = o.nong[1] + (o.sau[1] - o.nong[1]) * b;
        let C = o.nong[2] + (o.sau[2] - o.nong[2]) * b;
        let w = (o.trong ?? 0.5) * (1 - h(0.1, 0.75, b));
        if (w > 0.02) {
            m(t / 0.32, n / 0.28, a + 131, 0.9, 1, J);
            let e = l(J.i, J.j, a + 132);
            let r = 1 + ((J.d2 - J.d1 < 0.12 ? 0.72 : 0.9 + 0.25 * e) - 1) * w;
            x *= r;
            S *= r;
            C *= r;
        }
        let T = 0.3;
        let E = 0.1;
        if (e.chayX && e.chayY) {
            let t = e.W1;
            let n = e.chayX;
            let r = e.chayY;
            T = (n[g] * (1 - c) + n[g + 1] * c) * (1 - p) + (n[g + t] * (1 - c) + n[g + t + 1] * c) * p;
            E = (r[g] * (1 - c) + r[g + 1] * c) * (1 - p) + (r[g + t] * (1 - c) + r[g + t + 1] * c) * p;
        }
        let D = Math.atan2(E, T);
        let O = Math.PI / 8;
        let k = D / O;
        let A = Math.floor(k);
        let j = k - A;
        let ee = o.lang ? h(0.5, 0.85, f(t / 6, n / 4.5, a + 133, 3)) * 0.42 + (()=>{
            let e = d(t * 1.7 + 0.6 * d(t * 0.5, n * 0.5, a + 176), n * 5.2, a + 134);
            return h(0.58, 0.64, e) * (1 - h(0.66, 0.72, e)) * 0.3;
        })() : dn(t, n, A * O, a) * (1 - j) + dn(t, n, (A + 1) * O, a) * j;
        x += (o.troi[0] - x) * ee * 0.45;
        S += (o.troi[1] - S) * ee * 0.45;
        C += (o.troi[2] - C) * ee * 0.45;
        if (o.daBo) {
            fn[0] = 0;
            fn[1] = 0;
            pn(t, n, A * O, b, a, 1 - j);
            pn(t, n, (A + 1) * O, b, a, j);
            let e = fn[0];
            if (e > 0.01) {
                x += (o.troi[0] - x) * e * 0.55;
                S += (o.troi[1] - S) * e * 0.55;
                C += (o.troi[2] - C) * e * 0.55;
            }
            let r = fn[1];
            x *= 1 - r;
            S *= 1 - r;
            C *= 1 - r * 0.6;
        }
        if (M(e, e.kNuoc, t, n - 0.7) < 0.2 && r < 1.6) {
            let e = 1 - 0.35 * (1 - h(0.1, 1.6, r));
            x *= e;
            S *= e;
            C *= e * 1.02;
        }
        let te = (1 - h(0.04, 0.26, r)) * h(0.35, 0.6, d(t * 3.3, n * 3.3, a + 135) * 0.7 + d(t * 9, n * 9, a + 136) * 0.3);
        x += (o.bot[0] - x) * te * 0.75;
        S += (o.bot[1] - S) * te * 0.75;
        C += (o.bot[2] - C) * te * 0.75;
        if (o.beo) {
            let e = h(1 - o.beo.mat * 0.6, 1.12 - o.beo.mat * 0.6, f(t / 3.4, n / 3.4, a + 171, 2) * 0.62 + d(t / 1.1, n / 1.1, a + 174) * 0.18 + (1 - h(0.3, 4, r)) * 0.3);
            if (e > 0) {
                m(t / 0.16, n / 0.13, a + 172, 0.9, 1, J);
                let r = l(J.i, J.j, a + 173);
                let i = +(J.d1 < 0.34 + 0.1 * r && r < 0.35 + e * 0.75);
                let s = 0.82 + 0.3 * r - (J.d1 > 0.26 ? 0.18 : 0);
                if (i) {
                    let t = Math.min(1, e * 1.4);
                    x += (o.beo.mau[0] * s - x) * t;
                    S += (o.beo.mau[1] * s - S) * t;
                    C += (o.beo.mau[2] * s - C) * t;
                } else {
                    let t = e * 0.35;
                    x += (o.beo.mau[0] * 0.55 - x) * t;
                    S += (o.beo.mau[1] * 0.55 - S) * t;
                    C += (o.beo.mau[2] * 0.55 - C) * t;
                }
            }
        }
        if (o.bang) {
            let e = o.bang.rong * (0.2 + 1.6 * h(0.2, 0.8, f(t / 5.5, n / 5.5, a + 137, 2))) + (d(t * 1.3, n * 1.3, a + 139) - 0.5) * 0.35;
            let i = 0;
            if (r >= e + 0.2) {
                m(t / 1.1, n / 0.9, a + 142, 0.85, 1, J);
                let e = l(J.i, J.j, a + 143);
                let r = 0.14 + 0.16 * u(J.i, J.j, a + 144);
                let o = J.d2 - J.d1;
                if (e < 0.14 && o > r) {
                    i = 1 - Math.min(1, (o - r) / 0.06) * 0.2;
                } else if (e < 0.14 && o > r - 0.07 && (t / 1.1 - J.px) * 0.6 + (n / 0.9 - J.py) * 0.8 > 0) {
                    x *= 0.7;
                    S *= 0.72;
                    C *= 0.76;
                }
            }
            if (i > 0) {
                let e = 0.9 + 0.1 * l(J.i, J.j, a + 145);
                x = o.bang.mau[0] * e;
                S = o.bang.mau[1] * e;
                C = o.bang.mau[2] * e;
                if (i > 0.9) {
                    x = 236;
                    S = 244;
                    C = 250;
                }
            } else if (r < e) {
                m(t / 0.95, n / 0.8, a + 138, 0.9, 1, J);
                let i = l(J.i, J.j, a + 140);
                let s = Math.max(0, r) / Math.max(0.05, e);
                let c = o.bang.mau[0] * (0.9 + 0.14 * i);
                let u = o.bang.mau[1] * (0.9 + 0.14 * i);
                let f = o.bang.mau[2] * (0.93 + 0.1 * i);
                let p = h(0.45, 1, s) * 0.35;
                c += (x - c) * p;
                u += (S - u) * p;
                f += (C - f) * p;
                let g = h(0.45, 0.8, d(t / 1.6, n / 1.6, a + 141) * 0.7 + (1 - s) * 0.5);
                c += (244 - c) * g * 0.85;
                u += (247 - u) * g * 0.85;
                f += (252 - f) * g * 0.85;
                if (J.d2 - J.d1 < 0.05 && g < 0.6) {
                    c *= 0.72;
                    u *= 0.78;
                    f *= 0.86;
                }
                if (e - r < 0.07) {
                    c = 236;
                    u = 244;
                    f = 250;
                }
                if (r < 0.06) {
                    let e = 0.55 + 0.45 * h(0, 0.06, r);
                    c *= e;
                    u *= e;
                    f *= e * 1.04;
                }
                x = c;
                S = u;
                C = f;
            } else if (r < e + 0.22) {
                let t = 0.62 + 0.38 * h(e, e + 0.22, r);
                x *= t;
                S *= t;
                C *= t;
            }
        }
        Q(x, S, C, h(0.4, 0.56, i));
    }
    function dn(e, t, n, r) {
        let i = Math.cos(n);
        let a = Math.sin(n);
        let o = e * i + t * a;
        let s = -e * a + t * i;
        return h(0.5, 0.85, d(o / 3.4, s / 0.42, r + 133)) * 0.55 + h(0.6, 0.9, d(o / 1.1, s / 0.18, r + 134)) * 0.25;
    }
    let fn = [
        0,
        0
    ];
    function pn(e, t, n, r, i, a) {
        if (a <= 0) {
            return;
        }
        let o = Math.cos(n);
        let s = Math.sin(n);
        let c = e * o + t * s;
        let l = -e * s + t * o;
        fn[0] += a * (h(0.8, 0.9, d(c / 0.55, l / 0.085, i + 137)) * (0.3 + 0.7 * r) + h(0.86, 0.94, d(c / 0.3, l / 0.06, i + 138)) * 0.5);
        fn[1] += a * h(0.78, 0.9, d(c / 0.7, l / 0.12, i + 139)) * r * 0.18;
    }
    function mn(e, t, n, r, i, a, o, s, c, f, p, g) {
        let _ = Wt(e.xuong, e.da);
        let v = Math.max(0, -Wt(e.len, e.da));
        let y = _ + v;
        let b = r + _;
        re(e, i, n, b, Y);
        let x = ae(Y, y, a, a ? ie(e, X.k) : 0);
        qt.tren = false;
        if (_ < x) {
            qt.xs = _;
            qt.h = x;
            bn(t, n, r, _, x, b, i, o, s);
            return;
        }
        qt.xs = -1;
        let S = Wt(e.tay, e.da);
        let C = Wt(e.dong, e.da);
        let w = a ? 0 : Math.min(0.5, 0.12 + 0.11 * x) * (i.ben ?? 1);
        if (C < w || S < w) {
            let a = C < S;
            let c = a ? C : S;
            let u = c / w;
            re(e, i, r * 1.2, (a ? n + C : n - S) * 0.7, Vt, 17);
            let f = Vt.u;
            let p = Bt(t.da, r * 0.8 + 1.7, n * 0.3 + c, s) * (i.hat ?? 0.35);
            let m = (a ? 0.5 : 0.95) * (0.88 + 0.24 * l(Vt.i, 3, o + 18)) * (1.08 - 0.25 * f) * (0.7 + 0.3 * u) * (1 + p);
            if (Math.min(f, 1 - f) * Vt.w < 0.035) {
                m *= 0.5;
            }
            X.r = i.vach[0] * m;
            X.g = i.vach[1] * m;
            X.b = i.vach[2] * m;
            if (gn.anh && u > 0.78) {
                let e = (a ? 0.62 : 0.95) * (0.85 + 0.2 * l(Vt.i, 4, o + 19));
                Q(i.mat[0] * e, i.mat[1] * e, i.mat[2] * e, h(0.78, 0.86, u + (d(r * 3, n, o + 20) - 0.5) * 0.1));
            }
            if (u > 0.84) {
                let e = h(0.84, 0.98, u) * (a ? 0.5 : 0.85);
                Q(i.vien[0], i.vien[1], i.vien[2], e);
            }
            if (i.tuyet && u > 0.7) {
                Q(225, 232, 244, h(0.7, 0.85, u) * i.tuyet);
            }
            return;
        }
        qt.tren = true;
        let T = _ - x;
        qt.dt = T;
        if ((i.tuyet ?? 0) >= 0.5 && !a) {
            hn(e, t, n, r, i, o, s, T, v, S - w, C - w);
            return;
        }
        if (gn.anh && !a) {
            _n(n, r, T, v, S, C, w, i, o, c, f, p, g);
            return;
        }
        let E = i.tam ?? 1.5;
        let D = 0.35 + 0.45 * u(Y.i, Y.bang, o + 51);
        let O;
        let k;
        let A;
        let j;
        if (!a && T < D && y > 0.9) {
            let e = Math.min(Y.u, 1 - Y.u) * Y.w;
            O = Math.min(e, D - T) * 1.3;
            k = l(Y.i, Y.bang, o + 52);
            A = (Y.u - 0.5) * Y.w * 1.6;
            j = -(T - D / 2) * 1.6;
        } else if (!a && y > 1.4 && v < 0.95 && v < yn(e, i, n, r - v, o)) {
            let e = Math.min(Vt.u, 1 - Vt.u) * Vt.w;
            let t = vn;
            O = Math.min(e, t - v) * 1.3;
            k = l(Vt.i, Vt.bang, o + 54);
            A = (Vt.u - 0.5) * Vt.w * 1.6;
            j = (v - t / 2) * 1.6;
        } else {
            let e = E;
            let t = n + (d(n / 1.9, r / 1.9, o + 90) - 0.5) * 0.7 * e;
            let s = r + (d(n / 1.9 + 7, r / 1.9, o + 91) - 0.5) * 0.7 * e;
            m(t / e, s / (e * 0.8), o + 81, 0.9, 1, q);
            O = (q.d2 - q.d1) * e * 0.55;
            k = l(q.i, q.j, o + 82);
            A = t / e - q.px;
            j = s / (e * 0.8) - q.py;
            if (i.bac && !a) {
                let e = l(q.i2, q.j2, o + 82);
                let t = q.px2 - q.px;
                let a = (q.py2 - q.py) * 0.8;
                let s = -a / Math.max(0.001, Math.hypot(t, a));
                let u = (e - k) * i.bac * s;
                if (s > 0.3 && u > 0.05 && O < u) {
                    let t = O / u;
                    let a = 0.86 + 0.14 * d(n * 7, r * 0.9, o + 94);
                    let s = (0.6 + 0.3 * e) * (1.05 - 0.3 * t) * a * (0.94 + 0.12 * c);
                    X.r = i.vach[0] * s;
                    X.g = i.vach[1] * s;
                    X.b = i.vach[2] * s;
                    if (t < 0.18) {
                        Q(i.vien[0] * 0.9, i.vien[1] * 0.9, i.vien[2] * 0.9, (1 - t / 0.18) * 0.55);
                    }
                    if (t > 0.75) {
                        $(1 - 0.35 * h(0.75, 1, t));
                    }
                    if (i.tuyet && t < 0.25) {
                        Q(225, 232, 244, (1 - t / 0.25) * i.tuyet * 0.8);
                    }
                    return;
                }
            }
            if (k < 0.42) {
                m(t / (e * 0.45), s / (e * 0.38), o + 92, 0.9, 1, J);
                let n = (J.d2 - J.d1) * e * 0.25;
                if (n < O) {
                    O = n * 1.4;
                    k = k * 0.6 + l(J.i, J.j, o + 93) * 0.4;
                    A = t / (e * 0.45) - J.px;
                    j = s / (e * 0.38) - J.py;
                }
            }
        }
        let ee = Math.max(0.001, Math.hypot(A, j));
        let te = 1 - h(0.02, i.vat ?? 0.32, O);
        let ne = te * ((A * Ht + j * Ut) / ee);
        let M = Bt(t.da, n + 2.9, r + 1.7, s) * (i.hat ?? 0.35) * 0.7;
        let N = X.n5 - 0.5;
        let P = (0.78 + 0.38 * k) * (1 + ne * 0.58 - te * 0.1 + M) * (0.94 + 0.12 * c);
        if (S < w + 0.3) {
            P *= 1 + 0.1 * (1 - (S - w) / 0.3);
        }
        if (C < w + 0.3) {
            P *= 1 - 0.1 * (1 - (C - w) / 0.3);
        }
        X.r = i.mat[0] * P * (1 + N * 0.3);
        X.g = i.mat[1] * P * (1 + N * 0.22);
        X.b = i.mat[2] * P * (1 + N * 0.12);
        if (i.loang) {
            let e = i.loang;
            let t = l(q.i, q.j, o + 95) - 0.5;
            let n = u(q.i, q.j, o + 96) - 0.5;
            X.r *= 1 + e * (0.3 * t + 0.12 * n);
            X.g *= 1 + e * (0.26 * t - 0.08 * n);
            X.b *= 1 + e * (0.2 * t - 0.16 * n);
        }
        let F = v < 0.16 ? 1 - v / 0.16 : 0;
        let I = 1 - h(0.02, 0.12, T);
        let L = Math.max(F * 0.7, I);
        if (L > 0) {
            Q(i.vien[0], i.vien[1], i.vien[2], L * 0.6);
        }
        let R = 1 - h(0.01, 0.04, O);
        if (R > 0) {
            let e = (i.bui ?? 0) * 0.6;
            Q(i.khe[0] + (f - i.khe[0]) * e, i.khe[1] + (p - i.khe[1]) * e, i.khe[2] + (g - i.khe[2]) * e, R);
        } else {
            if (O < 0.05 && A * Ht + j * Ut > 0) {
                $(1.1);
            }
        }
        if (v < 0.045) {
            $(0.55);
        }
        if (i.bui) {
            let e = h(0.55, 0.8, d(n / 2.6, r / 2.6, o + 83) * 0.6 + c * 0.5) * i.bui * (1 - L) * (0.5 + 0.5 * (1 - h(0.05, 0.3, O)));
            if (e > 0.01) {
                Q(f * 0.95, p * 0.93, g * 0.9, e);
            }
        }
        if (i.co) {
            let e = h(0.55, 0.8, d(n / 4, r / 4, o + 84)) * 0.2;
            if (e > 0.01) {
                Kt(n, r, e, o + 85, i.co, X.p);
            }
        }
        if (i.reu) {
            let e = h(1 - i.reu.mat, 1 - i.reu.mat + 0.2, d(n / 3, r / 3, o + 87) * 0.7 + (1 - h(0, 0.06, O)) * 0.3);
            if (e > 0) {
                Q(i.reu.mau[0] * P, i.reu.mau[1] * P, i.reu.mau[2] * P, e * 0.7);
            }
        }
        if (i.tuyet) {
            let e = h(0.25, 0.55, i.tuyet * (0.55 + 0.6 * d(n / 2.2, r / 2.2, o + 88)) - R * 0.4);
            if (e > 0) {
                let t = 0.92 + 0.14 * ne;
                Q(232 * t, 238 * t, 250 * t, e);
            }
        }
    }
    function hn(e, t, n, r, i, a, o, s, c, f, p) {
        let _ = i.tuyet ?? 0.8;
        let v = e.gX ? N(e, e.gX, n, r) * 3.6 : 0;
        let y = e.gY ? N(e, e.gY, n, r) * 3.6 : 0;
        let b = 1 - h(0, 1.6, s);
        let x = 1 - h(0, 1.3, c);
        let S = 1 - h(0, 1.4, f);
        let C = 1 - h(0, 1.4, p);
        y += (x - b) * 0.42;
        v += (S - C) * 0.36;
        let w = -(v * Ht + y * Ut);
        let T = g(0.54 + w * 2.1);
        let E;
        let D;
        let O;
        if (T >= 0.5) {
            let e = (T - 0.5) * 2;
            E = 224 + 24 * e;
            D = 231 + 18 * e;
            O = 243 + 9 * e;
        } else {
            let e = T * 2;
            E = 150 + 74 * e;
            D = 168 + 63 * e;
            O = 206 + 37 * e;
        }
        let k = d(n * 1.9, r * 1.9, a + 161);
        let A = n * 0.82 - r * 0.57;
        let j = n * 0.57 + r * 0.82;
        let ee = (d(A / 2.6, j / 0.2, a + 151) - 0.5) * h(0.4, 0.75, d(n / 7, r / 7, a + 152));
        let te = 0.975 + 0.05 * k + 0.07 * ee;
        E *= te;
        D *= te;
        O *= te;
        let ne = 2.5;
        let M = n + (d(n / 1.2, r / 1.2, a + 162) - 0.5) * 0.85;
        let P = r + (d(n / 1.2 + 5.3, r / 1.2, a + 163) - 0.5) * 0.85;
        m(M / ne, P / (ne * 0.8), a + 164, 0.85, 1, q);
        let re = 0.12 + (1 - _) * 1.1;
        if (l(q.i, q.j, a + 165) < re && s > 0.5 && c > 0.35) {
            let e = u(q.i, q.j, a + 166);
            let s = 0.15 + 0.2 * e;
            let c = M / ne - q.px;
            let l = P / (ne * 0.8) - q.py;
            let f = q.d1;
            if (f < s) {
                let u = c / s;
                let p = l / s;
                let g = f / s;
                let _ = -0.12 + (d(n * 3.1, r * 3.1, a + 167) - 0.5) * 0.7 + (e - 0.5) * 0.5;
                if (p * 0.9 + u * 0.3 < _ && g < 0.95) {
                    let e = 1 - 0.12 * h(_ - 0.25, _, p * 0.9 + u * 0.3);
                    E = 246 * e;
                    D = 249 * e;
                    O = 253 * (0.98 + 0.02 * e);
                } else {
                    let s = -(u * Ht + p * Ut);
                    let c = Bt(t.da, n * 1.3 + 3.1, r * 1.3 + 1.1, o) * (i.hat ?? 0.35);
                    let l = (0.62 + 0.42 * s) * (0.82 + 0.3 * e) * (1 + c);
                    m(n / 0.38, r / 0.32, a + 168, 0.9, 1, J);
                    if (J.d2 - J.d1 < 0.06) {
                        l *= 0.62;
                    }
                    if (g > 0.86) {
                        l *= 0.55 + 0.45 * (1 - h(0.86, 1, g));
                    }
                    E = i.mat[0] * l;
                    D = i.mat[1] * l;
                    O = i.mat[2] * l;
                    if (d(n * 4.2, r * 4.2, a + 169) > 0.74) {
                        E = E * 0.35 + 210;
                        D = D * 0.35 + 216;
                        O = O * 0.35 + 228;
                    }
                }
            } else if (f < s * 1.7) {
                let e = (c * 0.6 + l * 0.8) / Math.max(0.001, f);
                if (e > -0.3) {
                    let t = (1 - (f - s) / (s * 0.7)) * (0.3 + 0.35 * e);
                    E *= 1 - t * 0.36;
                    D *= 1 - t * 0.3;
                    O *= 1 - t * 0.14;
                }
            }
        }
        let F = c * 1.25;
        let ie = Math.min(F, f, p);
        let ae = 0.12 + 0.5 * h(0.3, 0.85, d(n / 2.1, r / 2.1, a + 170)) + 0.12 * (d(n * 1.7, r * 1.7, a + 171) - 0.5);
        if (ie < ae) {
            let e = Bt(t.da, n * 1.2 + 7.1, r * 1.2, o) * (i.hat ?? 0.35);
            let s = (ie === p ? 0.52 : ie === F ? 1.02 : 0.9) * (0.8 + 0.25 * d(n * 2.6, r * 2.6, a + 172)) * (1 + e);
            m(n / 0.42, r / 0.34, a + 173, 0.9, 1, J);
            if (J.d2 - J.d1 < 0.07) {
                s *= 0.6;
            }
            let c = i.mat[0] * s;
            let l = i.mat[1] * s;
            let u = i.mat[2] * s;
            if (d(n * 3.6, r * 3.6, a + 174) > 0.66) {
                c = c * 0.3 + 172;
                l = l * 0.3 + 178;
                u = u * 0.3 + 192;
            }
            let f = h(ae - 0.1, ae, ie);
            E = c + (E * 0.86 - c) * f;
            D = l + (D * 0.9 - l) * f;
            O = u + (O - u) * f;
        }
        X.r = E;
        X.g = D;
        X.b = O;
        let I = 1 - h(0.03, 0.16, s);
        let L = c < 0.2 ? 1 - c / 0.2 : 0;
        if (I > 0) {
            Q(250, 252, 255, I * 0.8);
        }
        if (L > 0) {
            Q(252, 253, 255, L * 0.5);
        }
        if (c < 0.05) {
            Q(92, 104, 132, 0.55);
        }
    }
    let gn = {
        anh: null,
        tb: [
            1,
            1,
            1
        ]
    };
    function _n(e, t, n, r, i, a, o, s, c, f, p, g, _) {
        let gn_anh = gn.anh;
        let y = gn.tb;
        zt(gn_anh, X.wx * 0.93 + 5.1, X.wy * 0.93 + 2.3, 2, 9);
        let b = (s.hat ?? 0.35) / 0.35;
        let x = X.n5 - 0.5;
        let S = (0.9 + 0.2 * f) * (1 + x * 0.22);
        let C = 1 - h(0.03, 0.14, n);
        let w = h(0.1, 0.22, n) * (1 - h(0.22, 0.75, n));
        S *= 1 - 0.14 * w;
        if (i < o + 0.3) {
            S *= 1 + 0.08 * (1 - (i - o) / 0.3);
        }
        if (a < o + 0.3) {
            S *= 1 - 0.12 * (1 - (a - o) / 0.3);
        }
        X.r = s.mat[0] * (1 + (K[9] / y[0] - 1) * b) * S;
        X.g = s.mat[1] * (1 + (K[10] / y[1] - 1) * b) * S;
        X.b = s.mat[2] * (1 + (K[11] / y[2] - 1) * b) * S;
        let T = h(0.55, 0.85, d(e / 3.3, t / 3.3, c + 191)) * 0.55;
        if (T > 0.02) {
            let n = 0.36;
            m(e / n, t / n, c + 192, 0.85, 0.8, J);
            if (l(J.i, J.j, c + 193) < T) {
                let r = 0.12 + 0.22 * u(J.i, J.j, c + 194);
                let i = e / n - J.px;
                let a = (t / n - J.py) / 0.8;
                let o = Math.max(0.001, J.d1);
                if (J.d1 < r) {
                    let e = (i * Ht + a * Ut) / o;
                    let t = o / r;
                    let n = (0.7 + 0.3 * l(J.i, J.j, c + 195)) * (0.86 + 0.4 * e * Math.sqrt(t)) * (1 - 0.35 * h(0.72, 1, t));
                    X.r = s.vach[0] * 1.25 * n;
                    X.g = s.vach[1] * 1.25 * n;
                    X.b = s.vach[2] * 1.25 * n;
                } else {
                    if (J.d1 < r * 1.5 && i * 0.6 + a * 0.8 > 0) {
                        $(1 - 0.3 * (1 - h(r, r * 1.5, J.d1)));
                    }
                }
            }
        }
        if (s.bui) {
            let n = h(0.55, 0.8, d(e / 2.6, t / 2.6, c + 83) * 0.6 + f * 0.5) * s.bui;
            if (n > 0.01) {
                Q(p * 0.98, g * 0.95, _ * 0.9, n * 0.6);
            }
        }
        if (s.co) {
            let n = h(0.45, 0.75, d(e / 4, t / 4, c + 84)) * 0.28;
            if (n > 0.01) {
                Kt(e, t, n, c + 85, s.co, X.p);
            }
        }
        if (r < 0.5) {
            $(1 + 0.16 * (1 - r / 0.5) * (0.7 + 0.3 * d(e * 2.2, t, c + 196)));
        }
        let E = Math.max(C, r < 0.14 ? (1 - r / 0.14) * 0.6 : 0);
        if (E > 0) {
            Q(s.vien[0], s.vien[1], s.vien[2], E * 0.55);
        }
        if (r < 0.04) {
            $(0.6);
        }
    }
    let vn = 0.6;
    function yn(e, t, n, r, i) {
        re(e, t, n, r - 7, Vt, 31);
        vn = 0.4 + 0.45 * u(Vt.i, Vt.bang, i + 53);
        return vn;
    }
    function bn(e, t, n, r, i, a, o, s, c) {
        let f = Math.max(0, r / i);
        let p = Y.u;
        let m = 0.82 + 0.34 * l(Y.i, Y.bang, s + 41);
        let _ = 1.3 - 0.75 * p ** 1.2;
        let v = Bt(e.da, t * 0.9 + Y.i * 3.7, r * 0.75 + a * 0.25, c) * (o.hat ?? 0.35);
        let y = m * _ * (0.48 + 0.52 * f ** 0.7) * (1 + v);
        let b = 0;
        let x = 0;
        let S = 0;
        let C = 0;
        let w = i;
        let T = o.khoi ?? 1;
        let E = T > 1 ? Math.max(1, Math.round((1 + u(Y.i, Y.bang, s + 42) * 2.6) * T)) : 1 + Math.floor(u(Y.i, Y.bang, s + 42) * (i > 3.6 ? 1.6 + 0.6 * i : 2.6));
        for(let e = 0; e < E; e++){
            let t = i * (T > 1 ? (e + 0.6 + (l(Y.i * 7 + e, Y.bang, s + 43) - 0.5) * 0.6) / (E + 0.6) : i > 3.6 ? (e + 0.3 + 0.5 * l(Y.i * 7 + e, Y.bang, s + 43)) / E : 0.2 + 0.62 * l(Y.i * 7 + e, Y.bang, s + 43)) + (p - 0.5) * 0.2 * (l(Y.i, e, s + 44) - 0.5);
            let n = r - t;
            if (n > 0) {
                x++;
                if (t > C) {
                    C = t;
                }
            } else if (t < w) {
                w = t;
            }
            if (o.tuyet && n > 0.02 && n < 0.05 + 0.09 * l(Y.i * 5 + e, Y.bang, s + 49)) {
                S = Math.max(S, 1 - (n - 0.02) / 0.14);
            }
            if (n > -0.04 && n < 0.022) {
                b = Math.max(b, 1 - Math.abs(n + 0.009) / 0.031);
            } else if (n >= 0.022 && n < 0.1) {
                y *= 1.16;
            } else if (n <= -0.04 && n > -0.16) {
                y *= 0.88;
            }
        }
        y *= 0.86 + 0.28 * l(Y.i * 13 + x, Y.bang, s + 46);
        if (o.tron) {
            let e = g((r - C) / Math.max(0.05, w - C));
            let t = Math.abs(2 * p - 1);
            let n = Math.abs(2 * e - 1);
            let i = Math.max(t, n) ** 3 * 0.5 + (t * n) ** 1.5 * 0.5;
            y *= (1 - o.tron * 0.42 * i) * (1 + o.tron * 0.22 * h(0.72, 0.95, e) * (1 - t)) * (1 - o.tron * 0.25 * (1 - h(0, 0.2, e)));
        }
        if (Math.abs(d(t * 5.5 + Y.i * 1.3, r * 0.9, s + 45) - 0.5) < 0.02) {
            b = Math.max(b, 0.6);
        }
        let D = 1 - h(0, 0.075, Math.min(p, 1 - p) * Y.w);
        b = Math.max(b, D * 0.95);
        if (f < 0.14) {
            y *= 0.7 + 2.1 * f;
        }
        X.r = o.vach[0] * y;
        X.g = o.vach[1] * y;
        X.b = o.vach[2] * y;
        if (o.loang) {
            let e = o.loang;
            let t = l(Y.i * 13 + x, Y.bang, s + 97) - 0.5;
            X.r *= 1 + e * 0.22 * t;
            X.g *= 1 + e * 0.1 * t;
            X.b *= 1 - e * 0.1 * t;
        }
        if (gn.anh) {
            let e = 0.16 + 0.16 * d(t * 2.7, a * 0.3, s + 49) + 0.06 * l(Y.i, 11, s + 50);
            if (r > i - e) {
                let n = (0.72 + 0.22 * h(i - e, i, r)) * (0.9 + 0.2 * d(t * 9, r * 9, s + 51)) * (0.75 + 0.25 * _);
                X.r = o.mat[0] * n;
                X.g = o.mat[1] * n;
                X.b = o.mat[2] * n;
            } else {
                if (r > i - e - 0.07) {
                    $(0.6);
                }
            }
        }
        if (o.chong && i > 1.2) {
            let e = o.chong.cach;
            let n = Math.floor(t / e);
            let c = t - n * e;
            let u = Math.floor(a / 5);
            let p = (e)=>l(e, u, s + 61) < 0.72;
            let m = 0.2;
            let h = o.chong.go;
            let g = 0.88 + 0.2 * d(t * 22, r * 1.6, s + 62);
            let _ = r > i - 0.46 && r < i - 0.22 && p(n) && p(n + 1);
            if (p(n) && c < m && r < i - 0.12) {
                let e = c / m;
                let t = (e < 0.3 ? 1.18 : e > 0.72 ? 0.62 : 0.96) * g * (0.72 + 0.28 * Math.min(1, f * 2));
                X.r = h[0] * t;
                X.g = h[1] * t;
                X.b = h[2] * t;
            } else if (_) {
                let e = (r - (i - 0.46)) / 0.24;
                let t = (e > 0.72 ? 1.2 : e < 0.25 ? 0.62 : 0.95) * g;
                X.r = h[0] * t;
                X.g = h[1] * t;
                X.b = h[2] * t;
            } else {
                if (p(n) && c >= m && c < 0.29000000000000004 && r < i - 0.12) {
                    $(0.68);
                } else if (r > i - 0.54 && r <= i - 0.46 && p(n) && p(n + 1)) {
                    $(0.7);
                }
            }
        }
        let O = h(i - 0.12, i - 0.02, r);
        if (O > 0) {
            Q(o.vien[0] * m, o.vien[1] * m, o.vien[2] * m, O * 0.85);
        }
        if (b > 0) {
            Q(o.khe[0], o.khe[1], o.khe[2], b);
        }
        if (o.mach) {
            let e = 0.036 * o.mach.mat;
            let n = Math.abs(d(t * 1.4 + r * 0.9, r * 2.2 - t * 0.3, s + 47) - 0.5);
            if (n < e) {
                let t = 1 - n / e;
                X.r += o.mach.mau[0] * t;
                X.g += o.mach.mau[1] * t;
                X.b += o.mach.mau[2] * t;
            }
        }
        if (o.tuNhien && o.reu) {
            let e = o.reu.mau;
            for(let n = 0; n < E; n++){
                let a = i * (T > 1 ? (n + 0.6 + (l(Y.i * 7 + n, Y.bang, s + 43) - 0.5) * 0.6) / (E + 0.6) : i > 3.6 ? (n + 0.3 + 0.5 * l(Y.i * 7 + n, Y.bang, s + 43)) / E : 0.2 + 0.62 * l(Y.i * 7 + n, Y.bang, s + 43)) + (p - 0.5) * 0.2 * (l(Y.i, n, s + 44) - 0.5);
                let o = r - a;
                if (o > 0.02 && o < 0.09 && d(t * 5, a * 3, s + 181) > 0.45) {
                    Q(e[0] * 1.15, e[1] * 1.15, e[2], 0.75);
                    break;
                }
            }
            let n = h(0.66, 0.74, d(t * 2.2, a * 0.05, s + 182));
            if (n > 0) {
                let o = i * (0.25 + 0.6 * d(t * 0.9, a * 0.07, s + 183));
                let c = i - r;
                if (c < o) {
                    let i = (0.55 + 0.5 * l(Math.floor(t * 16), Math.floor(r * 14), s + 184)) * (1 - c / o * 0.35);
                    Q(e[0] * i, e[1] * i * 1.08, e[2] * i, n * (1 - h(0.75, 1, c / o)) * 0.9);
                }
            }
            let c = h(0.62, 0.78, d(t * 1.3, r * 1.6 + a, s + 185));
            if (c > 0) {
                Q(e[0] * 0.8, e[1] * 0.85, e[2] * 0.7, c * 0.55);
            }
            if (r > i - (0.12 + 0.12 * d(t * 4, a, s + 186))) {
                Q(e[0] * 1.25, e[1] * 1.25, e[2] * 1.1, 0.85);
            }
        }
        if (o.tuyet) {
            let e = (0.08 + 0.22 * d(t * 2.4, a, s + 48)) * o.tuyet;
            if (r > i - e) {
                let t = 0.9 + 0.12 * (1 - p);
                Q(232 * t, 238 * t, 248 * t, h(i - e, i - e + 0.05, r));
            }
            if (S > 0 && b < 0.5) {
                let e = 0.86 + 0.14 * (1 - p);
                Q(226 * e, 233 * e, 246 * e, Math.min(1, S * 1.6) * o.tuyet);
            }
            let n = d(t * 1.7 + Y.i * 0.7, r * 2.6 + a * 0.3, s + 50);
            if (n > 0.8 - 0.12 * o.tuyet && b < 0.5) {
                Q(214, 223, 238, h(0.8 - 0.12 * o.tuyet, 0.86 - 0.12 * o.tuyet, n) * 0.75 * o.tuyet);
            }
            let c = (0.1 + 0.16 * d(t * 0.9, a * 0.5, s + 51)) * o.tuyet;
            if (r < c) {
                Q(196, 208, 230, h(c, c - 0.05, r) * 0.92);
            }
        }
    }
    let xn = 0.35;
    let Sn = 1.4;
    function Cn(e, t, n, r, i, a, o) {
        let s = r.y1 - r.y0;
        let c = r.x1 - r.x0;
        let u = Math.min(0.46, Math.max(0.26, c * 0.1));
        let f = u + (s > 3 ? Math.min(0.75, c * 0.15) * h(0, 1, (s - 3) / 3) : 0) * (1 - Math.min(1, Math.max(0, (n - r.y0) / s)));
        let p = Bt(e.da, t * 1.3 + 2.3, n * 1.3, o) * (i.hat ?? 0.35);
        if (n > r.y1) {
            let e = n - r.y1;
            let o = t >= r.x0 + u && t <= r.x1 - u;
            if (o && e < 0.3) {
                let t = (e < 0.22 ? 0.98 + e / 0.22 * 0.1 : 0.5) * (1 + p * 0.8);
                X.r = i.mat[0] * t;
                X.g = i.mat[1] * t;
                X.b = i.mat[2] * t;
                if (e > 0.18 && e < 0.22) {
                    Q(i.vien[0], i.vien[1], i.vien[2], 0.45);
                }
                return;
            }
            if (!o && t >= r.x0 - 0.06 && t <= r.x1 + 0.06 && e < 0.25) {
                let n = (t < r.x0 + u ? 0.62 : 0.5) * (1 - e / 0.25 * 0.25) * (1 + p);
                X.r = i.vach[0] * n;
                X.g = i.vach[1] * n;
                X.b = i.vach[2] * n;
                return;
            }
            let s = 1 - h(0, 0.45, Math.max(r.x0 - 0.1 - t, t - r.x1 - 0.1, 0));
            let c = (1 - h(0, Sn, e + (d(t * 2, n * 2, a + 171) - 0.5) * 0.25)) * 0.55 * s;
            if (c > 0) {
                $(1 - c);
            }
            return;
        }
        if (t < r.x0 || t > r.x1) {
            let e = t < r.x0 ? r.x0 - t : t - r.x1;
            $(1 - 0.5 * (1 - h(0, 0.07, e)) - 0.14 * (1 - h(0.07, xn, e)));
            return;
        }
        let m = s > 4;
        let g = Math.max(2, Math.round(s / 0.36));
        let _ = m ? g + 1 : g;
        s / _;
        let v = (n - r.y0) / s;
        let y = (1.33 * v - 0.33 * v * v) * _;
        let b = Math.floor(g / 2);
        let x;
        let S;
        let C = 0.55;
        if (m && y >= b && y < b + 2) {
            x = b;
            S = (y - b) / 2;
            C = 0.78;
        } else if (m && y >= b + 2) {
            x = Math.min(g - 1, Math.floor(y - 1));
            S = y - 1 - x;
        } else {
            x = Math.min(g - 1, Math.floor(y));
            S = y - x;
        }
        let w = 1.14 - 0.46 * h(0.04, 1, v);
        let T;
        let E;
        let D;
        let O = t < r.x0 + f;
        let k = t > r.x1 - f;
        let A = r.y1 - n;
        if ((O || k) && A < 0.95) {
            let e = O ? (t - r.x0) / f : (r.x1 - t) / f;
            if (A > 0.72) {
                let t = (1.12 + 0.12 * (1 - h(0.75, 0.85, A))) * (0.9 + 0.12 * e) * (1 + p);
                T = i.mat[0] * t;
                E = i.mat[1] * t;
                D = i.mat[2] * t;
                if (A < 0.76) {
                    Q(i.vien[0], i.vien[1], i.vien[2], 0.55);
                }
            } else {
                let t = (O ? 0.7 : 0.58) * (0.82 + A / 0.72 * 0.25) * (0.85 + 0.15 * e) * (1 + p);
                T = i.vach[0] * t;
                E = i.vach[1] * t;
                D = i.vach[2] * t;
                if (Math.abs(A / 0.36 % 1) < 0.07) {
                    T *= 0.7;
                    E *= 0.7;
                    D *= 0.7;
                }
            }
            if (e < 0.1 || A > 0.92) {
                T *= 0.6;
                E *= 0.6;
                D *= 0.6;
            }
            X.r = T;
            X.g = E;
            X.b = D;
        } else {
            if (O || k) {
                let e = O ? (t - r.x0) / f : (r.x1 - t) / f;
                let o = Math.floor((n - r.y0) / 0.7);
                let s = (O ? 0.98 : 0.86) * (0.78 + 0.3 * e) * (1 + p) * (0.9 + 0.2 * l(o, O ? 1 : 2, a + 161)) * (0.6 + 0.4 * w);
                T = i.mat[0] * s;
                E = i.mat[1] * s;
                D = i.mat[2] * s;
                if (Math.abs((n - r.y0) / 0.7 % 1) < 0.05) {
                    T *= 0.58;
                    E *= 0.58;
                    D *= 0.58;
                }
                if (e > 0.86) {
                    let t = (e - 0.86) / 0.14 * 0.45;
                    T += (i.vien[0] - T) * t;
                    E += (i.vien[1] - E) * t;
                    D += (i.vien[2] - D) * t;
                }
                if (e < 0.12) {
                    T *= 0.62;
                    E *= 0.62;
                    D *= 0.62;
                }
                if (i.reu && d(t * 3, n * 1.6, a + 166) > 0.7) {
                    let e = 0.5;
                    T += (i.reu.mau[0] * 0.8 - T) * e;
                    E += (i.reu.mau[1] * 0.8 - E) * e;
                    D += (i.reu.mau[2] * 0.8 - D) * e;
                }
            } else if (S < C) {
                let e = S / C;
                let n = 0.55 + 0.35 * l(x, 5, a + 162);
                let o = (t - r.x0 + l(x, 6, a + 163) * n) / n;
                let s = Math.floor(o);
                let u = o - s;
                let d = 1 - Math.abs((t - (r.x0 + r.x1) / 2) / (c / 2));
                let f = (0.94 + 0.2 * e + 0.08 * d) * (0.9 + 0.16 * l(s, x, a + 164)) * (1 + p * 0.55) * w;
                T = i.mat[0] * f * 1.07;
                E = i.mat[1] * f * 1.05;
                D = i.mat[2] * f * 1.02;
                if (u < 0.04 || u > 0.96) {
                    T *= 0.62;
                    E *= 0.62;
                    D *= 0.62;
                    if (i.reu && l(s, x, a + 165) < 0.5) {
                        T = i.reu.mau[0] * 0.8;
                        E = i.reu.mau[1] * 0.8;
                        D = i.reu.mau[2] * 0.8;
                    }
                }
                if (e > 0.84) {
                    let t = h(0.84, 0.97, e) * 0.7;
                    T += (i.vien[0] * 1.08 - T) * t;
                    E += (i.vien[1] * 1.08 - E) * t;
                    D += (i.vien[2] * 1.05 - D) * t;
                }
                if (e < 0.16) {
                    let t = 0.55 + 0.45 * h(0, 0.16, e);
                    T *= t;
                    E *= t;
                    D *= t;
                }
            } else {
                let e = (S - C) / (1 - C);
                let t = (0.62 - 0.22 * e) * (1 + p * 0.6) * (0.7 + 0.3 * w);
                T = i.vach[0] * t;
                E = i.vach[1] * t;
                D = i.vach[2] * t;
                let n = 0.12 + 0.22 * e;
                T += (i.khe[0] - T) * n;
                E += (i.khe[1] - E) * n;
                D += (i.khe[2] - D) * n;
                if (e < 0.14) {
                    T *= 0.62;
                    E *= 0.62;
                    D *= 0.62;
                }
            }
            if (!O && !k) {
                let e = t - (r.x0 + f);
                let n = r.x1 - f - t;
                let a = S < C;
                let o = 0.16 + 0.75 * ((x + 0.5) / g) * Math.min(1, (c - 2 * f) / 3) + (a ? S / C * 0.1 : 0.1 + 0.3 * ((S - C) / (1 - C)));
                if (e < 0.1) {
                    T *= 0.46;
                    E *= 0.46;
                    D *= 0.5;
                } else if (e < o) {
                    let t = 0.62 + 0.08 * h(o - 0.06, o, e);
                    T *= t;
                    E *= t * 1.01;
                    D *= t * 1.04;
                }
                if (n < 0.07) {
                    let e = 0.4;
                    T += (i.vien[0] - T) * e;
                    E += (i.vien[1] - E) * e;
                    D += (i.vien[2] - D) * e;
                } else if (n < 0.2) {
                    let e = 1 - 0.12 * (1 - h(0.07, 0.2, n));
                    T *= e;
                    E *= e;
                    D *= e;
                }
            }
            X.r = T;
            X.g = E;
            X.b = D;
        }
    }
    let wn = {
        tr: null,
        o: 0,
        k: new Int32Array(4096),
        v: new Float32Array(4096)
    };
    function Tn(e, t, n, r, i, a) {
        if (wn.tr !== e || wn.o !== t) {
            wn.tr = e;
            wn.o = t;
            wn.k.fill(-1);
        }
        let o = (n * 73856093 ^ r * 19349663) & 4095;
        let s = (n & 65535) * 65536 + (r & 65535);
        if (wn.k[o] === s) {
            return wn.v[o];
        }
        let c = M(e, e.kRung, i, a);
        wn.k[o] = s;
        wn.v[o] = c;
        return c;
    }
    function En(e, t, n, r, i, a, o) {
        let s = o.o;
        let c = o.vuon ?? 0.45;
        let f = o.bien ?? 0;
        let p = Math.floor(t / s);
        let _ = Math.floor(n / s);
        let v = -1000000000;
        let y = 0;
        let b = 0;
        let x = 0;
        let S = 0;
        let C = 0;
        let w = 0;
        for(let r = _ - 1; r <= _ + 2; r++){
            for(let i = p - 1; i <= p + 1; i++){
                let o = l(i, r, a + 141);
                let f = (i + 0.5 + (o - 0.5) * 0.8) * s;
                let p = (r + 0.5 + (u(i, r, a + 142) - 0.5) * 0.8) * s;
                if (p <= v) {
                    continue;
                }
                let m = Tn(e, s, i, r, f, p);
                let h = Math.min(s * (0.68 + 0.3 * l(r, i, a + 143)), m + c);
                if (h < s * 0.3) {
                    continue;
                }
                let g = p - h * 0.35;
                let _ = t - f;
                let T = (n - g) * 1.08;
                let E = Math.hypot(_, T);
                let D = h * (0.9 + 0.2 * d(t * 2.6 + i, n * 2.6 + r, a + 144));
                if (E < D) {
                    v = p;
                    y = _ / D;
                    b = T / D;
                    x = o;
                    S = E / D;
                    C = i;
                    w = r;
                }
            }
        }
        let T;
        let E;
        let D;
        let O;
        if (v > -1000000000) {
            let e = Math.min(1, y * y + b * b);
            let i = Math.sqrt(1 - e);
            let s = Math.max(0, -0.5 * y - 0.62 * b + 0.6 * i);
            m(t / 0.34, n / 0.3, a + 145, 0.9, 1, J);
            let c = l(J.i, J.j, a + 146);
            let d = t / 0.34 - J.px;
            let p = n / 0.3 - J.py;
            let _ = Math.max(0.001, Math.hypot(d, p));
            let v = (1 - h(0.04, 0.3, J.d2 - J.d1)) * ((d * Ht + p * Ut) / _);
            let k = g(s * (0.85 + 0.3 * c) + v * 0.18, 0, 1.2);
            let A = h(0.78, 1, Math.sqrt(e));
            T = o.toi[0] + (o.tan[0] - o.toi[0]) * k;
            E = o.toi[1] + (o.tan[1] - o.toi[1]) * k;
            D = o.toi[2] + (o.tan[2] - o.toi[2]) * k;
            if (k > 0.85) {
                let e = h(0.85, 1.15, k);
                T += (o.sang[0] - T) * e;
                E += (o.sang[1] - E) * e;
                D += (o.sang[2] - D) * e;
            }
            let j = (1 - 0.45 * A) * (0.92 + 0.16 * x);
            T *= j;
            E *= j;
            D *= j;
            if (f > 0) {
                let e = (u(w, C, a + 147) - 0.5) * 2 * f;
                if (e > 0) {
                    T *= 1 + 0.32 * e;
                    E *= 1 + 0.12 * e;
                    D *= 1 - 0.25 * e;
                } else {
                    T *= 1 + 0.25 * e;
                    E *= 1 + 0.08 * e;
                    D *= 1 - 0.1 * e;
                }
            }
            O = 1 - h(0.93, 1, S);
            if (r > 0.5) {
                O = Math.max(O, h(0.42, 0.58, r));
            }
        } else {
            let i = 0.62;
            m(t / i, n / (i * 0.85), a + 148, 0.85, 1, J);
            let s = J.px * i;
            let u = J.py * i * 0.85;
            let d = Tn(e, -0.62, J.i, J.j, s, u);
            let f = Math.min(i * (0.62 + 0.25 * l(J.i, J.j, a + 149)), d + c);
            let p = Math.hypot(t - s, (n - u + f * 0.25) * 1.1);
            if (f > 0.18 && p < f) {
                let e = (t - s) / f;
                let i = (n - u + f * 0.25) * 1.1 / f;
                let c = Math.min(1, e * e + i * i);
                let d = g(Math.max(0, -0.5 * e - 0.62 * i + 0.6 * Math.sqrt(1 - c)) * (0.8 + 0.4 * l(J.j, J.i, a + 150)), 0, 1.15);
                T = o.toi[0] + (o.tan[0] - o.toi[0]) * d;
                E = o.toi[1] + (o.tan[1] - o.toi[1]) * d;
                D = o.toi[2] + (o.tan[2] - o.toi[2]) * d;
                if (d > 0.9) {
                    let e = h(0.9, 1.15, d) * 0.7;
                    T += (o.sang[0] - T) * e;
                    E += (o.sang[1] - E) * e;
                    D += (o.sang[2] - D) * e;
                }
                let m = 1 - 0.4 * h(0.75, 1, Math.sqrt(c));
                T *= m;
                E *= m;
                D *= m;
                O = 1 - h(0.9, 1, p / f);
                if (r > 0.5) {
                    O = Math.max(O, h(0.42, 0.58, r));
                }
            } else {
                T = o.nen[0];
                E = o.nen[1];
                D = o.nen[2];
                O = h(0.45, 0.62, r);
            }
        }
        if (O > 0.5) {
            let e = l(Math.floor(t * 11), Math.floor(n * 11), a + 151);
            let r = (T + E + D) / (o.tan[0] + o.tan[1] + o.tan[2] + 1);
            if (e < 0.16 * r) {
                T = T * 0.6 + o.sang[0] * 0.4;
                E = E * 0.6 + o.sang[1] * 0.4;
                D = D * 0.6 + o.sang[2] * 0.4;
            } else if (e > 1 - 0.2 * (1.2 - r)) {
                T *= 0.72;
                E *= 0.74;
                D *= 0.74;
            }
        }
        Q(T, E, D, O);
    }
    function Dn(e, t, n, r, i, a, o, s, c, lat, u = 1, d = 16777215) {
        let f = 64 / n / c;
        let p = (d >> 16 & 255) / 255;
        let m = (d >> 8 & 255) / 255;
        let h = (d & 255) / 255;
        let g = a.w / 64 * c;
        let _ = a.h / 64 * c;
        let v = Math.floor((o - g / 2 - r) * n);
        let y = Math.floor((s - _ - i) * n);
        let b = Math.ceil(g * n);
        let x = Math.ceil(_ * n);
        for(let n = Math.max(0, y); n < Math.min(t, y + x); n++){
            for(let r = Math.max(0, v); r < Math.min(t, v + b); r++){
                let i = Math.floor((r - v + 0.5) * f);
                let o = Math.floor((n - y + 0.5) * f);
                if (i >= a.w || o >= a.h) {
                    continue;
                }
                if (lat) {
                    i = a.w - 1 - i;
                }
                let s = (o * a.w + i) * 4;
                let c = a.d[s + 3] / 255 * u;
                if (c <= 0.01) {
                    continue;
                }
                let d = (n * t + r) * 4;
                e[d] = e[d] + (a.d[s] * p - e[d]) * c;
                e[d + 1] = e[d + 1] + (a.d[s + 1] * m - e[d + 1]) * c;
                e[d + 2] = e[d + 2] + (a.d[s + 2] * h - e[d + 2]) * c;
            }
        }
    }
    let On = P();
    function kn(e, t, n) {
        if (e.da[n] >= 0.5) {
            let r = e.xuong[n];
            let i = -e.len[n];
            let a = r + Math.max(0, i);
            if (e.the[n]) {
                let t = ie(e, n);
                if (t > 0) {
                    return Math.min(a, t);
                }
                return a;
            }
            let o = n % e.W;
            let s = n / e.W | 0;
            let c = (o + 0.5) / 4;
            let l = (s + 0.5) / 4;
            re(e, t.da, c, l + r, On);
            return ae(On, a, false);
        }
        if (e.rung && e.rung[n] >= 0.5) {
            return Math.min(t.rung?.cao ?? 5, 1.2 + 2.2 * Math.max(0, e.kRung?.[n] ?? 9));
        }
        return 0;
    }
    function An(e, t, n) {
        let { W, H } = e;
        let a = W * H;
        let e_tang = e.tang;
        let s = new Float32Array(a);
        let c = e_tang ? new Float32Array(a) : s;
        let l = e_tang ? new Float32Array(a) : null;
        let u = 0;
        for(let n = 0; n < a; n++){
            let r = kn(e, t, n);
            s[n] = r;
            if (e_tang) {
                let t = e_tang[n];
                c[n] = r > 0 ? t + r : t;
                l[n] = r > 0 && e.the[n] && e.xuong[n] < r ? t + e.xuong[n] : r > 0 ? -1 : t;
            }
            if (c[n] > u) {
                u = c[n];
            }
        }
        let d = -n * 0.95 + 0.12;
        let f = 0.55 + 0.25 * (1 - Math.abs(n));
        let p = Math.hypot(d, f);
        let m = d / p;
        let h = f / p;
        let g = 0.42 + 0.6 * Math.abs(n);
        let _ = 1 / 4;
        let v = new Float32Array(a);
        for(let e = 0; e < H; e++){
            for(let t = 0; t < W; t++){
                let n = e * W + t;
                let a = 0;
                let o = false;
                if (l) {
                    a = l[n];
                    if (a < 0) {
                        continue;
                    }
                    o = s[n] > 0;
                } else if (s[n] > 0) {
                    continue;
                }
                let d = (u - a) * g;
                let f = 0;
                let p = !o;
                for(let n = _ * 0.5; n <= d; n += _){
                    let o = Math.round(t - m * n * 4);
                    let l = Math.round(e - h * n * 4);
                    if (o < 0 || l < 0 || o >= W || l >= H) {
                        break;
                    }
                    let u = l * W + o;
                    if (!p) {
                        if (s[u] > 0) {
                            continue;
                        }
                        p = true;
                    }
                    let d = (c[u] - a) * g;
                    if (d <= 0) {
                        continue;
                    }
                    let _ = Math.min(1, (d - n) / 0.5 + 0.5);
                    if (_ > f && (f = _, f >= 1)) {
                        break;
                    }
                }
                v[n] = Math.max(0, f);
            }
        }
        let y = new Uint8Array(a);
        let b = t.bong.dam * 255;
        for(let e = 0; e < H; e++){
            for(let t = 0; t < W; t++){
                let n = 0;
                let a = 0;
                for(let o = -1; o <= 1; o++){
                    for(let s = -1; s <= 1; s++){
                        let c = t + s;
                        let l = e + o;
                        if (!(c < 0 || l < 0 || c >= W || l >= H)) {
                            n += v[l * W + c];
                            a++;
                        }
                    }
                }
                let o = e * W + t;
                y[o] = (l ? l[o] < 0 : s[o] > 0) ? 0 : Math.round(n / a * b);
            }
        }
        return y;
    }
    function jn(t, n = 3000, r) {
        let i = e(t.seed + 555);
        let a = {
            nuoc: [],
            bo: [],
            rung: [],
            dat: []
        };
        let o = r?.da.mach;
        if (o?.den) {
            a.mach = Mn(t, r, o.den.cach);
        }
        let s = {
            nuoc: 0,
            bo: 0,
            rung: 0,
            dat: 0,
            ruong: 0
        };
        let c = [];
        let l = !!(r?.ruong && !r.ruong.kho && t.ruong && t.kRuong);
        if (l) {
            a.ruong = [];
        }
        for(let e = 1; e < t.cao - 1; e++){
            for(let n = 1; n < t.rong - 1; n++){
                let r = n + i.next();
                let a = e + i.next();
                if (t.kNuoc) {
                    let e = M(t, t.kNuoc, r, a);
                    if (e > 0.35) {
                        c.push([
                            `nuoc`,
                            r,
                            a
                        ]);
                        s.nuoc++;
                        continue;
                    }
                    if (e > -0.05) {
                        c.push([
                            `bo`,
                            r,
                            a
                        ]);
                        s.bo++;
                        continue;
                    }
                }
                if (t.kRung) {
                    let e = M(t, t.kRung, r, a);
                    if (e > -0.3 && e < 1.5) {
                        c.push([
                            `rung`,
                            r,
                            a
                        ]);
                        s.rung++;
                        continue;
                    }
                }
                if (l && M(t, t.kRuong, r, a) > 1.2) {
                    c.push([
                        `ruong`,
                        r,
                        a
                    ]);
                    s.ruong++;
                } else if (M(t, t.da, r, a) < 0.3) {
                    c.push([
                        `dat`,
                        r,
                        a
                    ]);
                    s.dat++;
                }
            }
        }
        if (t.kRung && r?.rung && (r.dong?.tan ?? 1) > 0) {
            a.tan = Nn(t, n);
        }
        if (t.kNuoc && r?.nuoc && ((r.nuoc.daBo ?? 0) > 0 || (r.nuoc.daGiua ?? 0) > 0)) {
            a.daNuoc = Pn(t, r);
        }
        for (let [e, r, o] of c){
            let c = n / Math.max(1, s[e]);
            if (c >= 1 || i.next() < c) {
                (a[e] ??= []).push(+r.toFixed(2), +o.toFixed(2));
                if (e === `nuoc`) {
                    a.nuoc.push(t.chayX ? +N(t, t.chayX, r, o).toFixed(2) : 0.3, t.chayY ? +N(t, t.chayY, r, o).toFixed(2) : 0.1);
                }
            }
        }
        return a;
    }
    function Mn(e, { da }, cach) {
        let da_mach = da.mach;
        let e_seed = e.seed;
        let o = P();
        let s = [];
        let c = new Map;
        let l = 0.036 * da_mach.mat * 0.5;
        let u = (e, t)=>Math.floor(e / cach) * 65536 + Math.floor(t / cach);
        for(let t = 0; t < e.H; t++){
            for(let i = 0; i < e.W; i++){
                let f = t * e.W + i;
                if (e.da[f] < 0.5 || e.the[f]) {
                    continue;
                }
                let p = e.xuong[f];
                if (p > da.cao[1]) {
                    continue;
                }
                let m = (i + 0.5) / 4;
                let h = (t + 0.5) / 4;
                let g = Math.max(0, -e.len[f]);
                re(e, da, m, h + p, o);
                if (p >= ae(o, p + g, false) - 0.1 || p < 0.15 || Math.abs(d(m * 1.4 + p * 0.9, p * 2.2 - m * 0.3, e_seed + 47) - 0.5) > l) {
                    continue;
                }
                let _ = false;
                for(let e = -1; e <= 1 && !_; e++){
                    for(let t = -1; t <= 1 && !_; t++){
                        for (let [r, i] of c.get(u(m + e * cach, h + t * cach)) ?? []){
                            if ((r - m) ** 2 + (i - h) ** 2 < cach * cach) {
                                _ = true;
                                break;
                            }
                        }
                    }
                }
                if (_) {
                    continue;
                }
                let v = u(m, h);
                (c.get(v) ?? c.set(v, []).get(v)).push([
                    m,
                    h
                ]);
                s.push(+m.toFixed(2), +h.toFixed(2));
            }
        }
        return s;
    }
    function Nn(t, n) {
        let r = e(t.seed + 556);
        let i = [];
        for(let e = 1; e < t.cao - 1; e += 1.5){
            for(let n = 1; n < t.rong - 1; n += 1.5){
                let a = n + r.next() * 1.5;
                let o = e + r.next() * 1.5;
                if (M(t, t.kRung, a, o) >= 1.5) {
                    i.push(+a.toFixed(2), +o.toFixed(2));
                }
            }
        }
        if (i.length / 2 <= n) {
            return i;
        }
        let a = Math.ceil(i.length / 2 / n);
        let o = [];
        for(let e = 0; e < i.length; e += 2 * a){
            o.push(i[e], i[e + 1]);
        }
        return o;
    }
    function Pn(e, { nuoc }) {
        let e_seed = e.seed;
        let i = [];
        for (let t of [
            true,
            false
        ]){
            let a = t ? (nuoc.daGiua ?? 0) * 0.3 : nuoc.daBo ?? 0;
            if (a <= 0) {
                continue;
            }
            let o = t ? 1.7 : 0.8;
            let s = e_seed + (t ? 171 : 172);
            for(let n = 0; n < e.cao / (o * 0.8); n++){
                for(let c = 0; c < e.rong / o; c++){
                    let f = (c + 0.5 + (l(c, n, s) - 0.5) * 0.85) * o;
                    let p = (n + 0.5 + (u(c, n, s) - 0.5) * 0.85) * o * 0.8;
                    if (f < 0.5 || p < 0.5 || f > e.rong - 0.5 || p > e.cao - 0.5) {
                        continue;
                    }
                    let m = t ? a : a * h(0.3, 0.62, d(f / 4.5, p / 4.5, e_seed + 174));
                    if (u(c, n, e_seed + 175) > m) {
                        continue;
                    }
                    let g = M(e, e.kNuoc, f, p);
                    if (t ? g < 1 : g < 0 || g > 0.45) {
                        continue;
                    }
                    let _ = l(c, n, e_seed + 173);
                    let v = t ? 0.26 + 0.26 * _ : 0.2 + 0.28 * _;
                    let y = e.chayX ? N(e, e.chayX, f, p) : 0.3;
                    let b = e.chayY ? N(e, e.chayY, f, p) : 0.1;
                    i.push(+f.toFixed(2), +p.toFixed(2), +v.toFixed(2), +y.toFixed(2), +b.toFixed(2));
                }
            }
        }
        return i;
    }
    let Fn = self;
    let In = null;
    let Ln = null;
    let Rn = null;
    let zn = [];
    let Bn;
    let Vn = (e, t)=>{
        let n = jt(e);
        if (n) {
            return yt(n, t, At(e));
        }
    };
    let Hn = (e)=>{
        if (Ln?.do[e.loai]?.bien) {
            return e.tong;
        }
        return 16777215;
    };
    async function Un(e) {
        let t = await fetch(e);
        if (!t.ok) {
            throw Error(`tải ${e}: ${t.status}`);
        }
        let n = await createImageBitmap(await t.blob());
        let r = new OffscreenCanvas(n.width, n.height);
        let i = r.getContext(`2d`, {
            willReadFrequently: true
        });
        i.drawImage(n, 0, 0);
        n.close();
        return {
            w: r.width,
            h: r.height,
            d: i.getImageData(0, 0, r.width, r.height).data
        };
    }
    let Wn = null;
    let Gn = false;
    let Kn = ``;
    let qn = 0;
    let Jn = new Map;
    let Yn = (e)=>{
        let t = Jn.get(e);
        if (!t) {
            t = Un(e);
            Jn.set(e, t);
            t.catch(()=>Jn.delete(e));
        }
        return t;
    };
    Fn.onmessage = (e)=>{
        let e_data = e.data;
        try {
            if ((e_data.loai === `dung` || e_data.loai === `dungTruoc`) && e_data.z) {
                i([
                    e_data.z
                ]);
            }
            if (e_data.loai === `dung`) {
                Gn = true;
                ir(e_data);
                return;
            }
            if (e_data.loai === `truong`) {
                sr(e_data);
                return;
            }
            if (e_data.loai === `dungTruoc`) {
                if (e_data.phu && Gn) {
                    return;
                }
                for (let e of Object.values(e_data.anh ?? {})){
                    Yn(e).catch(()=>{});
                }
                rr(e_data.vung, e_data.z, !!e_data.phu, e_data.dh2).then(()=>{
                    if (e_data.nong && !ar && !Gn) {
                        let e = Vn(e_data.vung, e_data.dh2);
                        if (e) {
                            or(e);
                        }
                    }
                });
                return;
            }
            if (e_data.loai === `nghi`) {
                In = null;
                Ln = null;
                Rn = null;
                zn = [];
                qn = -1;
                return;
            }
            if (!In || !Ln || !Rn) {
                Fn.postMessage({
                    loai: `loi`,
                    id: e_data.id,
                    msg: `chưa dựng`
                });
                return;
            }
            let e = performance.now();
            if (e_data.loai === `manh`) {
                let n = Math.round(e_data.canh * e_data.P);
                let r = tn(In, Rn, Ln, e_data.x0, e_data.y0, e_data.canh, e_data.P);
                for (let e of zn){
                    let i = e.a.w / 64 * e.k;
                    let a = e.a.h / 64 * e.k;
                    if (!(e.x + i / 2 < e_data.x0 || e.x - i / 2 > e_data.x0 + e_data.canh || e.y < e_data.y0 || e.y - a > e_data.y0 + e_data.canh)) {
                        Dn(r, n, e_data.P, e_data.x0, e_data.y0, e.a, e.x, e.y, e.k, e.lat, 0.95, Hn(e));
                    }
                }
                Fn.postMessage({
                    loai: `manh`,
                    id: e_data.id,
                    px: r.buffer,
                    ms: performance.now() - e
                }, [
                    r.buffer
                ]);
            } else if (e_data.loai === `bong`) {
                let n = An(In, Ln, e_data.k);
                Fn.postMessage({
                    loai: `bong`,
                    id: e_data.id,
                    px: n.buffer,
                    W: In.W,
                    H: In.H,
                    ms: performance.now() - e
                }, [
                    n.buffer
                ]);
            } else if (e_data.loai === `toan`) {
                let w_1 = Math.ceil(In.rong * e_data.P);
                let h_1 = Math.ceil(In.cao * e_data.P);
                let i = new Uint8ClampedArray(w_1 * h_1 * 4);
                let a = 16 * e_data.P;
                for(let e = 0; e < In.cao; e += 16){
                    for(let o = 0; o < In.rong; o += 16){
                        let s = tn(In, Rn, Ln, o, e, 16, e_data.P);
                        for(let c = 0; c < a; c++){
                            let l = Math.round(e * e_data.P) + c;
                            if (l >= h_1) {
                                break;
                            }
                            let u = Math.round(o * e_data.P);
                            let d = Math.min(a, w_1 - u);
                            i.set(s.subarray(c * a * 4, (c * a + d) * 4), (l * w_1 + u) * 4);
                        }
                    }
                }
                Fn.postMessage({
                    loai: `toan`,
                    id: e_data.id,
                    px: i.buffer,
                    w: w_1,
                    h: h_1,
                    ms: performance.now() - e
                }, [
                    i.buffer
                ]);
            }
        } catch (error) {
            Fn.postMessage({
                loai: `loi`,
                id: e_data.id,
                msg: String(error)
            });
        }
    };
    function Xn(e, t, n) {
        let r = (e)=>{
            let n = t.get(e);
            if (!n) {
                throw Error(`thiếu ảnh ${e}`);
            }
            return n;
        };
        let them = {};
        for (let n of Mt(e)){
            let e = t.get(n);
            if (e) {
                them[n] = e;
            }
        }
        Rn = {
            nenA: r(e.nen[0]),
            nenB: r(e.nen[1]),
            da: r(e.da.anh),
            duong: r(e.duong),
            them
        };
        zn = n.filter((e)=>e.bet && t.has(e.anh)).map((e)=>({
                ...e,
                a: t.get(e.anh)
            }));
    }
    let Zn = `truong`;
    function Qn() {
        return new Promise((resolve)=>{
            try {
                let t = indexedDB.open(`cg_canh_code`, 1);
                t.onupgradeneeded = ()=>{
                    t.result.createObjectStore(Zn);
                };
                t.onsuccess = ()=>resolve(t.result);
                t.onerror = ()=>resolve(null);
                t.onblocked = ()=>resolve(null);
            } catch  {
                resolve(null);
            }
        });
    }
    async function $n(vung, t) {
        let n = await Qn();
        if (n) {
            return new Promise((resolve)=>{
                try {
                    let i = n.transaction(Zn, `readonly`).objectStore(Zn).get(vung);
                    i.onsuccess = ()=>{
                        let i_result = i.result;
                        resolve(i_result && i_result.khoa === t ? i_result : null);
                        n.close();
                    };
                    i.onerror = ()=>{
                        resolve(null);
                        n.close();
                    };
                } catch  {
                    resolve(null);
                    n.close();
                }
            });
        }
        return null;
    }
    async function er(vung, t) {
        let n = await Qn();
        if (n) {
            try {
                let r = n.transaction(Zn, `readwrite`);
                let i = r.objectStore(Zn);
                i.put(t, vung);
                let a = i.getAll();
                let o = i.getAllKeys();
                r.oncomplete = ()=>n.close();
                r.onerror = ()=>n.close();
                o.onsuccess = ()=>{
                    let e = (a.result ?? []).map((e, t)=>({
                            k: o.result[t],
                            luc: e.luc
                        })).sort((e, t)=>t.luc - e.luc);
                    for (let t of e.slice(4)){
                        i.delete(t.k);
                    }
                };
            } catch  {
                n.close();
            }
        }
    }
    function tr(e, t) {
        return String(c(JSON.stringify(e) + JSON.stringify(t) + String(t.loai) + A.toString() + le.toString() + jn.toString()));
    }
    let nr = new Map;
    async function rr(vung, t, n = false, r) {
        let i = Vn(vung, r);
        if (!i) {
            return;
        }
        let a = tr(t, i);
        if (nr.has(a)) {
            return;
        }
        let o = (async ()=>{
            let r = await $n(vung, a);
            if (r) {
                return r;
            }
            if (n && Gn) {
                return null;
            }
            let o = A(t, i);
            let ds = le(o, t, i);
            let c = {
                khoa: a,
                luc: Date.now(),
                tr: o,
                ds,
                diem: jn(o, 3000, i)
            };
            await er(vung, c);
            return c;
        })().catch(()=>null);
        nr.set(a, o);
        if (await o) {
            setTimeout(()=>{
                if (nr.get(a) === o) {
                    nr.delete(a);
                }
            }, 30000);
        } else {
            nr.delete(a);
        }
    }
    async function ir(e) {
        try {
            let t = Vn(e.vung, e.dh2);
            if (!t) {
                throw Error(`không có cấu hình cảnh code ${e.vung}`);
            }
            Kn = e.vung;
            qn = e.phien;
            Bn = e.dh2;
            In = null;
            Ln = null;
            Rn = null;
            zn = [];
            Wn = Promise.all(Object.entries(e.anh).map(async ([e, t])=>[
                    e,
                    await Yn(t)
                ])).then((e)=>new Map(e));
            if (!e.chinh) {
                if (e.congNhan) {
                    e.congNhan.onmessage = (t)=>{
                        sr(t.data);
                        e.congNhan.close();
                    };
                }
                if (!ar) {
                    setTimeout(()=>or(t), 0);
                }
                return;
            }
            let n = tr(e.z, t);
            let r = performance.now();
            let i = await nr.get(n) ?? await $n(e.vung, n);
            let a;
            let ds;
            let diem;
            let c = performance.now();
            if (i) {
                a = i.tr;
                ds = i.ds;
                diem = i.diem;
            } else {
                a = A(e.z, t);
                ds = le(a, e.z, t);
                diem = jn(a, 3000, t);
            }
            let l = performance.now();
            let u = await Wn;
            let d = performance.now();
            if (qn !== e.phien) {
                return;
            }
            Xn(t, u, ds);
            In = a;
            Ln = t;
            Fn.postMessage({
                loai: `san`,
                phien: e.phien,
                chinh: true,
                W: a.W,
                H: a.H,
                dem: !!i,
                ms: {
                    anh: d - l,
                    truong: i ? c - r : l - c,
                    rai: 0
                },
                do: ds.filter((e)=>!e.bet),
                diem
            });
            for (let t of e.cong ?? []){
                t.postMessage({
                    loai: `truong`,
                    tr: a,
                    bet: ds.filter((e)=>e.bet),
                    phien: e.phien
                });
                t.close();
            }
            if (!i) {
                er(e.vung, {
                    khoa: n,
                    luc: Date.now(),
                    tr: a,
                    ds,
                    diem
                });
            }
        } catch (error) {
            Fn.postMessage({
                loai: `loi`,
                msg: String(error)
            });
        }
    }
    let ar = false;
    function or(e) {
        ar = true;
        try {
            let t = A({
                id: `__khoi_dong`,
                ten_key: ``,
                loai: `san`,
                pvp: ``,
                tilemap: ``,
                rong: 24,
                cao: 24,
                spawn: {
                    x: 1,
                    y: 1
                },
                spawns: {},
                noi: [],
                bai: [],
                chan: [
                    `da_1`,
                    `nuoc_1`,
                    `rung_1`,
                    `suoi_1`,
                    `vach_1`
                ].map((id, t)=>({
                        id,
                        x: 2 + t % 3 * 7,
                        y: 2 + Math.floor(t / 3) * 9,
                        w: 5,
                        h: 6
                    })),
                ext: {
                    duong: [
                        {
                            diem: [
                                [
                                    1,
                                    22
                                ],
                                [
                                    22,
                                    22
                                ]
                            ],
                            rong: 2,
                            lop: `dat`
                        }
                    ]
                }
            }, e);
            let n = (e)=>({
                    w: e,
                    h: e,
                    d: new Uint8Array(e * e * 4).fill(128)
                });
            let r = {
                nenA: n(64),
                nenB: n(64),
                da: n(64),
                duong: n(64)
            };
            for(let n = 0; n < 4; n++){
                tn(t, r, e, n % 2 * 8, Math.floor(n / 2) * 8, 8, 16);
            }
        } catch  {}
    }
    async function sr(e) {
        try {
            if (e.phien !== qn) {
                return;
            }
            let t = Vn(Kn, Bn);
            let n = await Wn;
            if (e.phien !== qn) {
                return;
            }
            Xn(t, n, e.bet);
            In = e.tr;
            Ln = t;
            Fn.postMessage({
                loai: `san`,
                phien: e.phien,
                chinh: false,
                W: e.tr.W,
                H: e.tr.H,
                ms: {
                    anh: 0,
                    truong: 0,
                    rai: 0
                }
            });
        } catch (error) {
            Fn.postMessage({
                loai: `loi`,
                msg: String(error)
            });
        }
    }
})();
